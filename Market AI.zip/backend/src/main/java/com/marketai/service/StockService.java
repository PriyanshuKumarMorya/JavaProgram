package com.marketai.service;

import com.marketai.model.dto.PricePoint;
import com.marketai.model.dto.StockAsset;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StockService {

    private static final List<StockInfo> TOP_STOCKS = List.of(
        new StockInfo("AAPL", "Apple Inc."),
        new StockInfo("MSFT", "Microsoft Corp."),
        new StockInfo("GOOGL", "Alphabet Inc."),
        new StockInfo("AMZN", "Amazon.com Inc."),
        new StockInfo("NVDA", "NVIDIA Corp."),
        new StockInfo("META", "Meta Platforms Inc."),
        new StockInfo("TSLA", "Tesla Inc."),
        new StockInfo("JPM", "JPMorgan Chase & Co."),
        new StockInfo("V", "Visa Inc."),
        new StockInfo("WMT", "Walmart Inc.")
    );

    private final RestTemplate restTemplate;

    @Value("${finnhub.api.key:}")
    private String finnhubApiKey;

    public StockService() {
        this.restTemplate = new RestTemplate();
    }

    public List<StockAsset> getTopStocks() {
        if (finnhubApiKey != null && !finnhubApiKey.isBlank()) {
            return fetchFromFinnhub();
        }
        return generateFallbackData();
    }

    public List<PricePoint> getHistory(String symbol) {
        if (finnhubApiKey != null && !finnhubApiKey.isBlank()) {
            return fetchHistoryFromFinnhub(symbol);
        }
        return generateHistoryFallback(symbol);
    }

    // ── Finnhub API ──

    private List<StockAsset> fetchFromFinnhub() {
        return TOP_STOCKS.stream().map(stock -> {
            try {
                String quoteUrl = "https://finnhub.io/api/v1/quote?symbol=" +
                                  stock.symbol + "&token=" + finnhubApiKey;
                @SuppressWarnings("unchecked")
                Map<String, Object> quote = restTemplate.getForObject(quoteUrl, Map.class);

                StockAsset asset = new StockAsset();
                asset.setId(stock.symbol.toLowerCase());
                asset.setSymbol(stock.symbol);
                asset.setName(stock.name);
                asset.setImage("https://logo.clearbit.com/" +
                    stock.name.toLowerCase().replaceAll("\\s+", "") + ".com");

                if (quote != null) {
                    double currentPrice = toDouble(quote.get("c"));
                    double prevClose = toDouble(quote.get("pc"));
                    asset.setCurrentPrice(currentPrice);
                    asset.setHigh24h(toDouble(quote.get("h")));
                    asset.setLow24h(toDouble(quote.get("l")));
                    if (prevClose != 0) {
                        asset.setPriceChange24h(
                            Math.round(((currentPrice - prevClose) / prevClose) * 10000.0) / 100.0
                        );
                    }
                }
                return asset;
            } catch (Exception e) {
                return generateSingleStock(stock);
            }
        }).collect(Collectors.toList());
    }

    private List<PricePoint> fetchHistoryFromFinnhub(String symbol) {
        try {
            long now = System.currentTimeMillis() / 1000;
            long thirtyDaysAgo = now - 30L * 24 * 60 * 60;
            String url = "https://finnhub.io/api/v1/stock/candle?symbol=" + symbol +
                         "&resolution=60&from=" + thirtyDaysAgo + "&to=" + now +
                         "&token=" + finnhubApiKey;

            @SuppressWarnings("unchecked")
            Map<String, Object> data = restTemplate.getForObject(url, Map.class);

            if (data != null && "ok".equals(data.get("s"))) {
                List<Integer> timestamps = (List<Integer>) data.get("t");
                List<Double> closes = (List<Double>) data.get("c");

                List<PricePoint> points = new ArrayList<>();
                for (int i = 0; i < timestamps.size(); i++) {
                    long ts = timestamps.get(i) * 1000L;
                    points.add(new PricePoint(ts, closes.get(i), Instant.ofEpochMilli(ts).toString()));
                }
                return points;
            }
        } catch (Exception ignored) {}
        return generateHistoryFallback(symbol);
    }

    // ── Fallback generators ──

    private List<StockAsset> generateFallbackData() {
        return TOP_STOCKS.stream()
            .map(this::generateSingleStock)
            .collect(Collectors.toList());
    }

    private StockAsset generateSingleStock(StockInfo info) {
        int seed = info.symbol.chars().sum();
        Random rng = new Random(seed);

        StockAsset asset = new StockAsset();
        asset.setId(info.symbol.toLowerCase());
        asset.setSymbol(info.symbol);
        asset.setName(info.name);
        asset.setImage("https://logo.clearbit.com/" +
            info.name.toLowerCase().replaceAll("\\s+", "") + ".com");

        double price = 80 + rng.nextDouble() * 420;
        asset.setCurrentPrice(Math.round(price * 100.0) / 100.0);
        asset.setMarketCap((long) (price * (1e8 + rng.nextDouble() * 3e12)));
        asset.setTotalVolume((long) (rng.nextDouble() * 5e10));
        asset.setPriceChange1h(Math.round((rng.nextDouble() * 4 - 2) * 100.0) / 100.0);
        asset.setPriceChange24h(Math.round((rng.nextDouble() * 10 - 5) * 100.0) / 100.0);
        asset.setPriceChange7d(Math.round((rng.nextDouble() * 20 - 10) * 100.0) / 100.0);
        asset.setPriceChange30d(Math.round((rng.nextDouble() * 40 - 20) * 100.0) / 100.0);
        asset.setHigh24h(Math.round(price * 1.03 * 100.0) / 100.0);
        asset.setLow24h(Math.round(price * 0.97 * 100.0) / 100.0);

        // Sparkline
        List<Double> sparkline = new ArrayList<>();
        double sp = price * (1 - (asset.getPriceChange7d() != null ? asset.getPriceChange7d() : 0) / 100);
        for (int i = 0; i < 168; i++) {
            sp *= 1 + (rng.nextDouble() * 0.016 - 0.008);
            sparkline.add(Math.round(sp * 100.0) / 100.0);
        }
        sparkline.set(sparkline.size() - 1, price);
        asset.setSparkline(sparkline);

        return asset;
    }

    private List<PricePoint> generateHistoryFallback(String symbol) {
        int seed = symbol.chars().sum();
        Random rng = new Random(seed);
        List<PricePoint> points = new ArrayList<>();
        long now = System.currentTimeMillis();
        long thirtyDaysMs = 30L * 24 * 60 * 60 * 1000;
        double price = 80 + rng.nextDouble() * 420;

        for (int i = 0; i < 720; i++) {
            long ts = now - thirtyDaysMs + (thirtyDaysMs / 720) * i;
            price *= 1 + (rng.nextDouble() * 0.01 - 0.005);
            points.add(new PricePoint(ts, Math.round(price * 100.0) / 100.0, Instant.ofEpochMilli(ts).toString()));
        }
        return points;
    }

    private double toDouble(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        return 0;
    }

    private record StockInfo(String symbol, String name) {}
}
