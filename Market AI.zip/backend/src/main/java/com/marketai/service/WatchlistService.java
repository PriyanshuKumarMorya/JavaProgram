package com.marketai.service;

import com.marketai.model.entity.WatchlistItem;
import com.marketai.repository.WatchlistRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WatchlistService {

    private final WatchlistRepository watchlistRepository;

    public WatchlistService(WatchlistRepository watchlistRepository) {
        this.watchlistRepository = watchlistRepository;
    }

    public List<WatchlistItem> getAll() {
        return watchlistRepository.findAllByOrderByAddedAtDesc();
    }

    public List<WatchlistItem> getByAssetType(String assetType) {
        return watchlistRepository.findByAssetTypeOrderByAddedAtDesc(assetType);
    }

    public WatchlistItem add(String symbol, String assetType, String name) {
        if (watchlistRepository.existsBySymbolAndAssetType(symbol.toUpperCase(), assetType)) {
            throw new IllegalArgumentException(symbol + " is already in your watchlist");
        }
        WatchlistItem item = new WatchlistItem(
            symbol.toUpperCase(),
            assetType,
            name != null && !name.isBlank() ? name : symbol.toUpperCase()
        );
        return watchlistRepository.save(item);
    }

    public void remove(Long id) {
        watchlistRepository.deleteById(id);
    }
}
