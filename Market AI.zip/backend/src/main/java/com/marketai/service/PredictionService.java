package com.marketai.service;

import com.marketai.model.dto.PredictionRequest;
import com.marketai.model.dto.PredictionResponse;
import com.marketai.model.dto.PricePoint;
import com.marketai.model.entity.Prediction;
import com.marketai.repository.PredictionRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PredictionService {

    private final PredictionRepository predictionRepository;

    public PredictionService(PredictionRepository predictionRepository) {
        this.predictionRepository = predictionRepository;
    }

    /**
     * Generate an AI prediction using an ensemble model:
     * Linear Regression (45%) + EMA Momentum (30%) + RSI (15%) + Noise (10%)
     */
    public PredictionResponse predict(PredictionRequest request) {
        List<PricePoint> prices = request.getPrices();
        List<Double> priceValues = prices.stream().map(PricePoint::getPrice).toList();
        double currentPrice = priceValues.get(priceValues.size() - 1);
        int timeframeHours = request.getTimeframe();

        // Use recent data
        int recentCount = Math.max(24, (int) (prices.size() * 0.4));
        List<Double> recentPrices = priceValues.subList(
            Math.max(0, priceValues.size() - recentCount), priceValues.size()
        );

        // ── 1. Linear Regression ──
        RegressionResult regression = linearRegression(recentPrices);
        double futureIndex = recentPrices.size() + Math.max(1, timeframeHours);
        double regressionPred = regression.slope * futureIndex + regression.intercept;

        // ── 2. EMA / MACD Momentum ──
        int emaShortPeriod = Math.min(12, recentPrices.size() / 4);
        int emaLongPeriod = Math.min(26, recentPrices.size() / 2);
        double emaShort = ema(recentPrices, Math.max(2, emaShortPeriod));
        double emaLong = ema(recentPrices, Math.max(2, emaLongPeriod));
        double macdSignal = emaShort - emaLong;
        double emaMomentum = currentPrice != 0 ? macdSignal / currentPrice : 0;

        // ── 3. RSI ──
        double rsiValue = rsi(recentPrices, 14);
        double rsiFactor = (rsiValue - 50.0) / 50.0; // -1 to +1

        // ── 4. Volatility ──
        double vol = volatility(recentPrices);
        double volAdjustedTf = timeframeHours * (1 + vol * 2);

        // ── Weighted Ensemble ──
        double momentumPred = currentPrice * (1 + emaMomentum * (volAdjustedTf / 24.0));
        double rsiPred = currentPrice * (1 + rsiFactor * 0.05 * (timeframeHours / 24.0));
        double noise = (Math.random() - 0.5) * vol * currentPrice * 0.1;

        double predicted = regressionPred * 0.45 +
                           momentumPred * 0.30 +
                           rsiPred * 0.15 +
                           (currentPrice + noise) * 0.10;

        // Clamp within ±30%
        predicted = Math.max(currentPrice * 0.7, Math.min(currentPrice * 1.3, predicted));

        // ── Confidence ──
        double regConfidence = regression.r2;
        double volConfidence = Math.max(0, 1 - vol * 15);
        double dataConfidence = Math.min(1, (double) prices.size() / 168);
        int confidence = (int) Math.round(
            (regConfidence * 0.4 + volConfidence * 0.35 + dataConfidence * 0.25) * 100
        );
        confidence = Math.min(95, Math.max(30, confidence));

        // ── Trend ──
        String trend = predicted > currentPrice ? "bullish" : "bearish";
        double changePercent = ((predicted - currentPrice) / currentPrice) * 100;

        // ── Support / Resistance ──
        List<Double> sorted = new ArrayList<>(recentPrices);
        Collections.sort(sorted);
        double support = sorted.get((int) (sorted.size() * 0.05));
        double resistance = sorted.get((int) (sorted.size() * 0.95));

        // ── Indicators ──
        Map<String, Double> indicators = new LinkedHashMap<>();
        indicators.put("rsi", Math.round(rsiValue * 10.0) / 10.0);
        indicators.put("volatility", Math.round(vol * 10000.0) / 100.0);
        indicators.put("regressionR2", Math.round(regression.r2 * 1000.0) / 10.0);

        // ── Build Response ──
        PredictionResponse response = new PredictionResponse();
        response.setCurrentPrice(Math.round(currentPrice * 100.0) / 100.0);
        response.setPredictedPrice(Math.round(predicted * 100.0) / 100.0);
        response.setChangePercent(Math.round(changePercent * 100.0) / 100.0);
        response.setTrend(trend);
        response.setConfidence(confidence);
        response.setSupport(Math.round(support * 100.0) / 100.0);
        response.setResistance(Math.round(resistance * 100.0) / 100.0);
        response.setTimeframe(timeframeHours + "h");
        response.setIndicators(indicators);

        // ── Persist ──
        Prediction entity = new Prediction(
            request.getSymbol(),
            request.getAssetType(),
            response.getPredictedPrice(),
            response.getCurrentPrice(),
            confidence,
            timeframeHours + "h"
        );
        predictionRepository.save(entity);

        return response;
    }

    public List<Prediction> getHistory(String symbol, String assetType) {
        if (symbol != null && assetType != null) {
            return predictionRepository.findBySymbolAndAssetTypeOrderByCreatedAtDesc(symbol, assetType);
        }
        return predictionRepository.findAllByOrderByCreatedAtDesc();
    }

    // ────────────────────────
    //  Statistical Helpers
    // ────────────────────────

    private record RegressionResult(double slope, double intercept, double r2) {}

    private RegressionResult linearRegression(List<Double> prices) {
        int n = prices.size();
        if (n < 2) return new RegressionResult(0, prices.get(0), 0);

        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
        for (int i = 0; i < n; i++) {
            double x = i;
            double y = prices.get(i);
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
            sumY2 += y * y;
        }
        double slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        double intercept = (sumY - slope * sumX) / n;

        double meanY = sumY / n;
        double ssRes = 0, ssTot = 0;
        for (int i = 0; i < n; i++) {
            double pred = slope * i + intercept;
            double y = prices.get(i);
            ssRes += (y - pred) * (y - pred);
            ssTot += (y - meanY) * (y - meanY);
        }
        double r2 = ssTot == 0 ? 0 : 1 - (ssRes / ssTot);
        return new RegressionResult(slope, intercept, Math.max(0, Math.min(1, r2)));
    }

    private double ema(List<Double> prices, int period) {
        if (prices.size() < period) return prices.get(prices.size() - 1);
        double k = 2.0 / (period + 1);
        double emaVal = 0;
        for (int i = 0; i < period; i++) emaVal += prices.get(i);
        emaVal /= period;
        for (int i = period; i < prices.size(); i++) {
            emaVal = prices.get(i) * k + emaVal * (1 - k);
        }
        return emaVal;
    }

    private double rsi(List<Double> prices, int period) {
        if (prices.size() < period + 1) return 50;
        double gains = 0, losses = 0;
        int start = prices.size() - period;
        for (int i = start; i < prices.size(); i++) {
            double diff = prices.get(i) - prices.get(i - 1);
            if (diff >= 0) gains += diff;
            else losses -= diff;
        }
        double avgGain = gains / period;
        double avgLoss = losses / period;
        if (avgLoss == 0) return 100;
        double rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }

    private double volatility(List<Double> prices) {
        if (prices.size() < 2) return 0;
        List<Double> returns = new ArrayList<>();
        for (int i = 1; i < prices.size(); i++) {
            returns.add((prices.get(i) - prices.get(i - 1)) / prices.get(i - 1));
        }
        double mean = returns.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        double variance = returns.stream()
            .mapToDouble(r -> (r - mean) * (r - mean))
            .average().orElse(0);
        return Math.sqrt(variance);
    }
}
