package com.marketai.service;

import com.marketai.model.dto.CryptoAsset;
import com.marketai.model.dto.PricePoint;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CryptoService {

    private static final String COINGECKO_BASE = "https://api.coingecko.com/api/v3";
    private static final List<String> TOP_IDS = List.of(
        "bitcoin", "ethereum", "binancecoin", "solana", "ripple",
        "cardano", "dogecoin", "polkadot", "avalanche-2", "chainlink"
    );

    private final RestTemplate restTemplate;

    public CryptoService() {
        this.restTemplate = new RestTemplate();
    }

    /**
     * Fetch top 10 cryptocurrencies from CoinGecko.
     */
    @SuppressWarnings("unchecked")
    public List<CryptoAsset> getTopCryptos() {
        String ids = String.join(",", TOP_IDS);
        String url = COINGECKO_BASE + "/coins/markets?vs_currency=usd&ids=" + ids +
                     "&order=market_cap_desc&per_page=10&page=1" +
                     "&sparkline=true&price_change_percentage=1h%2C24h%2C7d%2C30d";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(List.of(MediaType.APPLICATION_JSON));
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<List> response = restTemplate.exchange(
                url, HttpMethod.GET, entity, List.class
            );

            if (response.getBody() == null) return List.of();

            return ((List<Map<String, Object>>) response.getBody()).stream()
                .map(this::mapToCryptoAsset)
                .collect(Collectors.toList());

        } catch (Exception e) {
            // Fallback: return mock data if CoinGecko fails
            return generateFallbackData();
        }
    }

    /**
     * Fetch 30-day price history for a specific coin.
     */
    @SuppressWarnings("unchecked")
    public List<PricePoint> getHistory(String coinId) {
        String url = COINGECKO_BASE + "/coins/" + coinId +
                     "/market_chart?vs_currency=usd&days=30";

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(List.of(MediaType.APPLICATION_JSON));
            HttpEntity<Void> entity = new HttpEntity<>(headers);

            ResponseEntity<Map> response = restTemplate.exchange(
                url, HttpMethod.GET, entity, Map.class
            );

            if (response.getBody() == null) return List.of();

            List<List<Number>> prices = (List<List<Number>>) response.getBody().get("prices");
            if (prices == null) return List.of();

            return prices.stream().map(p -> {
                long ts = p.get(0).longValue();
                double price = p.get(1).doubleValue();
                return new PricePoint(ts, price, Instant.ofEpochMilli(ts).toString());
            }).collect(Collectors.toList());

        } catch (Exception e) {
            return generateHistoryFallback(coinId);
        }
    }

    private CryptoAsset mapToCryptoAsset(Map<String, Object> coin) {
        CryptoAsset asset = new CryptoAsset();
        asset.setId((String) coin.get("id"));
        asset.setSymbol(((String) coin.get("symbol")).toUpperCase());
        asset.setName((String) coin.get("name"));
        asset.setImage((String) coin.get("image"));
        asset.setCurrentPrice(toDouble(coin.get("current_price")));
        asset.setMarketCap(toLong(coin.get("market_cap")));
        asset.setMarketCapRank(toInt(coin.get("market_cap_rank")));
        asset.setTotalVolume(toLong(coin.get("total_volume")));
        asset.setPriceChange1h(toDouble(coin.get("price_change_percentage_1h_in_currency")));
        asset.setPriceChange24h(toDouble(coin.get("price_change_percentage_24h")));
        asset.setPriceChange7d(toDouble(coin.get("price_change_percentage_7d_in_currency")));
        asset.setPriceChange30d(toDouble(coin.get("price_change_percentage_30d_in_currency")));
        asset.setHigh24h(toDouble(coin.get("high_24h")));
        asset.setLow24h(toDouble(coin.get("low_24h")));

        // Sparkline
        Map<String, Object> sparklineMap = (Map<String, Object>) coin.get("sparkline_in_7d");
        if (sparklineMap != null && sparklineMap.get("price") instanceof List<?> list) {
            asset.setSparkline(list.stream()
                .map(o -> o instanceof Number n ? n.doubleValue() : 0.0)
                .collect(Collectors.toList()));
        }
        return asset;
    }

    // ── Fallback data generators ──

    private List<CryptoAsset> generateFallbackData() {
        String[][] coins = {
            {"bitcoin", "BTC", "Bitcoin"},
            {"ethereum", "ETH", "Ethereum"},
            {"binancecoin", "BNB", "BNB"},
            {"solana", "SOL", "Solana"},
            {"ripple", "XRP", "XRP"},
            {"cardano", "ADA", "Cardano"},
            {"dogecoin", "DOGE", "Dogecoin"},
            {"polkadot", "DOT", "Polkadot"},
            {"avalanche-2", "AVAX", "Avalanche"},
            {"chainlink", "LINK", "Chainlink"},
        };

        List<CryptoAsset> result = new ArrayList<>();
        Random rng = new Random(42);

        for (String[] c : coins) {
            CryptoAsset asset = new CryptoAsset();
            asset.setId(c[0]);
            asset.setSymbol(c[1]);
            asset.setName(c[2]);
            asset.setImage("https://assets.coingecko.com/coins/images/1/large/" + c[0] + ".png");
            double price = 10 + rng.nextDouble() * 50000;
            asset.setCurrentPrice(Math.round(price * 100.0) / 100.0);
            asset.setMarketCap((long) (price * (1e6 + rng.nextDouble() * 1e11)));
            asset.setPriceChange24h(Math.round((rng.nextDouble() * 10 - 5) * 100.0) / 100.0);

            List<Double> sparkline = new ArrayList<>();
            double sp = price * 0.9;
            for (int i = 0; i < 168; i++) {
                sp *= 1 + (rng.nextDouble() * 0.01 - 0.005);
                sparkline.add(Math.round(sp * 100.0) / 100.0);
            }
            sparkline.set(sparkline.size() - 1, price);
            asset.setSparkline(sparkline);
            result.add(asset);
        }
        return result;
    }

    private List<PricePoint> generateHistoryFallback(String coinId) {
        List<PricePoint> points = new ArrayList<>();
        Random rng = new Random(coinId.hashCode());
        long now = System.currentTimeMillis();
        long thirtyDaysMs = 30L * 24 * 60 * 60 * 1000;
        double price = 100 + rng.nextDouble() * 40000;

        for (int i = 0; i < 720; i++) {
            long ts = now - thirtyDaysMs + (thirtyDaysMs / 720) * i;
            price *= 1 + (rng.nextDouble() * 0.02 - 0.01);
            points.add(new PricePoint(ts, Math.round(price * 100.0) / 100.0, Instant.ofEpochMilli(ts).toString()));
        }
        return points;
    }

    private Double toDouble(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        return null;
    }

    private Long toLong(Object o) {
        if (o instanceof Number n) return n.longValue();
        return null;
    }

    private Integer toInt(Object o) {
        if (o instanceof Number n) return n.intValue();
        return null;
    }
}
