package com.marketai.repository;

import com.marketai.model.entity.WatchlistItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WatchlistRepository extends JpaRepository<WatchlistItem, Long> {

    List<WatchlistItem> findByAssetTypeOrderByAddedAtDesc(String assetType);

    List<WatchlistItem> findAllByOrderByAddedAtDesc();

    Optional<WatchlistItem> findBySymbolAndAssetType(String symbol, String assetType);

    boolean existsBySymbolAndAssetType(String symbol, String assetType);
}
