package com.marketai.repository;

import com.marketai.model.entity.Prediction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PredictionRepository extends JpaRepository<Prediction, Long> {

    List<Prediction> findBySymbolAndAssetTypeOrderByCreatedAtDesc(
        String symbol, String assetType
    );

    List<Prediction> findAllByOrderByCreatedAtDesc();
}
