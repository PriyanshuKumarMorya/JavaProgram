package com.marketai.controller;

import com.marketai.model.dto.WatchlistRequest;
import com.marketai.model.entity.WatchlistItem;
import com.marketai.service.WatchlistService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/watchlist")
public class WatchlistController {

    private final WatchlistService watchlistService;

    public WatchlistController(WatchlistService watchlistService) {
        this.watchlistService = watchlistService;
    }

    /**
     * GET /api/watchlist?assetType=crypto
     */
    @GetMapping
    public ResponseEntity<List<WatchlistItem>> getWatchlist(
        @RequestParam(required = false) String assetType
    ) {
        if (assetType != null) {
            return ResponseEntity.ok(watchlistService.getByAssetType(assetType));
        }
        return ResponseEntity.ok(watchlistService.getAll());
    }

    /**
     * POST /api/watchlist — add item
     */
    @PostMapping
    public ResponseEntity<?> addToWatchlist(@Valid @RequestBody WatchlistRequest request) {
        try {
            WatchlistItem item = watchlistService.add(
                request.getSymbol(), request.getAssetType(), request.getName()
            );
            return ResponseEntity.status(201).body(item);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(409).body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * DELETE /api/watchlist/{id} — remove item
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Boolean>> removeFromWatchlist(@PathVariable Long id) {
        watchlistService.remove(id);
        return ResponseEntity.ok(Map.of("success", true));
    }
}
