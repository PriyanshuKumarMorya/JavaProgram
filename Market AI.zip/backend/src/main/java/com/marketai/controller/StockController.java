package com.marketai.controller;

import com.marketai.model.dto.PricePoint;
import com.marketai.model.dto.StockAsset;
import com.marketai.service.StockService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/market/stocks")
public class StockController {

    private final StockService stockService;

    public StockController(StockService stockService) {
        this.stockService = stockService;
    }

    /**
     * GET /api/market/stocks — top 10 stocks
     */
    @GetMapping
    public ResponseEntity<List<StockAsset>> getTopStocks() {
        return ResponseEntity.ok(stockService.getTopStocks());
    }

    /**
     * GET /api/market/stocks/{symbol}/history — 30-day price history
     */
    @GetMapping("/{symbol}/history")
    public ResponseEntity<Map<String, Object>> getHistory(@PathVariable String symbol) {
        List<PricePoint> prices = stockService.getHistory(symbol);
        return ResponseEntity.ok(Map.of(
            "symbol", symbol,
            "prices", prices
        ));
    }
}
