package com.marketai.controller;

import com.marketai.model.dto.CryptoAsset;
import com.marketai.model.dto.PricePoint;
import com.marketai.service.CryptoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/market/crypto")
public class CryptoController {

    private final CryptoService cryptoService;

    public CryptoController(CryptoService cryptoService) {
        this.cryptoService = cryptoService;
    }

    /**
     * GET /api/market/crypto — top 10 cryptocurrencies
     */
    @GetMapping
    public ResponseEntity<List<CryptoAsset>> getTopCryptos() {
        return ResponseEntity.ok(cryptoService.getTopCryptos());
    }

    /**
     * GET /api/market/crypto/{id}/history — 30-day price history
     */
    @GetMapping("/{id}/history")
    public ResponseEntity<Map<String, Object>> getHistory(@PathVariable String id) {
        List<PricePoint> prices = cryptoService.getHistory(id);
        return ResponseEntity.ok(Map.of(
            "id", id,
            "prices", prices
        ));
    }
}
