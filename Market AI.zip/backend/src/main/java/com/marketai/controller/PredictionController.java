package com.marketai.controller;

import com.marketai.model.dto.PredictionRequest;
import com.marketai.model.dto.PredictionResponse;
import com.marketai.model.entity.Prediction;
import com.marketai.service.PredictionService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/predict")
public class PredictionController {

    private final PredictionService predictionService;

    public PredictionController(PredictionService predictionService) {
        this.predictionService = predictionService;
    }

    /**
     * POST /api/predict — generate AI prediction
     */
    @PostMapping
    public ResponseEntity<?> predict(@Valid @RequestBody PredictionRequest request) {
        try {
            PredictionResponse response = predictionService.predict(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("error", "Prediction failed: " + e.getMessage())
            );
        }
    }

    /**
     * GET /api/predict — retrieve prediction history
     */
    @GetMapping
    public ResponseEntity<List<Prediction>> getPredictions(
        @RequestParam(required = false) String symbol,
        @RequestParam(required = false) String assetType
    ) {
        return ResponseEntity.ok(predictionService.getHistory(symbol, assetType));
    }
}
