package com.marketai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarketAiApplication.class, args);
    }
}
