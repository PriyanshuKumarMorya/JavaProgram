package com.marketai.model.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

public class PredictionRequest {

    @NotBlank(message = "Symbol is required")
    private String symbol;

    @NotBlank(message = "Asset type is required")
    private String assetType; // "crypto" or "stock"

    @NotNull(message = "Price history is required")
    @Size(min = 5, message = "At least 5 price points required")
    private List<PricePoint> prices;

    private Integer timeframe = 24; // default 24 hours

    public PredictionRequest() {}

    public PredictionRequest(String symbol, String assetType, List<PricePoint> prices, Integer timeframe) {
        this.symbol = symbol;
        this.assetType = assetType;
        this.prices = prices;
        this.timeframe = timeframe;
    }

    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public String getAssetType() { return assetType; }
    public void setAssetType(String assetType) { this.assetType = assetType; }

    public List<PricePoint> getPrices() { return prices; }
    public void setPrices(List<PricePoint> prices) { this.prices = prices; }

    public Integer getTimeframe() { return timeframe; }
    public void setTimeframe(Integer timeframe) { this.timeframe = timeframe; }
}
