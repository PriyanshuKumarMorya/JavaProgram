package com.marketai.model.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "predictions")
public class Prediction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String symbol;

    @Column(name = "asset_type", nullable = false)
    private String assetType; // "crypto" or "stock"

    @Column(name = "predicted_price", nullable = false)
    private Double predictedPrice;

    @Column(name = "current_price", nullable = false)
    private Double currentPrice;

    @Column(nullable = false)
    private Integer confidence;

    @Column(nullable = false)
    private String timeframe; // "1h", "24h", "168h", "720h"

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Prediction() {}

    public Prediction(String symbol, String assetType, Double predictedPrice,
                      Double currentPrice, Integer confidence, String timeframe) {
        this.symbol = symbol;
        this.assetType = assetType;
        this.predictedPrice = predictedPrice;
        this.currentPrice = currentPrice;
        this.confidence = confidence;
        this.timeframe = timeframe;
    }

    // --- Getters & Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public String getAssetType() { return assetType; }
    public void setAssetType(String assetType) { this.assetType = assetType; }

    public Double getPredictedPrice() { return predictedPrice; }
    public void setPredictedPrice(Double predictedPrice) { this.predictedPrice = predictedPrice; }

    public Double getCurrentPrice() { return currentPrice; }
    public void setCurrentPrice(Double currentPrice) { this.currentPrice = currentPrice; }

    public Integer getConfidence() { return confidence; }
    public void setConfidence(Integer confidence) { this.confidence = confidence; }

    public String getTimeframe() { return timeframe; }
    public void setTimeframe(String timeframe) { this.timeframe = timeframe; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
