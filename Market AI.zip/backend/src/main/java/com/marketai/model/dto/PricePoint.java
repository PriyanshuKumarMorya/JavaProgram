package com.marketai.model.dto;

public class PricePoint {

    private Long timestamp;
    private Double price;
    private String date;

    public PricePoint() {}

    public PricePoint(Long timestamp, Double price, String date) {
        this.timestamp = timestamp;
        this.price = price;
        this.date = date;
    }

    public Long getTimestamp() { return timestamp; }
    public void setTimestamp(Long timestamp) { this.timestamp = timestamp; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}
