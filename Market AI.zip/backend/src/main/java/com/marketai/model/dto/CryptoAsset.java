package com.marketai.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class CryptoAsset {

    private String id;
    private String symbol;
    private String name;
    private String image;

    @JsonProperty("currentPrice")
    private Double currentPrice;

    @JsonProperty("marketCap")
    private Long marketCap;

    @JsonProperty("marketCapRank")
    private Integer marketCapRank;

    @JsonProperty("totalVolume")
    private Long totalVolume;

    @JsonProperty("priceChange1h")
    private Double priceChange1h;

    @JsonProperty("priceChange24h")
    private Double priceChange24h;

    @JsonProperty("priceChange7d")
    private Double priceChange7d;

    @JsonProperty("priceChange30d")
    private Double priceChange30d;

    @JsonProperty("high24h")
    private Double high24h;

    @JsonProperty("low24h")
    private Double low24h;

    private List<Double> sparkline;

    public CryptoAsset() {}

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }

    public Double getCurrentPrice() { return currentPrice; }
    public void setCurrentPrice(Double currentPrice) { this.currentPrice = currentPrice; }

    public Long getMarketCap() { return marketCap; }
    public void setMarketCap(Long marketCap) { this.marketCap = marketCap; }

    public Integer getMarketCapRank() { return marketCapRank; }
    public void setMarketCapRank(Integer marketCapRank) { this.marketCapRank = marketCapRank; }

    public Long getTotalVolume() { return totalVolume; }
    public void setTotalVolume(Long totalVolume) { this.totalVolume = totalVolume; }

    public Double getPriceChange1h() { return priceChange1h; }
    public void setPriceChange1h(Double priceChange1h) { this.priceChange1h = priceChange1h; }

    public Double getPriceChange24h() { return priceChange24h; }
    public void setPriceChange24h(Double priceChange24h) { this.priceChange24h = priceChange24h; }

    public Double getPriceChange7d() { return priceChange7d; }
    public void setPriceChange7d(Double priceChange7d) { this.priceChange7d = priceChange7d; }

    public Double getPriceChange30d() { return priceChange30d; }
    public void setPriceChange30d(Double priceChange30d) { this.priceChange30d = priceChange30d; }

    public Double getHigh24h() { return high24h; }
    public void setHigh24h(Double high24h) { this.high24h = high24h; }

    public Double getLow24h() { return low24h; }
    public void setLow24h(Double low24h) { this.low24h = low24h; }

    public List<Double> getSparkline() { return sparkline; }
    public void setSparkline(List<Double> sparkline) { this.sparkline = sparkline; }
}
