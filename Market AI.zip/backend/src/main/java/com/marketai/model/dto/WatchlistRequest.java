package com.marketai.model.dto;

import jakarta.validation.constraints.NotBlank;

public class WatchlistRequest {

    @NotBlank(message = "Symbol is required")
    private String symbol;

    @NotBlank(message = "Asset type is required")
    private String assetType;

    private String name;

    public WatchlistRequest() {}

    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }

    public String getAssetType() { return assetType; }
    public void setAssetType(String assetType) { this.assetType = assetType; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
