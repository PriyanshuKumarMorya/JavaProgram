package com.marketai.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;

public class PredictionResponse {

    @JsonProperty("currentPrice")
    private Double currentPrice;

    @JsonProperty("predictedPrice")
    private Double predictedPrice;

    @JsonProperty("changePercent")
    private Double changePercent;

    private String trend;       // "bullish" or "bearish"
    private Integer confidence;  // 0-100

    private Double support;
    private Double resistance;

    private String timeframe;    // "24h"

    private Map<String, Double> indicators; // rsi, volatility, regressionR2

    public PredictionResponse() {}

    public Double getCurrentPrice() { return currentPrice; }
    public void setCurrentPrice(Double currentPrice) { this.currentPrice = currentPrice; }

    public Double getPredictedPrice() { return predictedPrice; }
    public void setPredictedPrice(Double predictedPrice) { this.predictedPrice = predictedPrice; }

    public Double getChangePercent() { return changePercent; }
    public void setChangePercent(Double changePercent) { this.changePercent = changePercent; }

    public String getTrend() { return trend; }
    public void setTrend(String trend) { this.trend = trend; }

    public Integer getConfidence() { return confidence; }
    public void setConfidence(Integer confidence) { this.confidence = confidence; }

    public Double getSupport() { return support; }
    public void setSupport(Double support) { this.support = support; }

    public Double getResistance() { return resistance; }
    public void setResistance(Double resistance) { this.resistance = resistance; }

    public String getTimeframe() { return timeframe; }
    public void setTimeframe(String timeframe) { this.timeframe = timeframe; }

    public Map<String, Double> getIndicators() { return indicators; }
    public void setIndicators(Map<String, Double> indicators) { this.indicators = indicators; }
}
