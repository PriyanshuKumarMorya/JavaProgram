import type { NextConfig } from "next";

const SPRING_BOOT_URL = process.env.SPRING_BOOT_URL || "http://localhost:8080";

const nextConfig: NextConfig = {
  // Proxy API requests to Spring Boot backend when SPRING_BOOT_URL is configured.
  // Remove/ignore in production if Spring Boot sits behind a reverse proxy.
  async rewrites() {
    const apiRewrites = [
      // Only proxy if Spring Boot is available (skip for sandbox where Next.js handles everything)
    ];

    if (process.env.SPRING_BOOT_URL) {
      apiRewrites.push({
        source: "/api/:path*",
        destination: `${SPRING_BOOT_URL}/api/:path*`,
      });
    }

    return apiRewrites;
  },
};

export default nextConfig;
