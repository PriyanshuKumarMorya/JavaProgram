import { pgTable, text, timestamp, real, serial } from "drizzle-orm/pg-core";

export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  assetType: text("asset_type").notNull(), // "crypto" or "stock"
  predictedPrice: real("predicted_price").notNull(),
  currentPrice: real("current_price").notNull(),
  confidence: real("confidence").notNull(),
  timeframe: text("timeframe").notNull(), // "1h", "24h", "7d", "30d"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const watchlist = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  assetType: text("asset_type").notNull(),
  name: text("name").notNull(),
  addedAt: timestamp("added_at").defaultNow().notNull(),
});
