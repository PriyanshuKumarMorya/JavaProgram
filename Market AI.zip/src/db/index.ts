import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Database is OPTIONAL.
 * - If DATABASE_URL is set  → full persistence (predictions + watchlist).
 * - If not set             → db === null, and API routes degrade gracefully
 *                            (return empty data instead of crashing).
 */
const databaseUrl = process.env.DATABASE_URL;

export const dbAvailable = Boolean(databaseUrl);

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool = databaseUrl
  ? globalForDb.__arenaNextJsPostgresqlPool ??
    new Pool({ connectionString: databaseUrl })
  : null;

if (pool && process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = pool ? drizzle(pool) : null;

export type DbClient = NonNullable<typeof db>;
