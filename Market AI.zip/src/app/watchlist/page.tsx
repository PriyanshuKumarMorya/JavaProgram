"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ProShell, PageTitle } from "@/components/ProShell";
import { loadLS, saveLS, LS, type AssetType } from "@/lib/pro";

interface WatchItem {
  symbol: string;
  name: string;
  type: AssetType;
}

interface MarketAsset {
  symbol: string;
  name: string;
  currentPrice: number;
  priceChange24h: number | null;
  sparkline: number[];
  image: string;
}

export default function WatchlistPage() {
  const [items, setItems] = useState<WatchItem[]>(() =>
    loadLS<WatchItem[]>(LS.watchlist, [])
  );
  const [market, setMarket] = useState<Record<string, MarketAsset & { type: AssetType }>>({});
  const [pick, setPick] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [c, s] = await Promise.all([
          fetch("/api/market/crypto").then((r) => r.json()),
          fetch("/api/market/stocks").then((r) => r.json()),
        ]);
        const map: Record<string, MarketAsset & { type: AssetType }> = {};
        c.forEach((a: MarketAsset) => (map[a.symbol] = { ...a, type: "crypto" }));
        s.forEach((a: MarketAsset) => (map[a.symbol] = { ...a, type: "stock" }));
        setMarket(map);
        if (!pick && c[0]) setPick(c[0].symbol);
      } finally {
        setLoaded(true);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const add = () => {
    const m = market[pick];
    if (!m) return;
    if (items.some((i) => i.symbol === pick)) return;
    const next = [...items, { symbol: pick, name: m.name, type: m.type }];
    setItems(next);
    saveLS(LS.watchlist, next);
  };

  const remove = (symbol: string) => {
    const next = items.filter((i) => i.symbol !== symbol);
    setItems(next);
    saveLS(LS.watchlist, next);
  };

  const rows = useMemo(
    () => items.map((i) => ({ ...i, data: market[i.symbol] })).filter((r) => r.data),
    [items, market]
  );

  return (
    <ProShell active="watchlist">
      <PageTitle
        icon="⭐"
        title="My Watchlist"
        subtitle="Your favourite cryptos & stocks with live prices — saved on this device"
      />

      {/* Add control */}
      <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 mb-6 flex items-center gap-3 flex-wrap">
        <select
          value={pick}
          onChange={(e) => setPick(e.target.value)}
          className="bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white min-w-[220px]"
        >
          <optgroup label="🪙 Crypto">
            {Object.values(market).filter((m) => m.type === "crypto").map((m) => (
              <option key={m.symbol} value={m.symbol}>{m.symbol} — {m.name}</option>
            ))}
          </optgroup>
          <optgroup label="📈 Stocks">
            {Object.values(market).filter((m) => m.type === "stock").map((m) => (
              <option key={m.symbol} value={m.symbol}>{m.symbol} — {m.name}</option>
            ))}
          </optgroup>
        </select>
        <button
          onClick={add}
          className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
        >
          + Add to watchlist
        </button>
        <span className="text-xs text-slate-500">{items.length} saved</span>
      </div>

      {!loaded ? (
        <p className="text-center text-slate-500 py-16 text-sm">Loading...</p>
      ) : rows.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-12 text-center">
          <span className="text-4xl">⭐</span>
          <p className="mt-3 text-slate-300 text-sm">Your watchlist is empty.</p>
          <p className="text-xs text-slate-500 mt-1">Pick an asset above and click “Add to watchlist”.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rows.map((r) => {
            const d = r.data!;
            const up = (d.priceChange24h ?? 0) >= 0;
            return (
              <div key={r.symbol} className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img src={d.image} alt="" className="w-8 h-8 rounded-full bg-slate-700" />
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-white">{r.symbol}</p>
                      <p className="text-[10px] text-slate-500 truncate">{r.name}</p>
                    </div>
                  </div>
                  <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${r.type === "crypto" ? "bg-amber-500/10 text-amber-400" : "bg-cyan-500/10 text-cyan-400"}`}>
                    {r.type === "crypto" ? "CRYPTO" : "STOCK"}
                  </span>
                </div>

                <div className="flex items-end justify-between mt-3">
                  <div>
                    <p className="text-xl font-extrabold text-white tabular-nums">
                      ${d.currentPrice.toLocaleString(undefined, { maximumFractionDigits: d.currentPrice < 1 ? 4 : 2 })}
                    </p>
                    <p className={`text-xs font-semibold tabular-nums ${up ? "text-emerald-400" : "text-red-400"}`}>
                      {up ? "▲" : "▼"} {Math.abs(d.priceChange24h ?? 0).toFixed(2)}%
                    </p>
                  </div>
                  <Spark values={d.sparkline} up={up} />
                </div>

                <div className="flex gap-2 mt-3">
                  <Link
                    href={`/trade/${r.symbol}`}
                    className="flex-1 text-center py-1.5 rounded-lg bg-indigo-600/20 text-indigo-300 text-xs font-semibold hover:bg-indigo-600/40"
                  >
                    🛡️ Trade
                  </Link>
                  <button
                    onClick={() => remove(r.symbol)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400 text-xs hover:text-red-400"
                  >
                    ✕ Remove
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </ProShell>
  );
}

function Spark({ values, up }: { values: number[]; up: boolean }) {
  if (!values || values.length < 2) return null;
  const w = 90, h = 32;
  const min = Math.min(...values), max = Math.max(...values), r = max - min || 1;
  const d = values
    .map((v, i) => `${i === 0 ? "M" : "L"} ${((i / (values.length - 1)) * w).toFixed(1)} ${(h - ((v - min) / r) * (h - 4) - 2).toFixed(1)}`)
    .join(" ");
  return (
    <svg width={w} height={h}>
      <path d={d} fill="none" stroke={up ? "#34d399" : "#f87171"} strokeWidth={1.6} />
    </svg>
  );
}
