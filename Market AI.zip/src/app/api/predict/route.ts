import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { predictions } from "@/db/schema";
import { eq, and } from "drizzle-orm";

interface PricePoint {
  timestamp: number;
  price: number;
}

// Linear regression model
function linearRegression(points: { x: number; y: number }[]) {
  const n = points.length;
  if (n < 2) return { slope: 0, intercept: points[0]?.y || 0, r2: 0 };

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;
  for (const p of points) {
    sumX += p.x;
    sumY += p.y;
    sumXY += p.x * p.y;
    sumX2 += p.x * p.x;
    sumY2 += p.y * p.y;
  }

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  // R-squared calculation
  const meanY = sumY / n;
  let ssRes = 0, ssTot = 0;
  for (const p of points) {
    const predicted = slope * p.x + intercept;
    ssRes += (p.y - predicted) ** 2;
    ssTot += (p.y - meanY) ** 2;
  }
  const r2 = ssTot === 0 ? 0 : 1 - ssRes / ssTot;

  return { slope, intercept, r2: Math.max(0, Math.min(1, r2)) };
}

// Exponential moving average
function ema(prices: number[], period: number): number {
  if (prices.length < period) return prices[prices.length - 1];
  const k = 2 / (period + 1);
  let emaVal = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < prices.length; i++) {
    emaVal = prices[i] * k + emaVal * (1 - k);
  }
  return emaVal;
}

// RSI calculation
function rsi(prices: number[], period = 14): number {
  if (prices.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = prices.length - period; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

// Volatility (standard deviation of returns)
function volatility(prices: number[]): number {
  if (prices.length < 2) return 0;
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
  }
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + (r - mean) ** 2, 0) / returns.length;
  return Math.sqrt(variance);
}

function predictPrice(prices: PricePoint[], timeframeHours: number) {
  const priceValues = prices.map((p) => p.price);
  const currentPrice = priceValues[priceValues.length - 1];
  
  // Use recent data: last 50% for short-term, more for long-term
  const recentCount = Math.max(24, Math.floor(prices.length * 0.4));
  const recentPrices = priceValues.slice(-recentCount);
  
  // Prepare data for linear regression
  const points = recentPrices.map((price, i) => ({
    x: i,
    y: price,
  }));
  
  const regression = linearRegression(points);
  
  // Predict price at the end of timeframe
  const futureIndex = points.length + Math.max(1, Math.round(timeframeHours));
  const regressionPrediction = regression.slope * futureIndex + regression.intercept;
  
  // EMA-based prediction
  const emaShort = ema(recentPrices, Math.min(12, Math.floor(recentPrices.length / 4)));
  const emaLong = ema(recentPrices, Math.min(26, Math.floor(recentPrices.length / 2)));
  const macdSignal = emaShort - emaLong;
  const emaMomentum = macdSignal / currentPrice;
  
  // RSI factor
  const rsiValue = rsi(recentPrices);
  const rsiFactor = (rsiValue - 50) / 50; // -1 to 1, normalized
  
  // Volatility factor
  const vol = volatility(recentPrices);
  const volAdjustedTimeframe = timeframeHours * (1 + vol * 2);
  
  // Weighted ensemble prediction
  const regressionWeight = 0.45;
  const momentumWeight = 0.30;
  const rsiWeight = 0.15;
  const noiseWeight = 0.10;
  
  const momentumPrediction = currentPrice * (1 + emaMomentum * (volAdjustedTimeframe / 24));
  const rsiPrediction = currentPrice * (1 + rsiFactor * 0.05 * (timeframeHours / 24));
  const noiseTerm = (Math.random() - 0.5) * vol * currentPrice * 0.1;
  
  const predictedPrice =
    regressionPrediction * regressionWeight +
    momentumPrediction * momentumWeight +
    rsiPrediction * rsiWeight +
    (currentPrice + noiseTerm) * noiseWeight;
  
  // Ensure prediction is reasonable (within ±30% of current)
  const clampedPrediction = Math.max(
    currentPrice * 0.7,
    Math.min(currentPrice * 1.3, predictedPrice)
  );
  
  // Confidence calculation
  const regressionConfidence = regression.r2;
  const volatilityConfidence = Math.max(0, 1 - vol * 15); // lower vol = higher confidence
  const dataConfidence = Math.min(1, prices.length / 168); // more data = higher confidence
  
  const confidence = Math.round(
    (regressionConfidence * 0.4 + volatilityConfidence * 0.35 + dataConfidence * 0.25) * 100
  );
  
  // Trend direction
  const trend = predictedPrice > currentPrice ? "bullish" : "bearish";
  const changePercent = ((predictedPrice - currentPrice) / currentPrice) * 100;
  
  // Support and resistance levels
  const sortedPrices = [...recentPrices].sort((a, b) => a - b);
  const support = sortedPrices[Math.floor(sortedPrices.length * 0.05)];
  const resistance = sortedPrices[Math.floor(sortedPrices.length * 0.95)];
  
  return {
    currentPrice: Math.round(currentPrice * 100) / 100,
    predictedPrice: Math.round(clampedPrediction * 100) / 100,
    changePercent: Math.round(changePercent * 100) / 100,
    trend,
    confidence: Math.round(Math.min(95, Math.max(30, confidence))),
    support: Math.round(support * 100) / 100,
    resistance: Math.round(resistance * 100) / 100,
    indicators: {
      rsi: Math.round(rsiValue * 10) / 10,
      volatility: Math.round(vol * 10000) / 100,
      regressionR2: Math.round(regression.r2 * 1000) / 10,
    },
    timeframe: `${timeframeHours}h`,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      symbol,
      assetType,
      prices,
      timeframe = 24,
    }: {
      symbol: string;
      assetType: "crypto" | "stock";
      prices: PricePoint[];
      timeframe?: number;
    } = body;

    if (!symbol || !prices || prices.length < 5) {
      return NextResponse.json(
        { error: "Symbol and at least 5 price points are required" },
        { status: 400 }
      );
    }

    const result = predictPrice(prices, timeframe);

    // Store prediction in database (skip if DB not configured)
    if (!db) return NextResponse.json(result);
    try {
      await db.insert(predictions).values({
        symbol,
        assetType,
        predictedPrice: result.predictedPrice,
        currentPrice: result.currentPrice,
        confidence: result.confidence,
        timeframe: `${timeframe}h`,
      });
    } catch (dbError) {
      console.error("Failed to store prediction:", dbError);
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error("Prediction error:", error);
    return NextResponse.json(
      { error: "Failed to generate prediction" },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    if (!db) return NextResponse.json([]);
    const { searchParams } = new URL(request.url);
    const symbol = searchParams.get("symbol");
    const assetType = searchParams.get("assetType");

    if (symbol && assetType) {
      const pastPredictions = await db
        .select()
        .from(predictions)
        .where(
          and(
            eq(predictions.symbol, symbol),
            eq(predictions.assetType, assetType)
          )
        )
        .orderBy(predictions.createdAt)
        .limit(20);

      return NextResponse.json(pastPredictions);
    }

    const allPredictions = await db
      .select()
      .from(predictions)
      .orderBy(predictions.createdAt)
      .limit(50);

    return NextResponse.json(allPredictions);
  } catch (error) {
    console.error("Failed to fetch predictions:", error);
    return NextResponse.json(
      { error: "Failed to fetch predictions" },
      { status: 500 }
    );
  }
}
