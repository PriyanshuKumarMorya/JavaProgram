import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { watchlist } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    if (!db) return NextResponse.json([]);
    const { searchParams } = new URL(request.url);
    const assetType = searchParams.get("assetType");

    const query = assetType
      ? db
          .select()
          .from(watchlist)
          .where(eq(watchlist.assetType, assetType))
          .orderBy(watchlist.addedAt)
      : db.select().from(watchlist).orderBy(watchlist.addedAt);

    const items = await query;
    return NextResponse.json(items);
  } catch (error) {
    console.error("Failed to fetch watchlist:", error);
    return NextResponse.json(
      { error: "Failed to fetch watchlist" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { symbol, assetType, name } = body;

    if (!symbol || !assetType) {
      return NextResponse.json(
        { error: "Symbol and assetType are required" },
        { status: 400 }
      );
    }

    if (!db) {
      return NextResponse.json(
        { error: "Database not configured (set DATABASE_URL)" },
        { status: 503 }
      );
    }

    // Check for duplicates
    const existing = await db
      .select()
      .from(watchlist)
      .where(
        and(
          eq(watchlist.symbol, symbol.toUpperCase()),
          eq(watchlist.assetType, assetType)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      return NextResponse.json(
        { error: "Already in watchlist" },
        { status: 409 }
      );
    }

    const [item] = await db
      .insert(watchlist)
      .values({
        symbol: symbol.toUpperCase(),
        assetType,
        name: name || symbol.toUpperCase(),
      })
      .returning();

    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error("Failed to add to watchlist:", error);
    return NextResponse.json(
      { error: "Failed to add to watchlist" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { error: "ID is required" },
        { status: 400 }
      );
    }

    if (!db) {
      return NextResponse.json(
        { error: "Database not configured (set DATABASE_URL)" },
        { status: 503 }
      );
    }

    await db.delete(watchlist).where(eq(watchlist.id, parseInt(id, 10)));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to remove from watchlist:", error);
    return NextResponse.json(
      { error: "Failed to remove from watchlist" },
      { status: 500 }
    );
  }
}
