import { NextResponse } from "next/server";

const COINGECKO_BASE = "https://api.coingecko.com/api/v3";

// Top cryptocurrencies to track
const TOP_CRYPTO_IDS = [
  "bitcoin",
  "ethereum",
  "binancecoin",
  "solana",
  "ripple",
  "cardano",
  "dogecoin",
  "polkadot",
  "avalanche-2",
  "chainlink",
];

export async function GET() {
  try {
    const ids = TOP_CRYPTO_IDS.join(",");
    const res = await fetch(
      `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&per_page=10&page=1&sparkline=true&price_change_percentage=1h%2C24h%2C7d%2C30d`,
      {
        headers: { Accept: "application/json" },
        next: { revalidate: 60 }, // revalidate every 60 seconds
      }
    );

    if (!res.ok) {
      throw new Error(`CoinGecko API error: ${res.status}`);
    }

    const data = await res.json();

    const formatted = data.map((coin: Record<string, unknown>) => ({
      id: coin.id as string,
      symbol: (coin.symbol as string).toUpperCase(),
      name: coin.name as string,
      image: coin.image as string,
      currentPrice: coin.current_price as number,
      marketCap: coin.market_cap as number,
      marketCapRank: coin.market_cap_rank as number,
      totalVolume: coin.total_volume as number,
      priceChange1h: coin.price_change_percentage_1h_in_currency as number | null,
      priceChange24h: coin.price_change_percentage_24h as number | null,
      priceChange7d: coin.price_change_percentage_7d_in_currency as number | null,
      priceChange30d: coin.price_change_percentage_30d_in_currency as number | null,
      sparkline: (coin.sparkline_in_7d as { price: number[] })?.price || [],
      high24h: coin.high_24h as number,
      low24h: coin.low_24h as number,
    }));

    return NextResponse.json(formatted);
  } catch (error) {
    console.error("Failed to fetch crypto data:", error);
    return NextResponse.json(
      { error: "Failed to fetch cryptocurrency data" },
      { status: 500 }
    );
  }
}
