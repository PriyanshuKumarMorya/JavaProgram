import { NextResponse } from "next/server";

// Top stocks to track
const TOP_STOCKS = [
  { symbol: "AAPL", name: "Apple Inc." },
  { symbol: "MSFT", name: "Microsoft Corp." },
  { symbol: "GOOGL", name: "Alphabet Inc." },
  { symbol: "AMZN", name: "Amazon.com Inc." },
  { symbol: "NVDA", name: "NVIDIA Corp." },
  { symbol: "META", name: "Meta Platforms Inc." },
  { symbol: "TSLA", name: "Tesla Inc." },
  { symbol: "JPM", name: "JPMorgan Chase & Co." },
  { symbol: "V", name: "Visa Inc." },
  { symbol: "WMT", name: "Walmart Inc." },
];

function generateStockData(symbol: string, name: string) {
  // Use a deterministic seed based on symbol for consistent mock data
  const seed = symbol.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const pseudoRandom = (min: number, max: number, offset = 0) => {
    const x = Math.sin(seed + offset) * 10000;
    const r = x - Math.floor(x);
    return min + r * (max - min);
  };

  const basePrice = pseudoRandom(80, 500);
  const currentPrice = Math.round(basePrice * 100) / 100;
  const change1h = Math.round(pseudoRandom(-2, 2, 1) * 100) / 100;
  const change24h = Math.round(pseudoRandom(-5, 5, 2) * 100) / 100;
  const change7d = Math.round(pseudoRandom(-10, 10, 3) * 100) / 100;
  const change30d = Math.round(pseudoRandom(-20, 20, 4) * 100) / 100;

  // Generate sparkline data (7 days, 24 points per day = 168 points)
  const sparkline: number[] = [];
  let price = currentPrice * (1 - change7d / 100);
  for (let i = 0; i < 168; i++) {
    price = price * (1 + pseudoRandom(-0.008, 0.008, i + 10));
    sparkline.push(Math.round(price * 100) / 100);
  }
  // Ensure last point matches current price
  sparkline[sparkline.length - 1] = currentPrice;

  return {
    id: symbol.toLowerCase(),
    symbol,
    name,
    image: `https://logo.clearbit.com/${name.toLowerCase().replace(/\s+/g, "")}.com`,
    currentPrice,
    marketCap: Math.round(pseudoRandom(50, 3000, 5) * 1e9),
    marketCapRank: 0,
    totalVolume: Math.round(pseudoRandom(5, 50, 6) * 1e9),
    priceChange1h: change1h,
    priceChange24h: change24h,
    priceChange7d: change7d,
    priceChange30d: change30d,
    sparkline,
    high24h: Math.round(currentPrice * (1 + pseudoRandom(0.01, 0.04, 7)) * 100) / 100,
    low24h: Math.round(currentPrice * (1 - pseudoRandom(0.01, 0.04, 8)) * 100) / 100,
  };
}

export async function GET() {
  try {
    // Try to fetch from a real API first (Finnhub free tier)
    const finnhubKey = process.env.FINNHUB_API_KEY;
    
    if (finnhubKey) {
      const results = await Promise.all(
        TOP_STOCKS.map(async ({ symbol }) => {
          try {
            const quoteRes = await fetch(
              `https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${finnhubKey}`
            );
            const quote = await quoteRes.json();
            
            const profileRes = await fetch(
              `https://finnhub.io/api/v1/stock/profile2?symbol=${symbol}&token=${finnhubKey}`
            );
            const profile = await profileRes.json();

            const currentPrice = quote.c as number;
            const previousClose = quote.pc as number;
            const changePercent = previousClose ? ((currentPrice - previousClose) / previousClose) * 100 : 0;

            return {
              id: symbol.toLowerCase(),
              symbol,
              name: profile.name || symbol,
              image: profile.logo || "",
              currentPrice,
              marketCap: (profile.marketCapitalization || 0) * 1e6,
              marketCapRank: 0,
              totalVolume: 0,
              priceChange1h: null,
              priceChange24h: Math.round(changePercent * 100) / 100,
              priceChange7d: null,
              priceChange30d: null,
              sparkline: [],
              high24h: quote.h as number,
              low24h: quote.l as number,
            };
          } catch {
            return generateStockData(symbol, symbol);
          }
        })
      );
      return NextResponse.json(results);
    }

    // Fallback: use generated data
    const data = TOP_STOCKS.map(({ symbol, name }) =>
      generateStockData(symbol, name)
    );
    return NextResponse.json(data);
  } catch (error) {
    console.error("Failed to fetch stock data:", error);
    // Final fallback
    const data = TOP_STOCKS.map(({ symbol, name }) =>
      generateStockData(symbol, name)
    );
    return NextResponse.json(data);
  }
}
