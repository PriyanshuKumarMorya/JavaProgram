import { NextResponse } from "next/server";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ symbol: string }> }
) {
  const { symbol } = await params;

  try {
    const finnhubKey = process.env.FINNHUB_API_KEY;

    if (finnhubKey) {
      const now = Math.floor(Date.now() / 1000);
      const thirtyDaysAgo = now - 30 * 24 * 60 * 60;

      const res = await fetch(
        `https://finnhub.io/api/v1/stock/candle?symbol=${symbol}&resolution=60&from=${thirtyDaysAgo}&to=${now}&token=${finnhubKey}`
      );
      const data = await res.json();

      if (data.s === "ok") {
        const prices = data.t.map((timestamp: number, i: number) => ({
          timestamp: timestamp * 1000,
          price: data.c[i],
          date: new Date(timestamp * 1000).toISOString(),
        }));
        return NextResponse.json({ symbol, prices });
      }
    }

    // Generate historical data
    const seed = symbol.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
    const pseudoRandom = (min: number, max: number, offset = 0) => {
      const x = Math.sin(seed + offset) * 10000;
      const r = x - Math.floor(x);
      return min + r * (max - min);
    };

    const basePrice = pseudoRandom(80, 500);
    const prices: { timestamp: number; price: number; date: string }[] = [];
    let price = basePrice * pseudoRandom(0.7, 1.3, 100);

    const now = Date.now();
    const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
    const points = 720; // ~1 point per hour for 30 days

    for (let i = 0; i < points; i++) {
      const timestamp = now - thirtyDaysMs + (thirtyDaysMs / points) * i;
      price = price * (1 + pseudoRandom(-0.01, 0.01, i));
      prices.push({
        timestamp,
        price: Math.round(price * 100) / 100,
        date: new Date(timestamp).toISOString(),
      });
    }

    return NextResponse.json({ symbol, prices });
  } catch (error) {
    console.error(`Failed to fetch history for ${symbol}:`, error);
    return NextResponse.json(
      { error: "Failed to fetch stock history" },
      { status: 500 }
    );
  }
}
