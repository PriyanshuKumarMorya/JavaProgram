import { NextRequest, NextResponse } from "next/server";
import { readFileSync, existsSync } from "fs";
import path from "path";
import { SYNC_FILES } from "@/lib/syncFiles";

export const dynamic = "force-dynamic";

/**
 * Serves exact project file contents for the /sync page.
 * Only whitelisted paths are allowed.
 */
export async function GET(req: NextRequest) {
  const file = req.nextUrl.searchParams.get("file") ?? "";

  if (!SYNC_FILES.includes(file)) {
    return NextResponse.json({ error: "File not in whitelist" }, { status: 403 });
  }

  const full = path.join(process.cwd(), file);
  if (!existsSync(full)) {
    return NextResponse.json({ error: "File missing on server" }, { status: 404 });
  }

  try {
    const content = readFileSync(full, "utf8");
    const filename = file.split("/").pop() ?? "file.txt";
    return new NextResponse(content, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return NextResponse.json({ error: "Read failed" }, { status: 500 });
  }
}
