export default function SetupGuide() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <div className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-bold text-white mb-2">📘 IntelliJ IDEA Setup Guide</h1>
        <p className="text-slate-400 mb-10">
          Step-by-step instructions to get the MarketAI fullstack project running
        </p>

        {steps.map((step, i) => (
          <StepCard key={i} number={i + 1} {...step} />
        ))}
      </div>
    </div>
  );
}

interface StepData {
  title: string;
  description: string;
  action: string;
  detail: string;
  tip?: string;
  code?: { lang: string; content: string };
}

const steps: StepData[] = [
  {
    title: "Open the Project in IntelliJ IDEA",
    description: "Launch IntelliJ IDEA and open the marketai root folder.",
    action: "File → Open → Select the 'marketai' folder",
    detail:
      "IntelliJ will auto-detect both the Next.js frontend (package.json) and the Spring Boot backend (pom.xml). You will see both modules in the Project tool window.",
    tip: "Make sure you have IntelliJ IDEA Ultimate for best Spring Boot support. Community Edition works for the frontend but lacks some Java features.",
  },
  {
    title: "Import Maven Backend Dependencies",
    description: "Load the Spring Boot project via Maven.",
    action: "Right-click backend/pom.xml → Add as Maven Project",
    detail:
      "A notification banner will appear: 'Maven build scripts found'. Click Load. IntelliJ downloads Spring Boot, JPA, PostgreSQL driver, Lombok, and Jackson automatically. Wait for the progress bar to finish.",
    tip: 'If the Maven tool window is not visible: View → Tool Windows → Maven',
    code: {
      lang: "xml",
      content: `<!-- Key dependencies in backend/pom.xml -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
</dependency>`,
    },
  },
  {
    title: "Install Frontend Dependencies",
    description: "Run npm install for the Next.js frontend.",
    action: "Terminal (Alt+F12) → npm install",
    detail:
      "Installs Next.js, React, Recharts (charts), Tailwind CSS, Drizzle ORM, and TypeScript. You will see a node_modules folder appear in the project tree after completion.",
    tip: "Use IntelliJ's built-in terminal (Alt+F12) to keep everything in one window.",
    code: {
      lang: "bash",
      content: `# Run from the project root
npm install

# Installs: next, react, recharts, tailwindcss, drizzle-orm, typescript, etc.`,
    },
  },
  {
    title: "Configure PostgreSQL Database",
    description: "Set up the PostgreSQL connection for both backends.",
    action: "Create database 'app_db' in PostgreSQL, then verify connection settings",
    detail:
      "Spring Boot reads from backend/src/main/resources/application.properties. Next.js reads from .env in the root. Both point to the same PostgreSQL instance.",
    tip: "Use IntelliJ's Database tool window (View → Tool Windows → Database) to connect and browse tables.",
    code: {
      lang: "properties",
      content: `# backend/src/main/resources/application.properties
spring.datasource.url=jdbc:postgresql://localhost:5432/app_db
spring.datasource.username=postgres
spring.datasource.password=postgres
spring.jpa.hibernate.ddl-auto=update`,
    },
  },
  {
    title: "Start Spring Boot Backend",
    description: "Launch the Spring Boot application on port 8080.",
    action: "Open MarketAiApplication.java → Click green ▶ play button in gutter",
    detail:
      "Spring Boot starts and JPA auto-creates the predictions and watchlist tables. You should see: 'Started MarketAiApplication in X seconds'. API is now available at http://localhost:8080/api/.",
    tip: "Create a Run Configuration: Run → Edit Configurations → + → Spring Boot → Main class: MarketAiApplication",
    code: {
      lang: "java",
      content: `@SpringBootApplication
public class MarketAiApplication {
    public static void main(String[] args) {
        SpringApplication.run(MarketAiApplication.class, args);
    }
}
// Tables auto-created: predictions, watchlist`,
    },
  },
  {
    title: "Start Next.js Frontend",
    description: "Launch the React frontend on port 3000.",
    action: "npm run dev (from project root)",
    detail:
      "Next.js starts on http://localhost:3000. When SPRING_BOOT_URL is set, all /api/* requests are proxied to Spring Boot on port 8080. If Spring Boot is not running, Next.js falls back to its own API routes.",
    tip: "Add a 'npm' Run Configuration for the dev script, then you can start both Spring Boot and Next.js with one click from the Services tool window.",
    code: {
      lang: "bash",
      content: `# Start the frontend
npm run dev
# → http://localhost:3000

# Optional: enable Spring Boot proxy
export SPRING_BOOT_URL=http://localhost:8080`,
    },
  },
  {
    title: "Configure API Proxy (next.config.ts)",
    description: "Understand how Next.js routes API calls to Spring Boot.",
    action: "Review next.config.ts → rewrites() function",
    detail:
      "When SPRING_BOOT_URL is set, Next.js acts as a reverse proxy, forwarding /api/* requests to Spring Boot. Without it, Next.js uses its own API route handlers as fallback.",
    tip: "In production, you can place both behind Nginx — no proxy needed in Next.js config.",
    code: {
      lang: "typescript",
      content: `// next.config.ts
const nextConfig: NextConfig = {
  async rewrites() {
    if (process.env.SPRING_BOOT_URL) {
      return [{
        source: '/api/:path*',
        destination: \`\${process.env.SPRING_BOOT_URL}/api/:path*\`,
      }];
    }
    return [];
  },
};`,
    },
  },
  {
    title: "Explore the REST API Endpoints",
    description: "Browse all backend API endpoints from the controllers.",
    action: "View → Tool Windows → Endpoints",
    detail:
      "IntelliJ lists all @RestController endpoints with HTTP methods and paths. You can test them directly with the built-in HTTP client.",
    tip: "Use the .http scratch files in IntelliJ to test API endpoints without leaving the IDE.",
    code: {
      lang: "http",
      content: `### Test the API endpoints
GET http://localhost:8080/api/market/crypto
GET http://localhost:8080/api/market/stocks
POST http://localhost:8080/api/predict
Content-Type: application/json

{
  "symbol": "BTC",
  "assetType": "crypto",
  "prices": [{"timestamp": 1700000000000, "price": 42000}],
  "timeframe": 24
}`,
    },
  },
  {
    title: "Understand the AI Prediction Engine",
    description: "Explore how the ensemble ML model predicts prices.",
    action: "Open backend/.../service/PredictionService.java",
    detail:
      "The predict() method uses 4 techniques: (1) Linear Regression on recent prices, (2) EMA/MACD momentum signals, (3) RSI oscillator for overbought/oversold, (4) Volatility-adjusted noise. Results are weighted and combined into a final prediction with confidence score.",
    tip: "Each prediction is persisted to PostgreSQL. View history at GET /api/predict.",
    code: {
      lang: "java",
      content: `// Ensemble Weights in PredictionService.java
double predicted = regressionPred * 0.45   // Linear Regression
                 + momentumPred  * 0.30    // EMA Momentum
                 + rsiPred       * 0.15    // RSI Oscillator
                 + noiseTerm     * 0.10;   // Volatility Noise

// Confidence = weighted combination of:
//   - R² (regression fit quality)
//   - Inverse volatility (lower vol = more confident)
//   - Data quantity (more data = more confident)`,
    },
  },
  {
    title: "Open the Dashboard in Browser",
    description: "View the live MarketAI dashboard.",
    action: "Open http://localhost:3000 in your browser",
    detail:
      "You should see: Cryptocurrency/Stocks tabs, price cards with sparklines, interactive charts (1D/7D/30D), AI predictions with confidence scores, technical indicators (RSI, volatility), and a personal watchlist. Data auto-refreshes every 60 seconds.",
    tip: "Use Chrome DevTools (F12) → Network tab to see all API requests flowing between frontend and backend.",
  },
];

function StepCard({ number, title, description, action, detail, tip, code }: StepData & { number: number }) {
  return (
    <div className="mb-8 bg-slate-900/60 border border-white/10 rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-4 p-5 border-b border-white/5">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg flex-shrink-0 shadow-lg shadow-purple-500/20">
          {number}
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <p className="text-sm text-slate-400">{description}</p>
        </div>
      </div>

      {/* Body */}
      <div className="p-5 space-y-4">
        {/* Action */}
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
          <p className="text-xs text-blue-400 uppercase tracking-wider font-semibold mb-1">
            🎯 Action
          </p>
          <p className="text-white font-medium">{action}</p>
        </div>

        {/* Detail */}
        <p className="text-sm text-slate-300 leading-relaxed">{detail}</p>

        {/* Code */}
        {code && (
          <div className="bg-slate-950 border border-white/10 rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-white/5">
              <span className="text-xs text-slate-500 uppercase">{code.lang}</span>
              <span className="text-xs text-slate-600">📋 {code.content.split("\n").length} lines</span>
            </div>
            <pre className="p-4 text-sm text-slate-300 overflow-x-auto font-mono leading-relaxed">
              <code>{code.content}</code>
            </pre>
          </div>
        )}

        {/* Tip */}
        {tip && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
            <p className="text-xs text-yellow-400 uppercase tracking-wider font-semibold mb-1">
              💡 Pro Tip
            </p>
            <p className="text-sm text-yellow-300/80">{tip}</p>
          </div>
        )}
      </div>
    </div>
  );
}
