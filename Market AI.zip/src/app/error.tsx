"use client";

import Link from "next/link";

/**
 * Friendly runtime error boundary.
 * Most crashes in local dev are caused by out-of-sync / truncated files,
 * so we show recovery steps + a link to the Sync Center instead of a
 * scary stack trace.
 */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 flex items-center justify-center p-6">
      <div className="max-w-lg w-full rounded-2xl border border-red-500/30 bg-slate-900 p-6">
        <p className="text-2xl">🧯</p>
        <h1 className="mt-2 text-xl font-bold text-white">Oops — the page crashed</h1>
        <p className="mt-2 text-sm text-slate-400 leading-relaxed">
          This almost always means some project files on your computer are{" "}
          <b className="text-red-300">out of sync or truncated</b> (a component import came
          back undefined).
        </p>

        <div className="mt-4 rounded-xl border border-white/10 bg-slate-950/60 p-4 text-xs text-slate-300 space-y-2">
          <p className="font-semibold text-white">Fix in 2 minutes:</p>
          <ol className="list-decimal ml-4 space-y-1.5">
            <li>
              Open the{" "}
              <Link href="/sync" className="text-indigo-400 underline font-semibold">
                🔄 Sync Center
              </Link>{" "}
              (this link works even when the dashboard is broken).
            </li>
            <li>
              Click <b>📦 Download ZIP</b> → Extract-All over your project folder →{" "}
              <b>Replace files</b>.
            </li>
            <li>
              Verify: <code className="bg-slate-800 px-1 rounded">MarketDashboard.tsx</code> must
              be <b>992 lines</b> (VS Code shows line count bottom-right).
            </li>
            <li>Restart `npm run dev` and reload.</li>
          </ol>
        </div>

        <details className="mt-3 text-[11px] text-slate-500">
          <summary className="cursor-pointer">Technical detail</summary>
          <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap rounded bg-slate-950 p-2 text-[10px] text-red-300/80">
            {error.message}
          </pre>
        </details>

        <div className="mt-4 flex gap-2">
          <button
            onClick={reset}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
          >
            Try again
          </button>
          <Link
            href="/sync"
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold"
          >
            Open Sync Center
          </Link>
        </div>
      </div>
    </div>
  );
}
