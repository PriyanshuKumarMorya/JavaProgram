"use client";

import { useState } from "react";
import Link from "next/link";
import { loginUser, registerUser } from "@/lib/pro";

export default function LoginPage() {
  const [mode, setMode] = useState<"signin" | "register">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (mode === "register" && pass !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    const res =
      mode === "signin" ? loginUser(email, pass) : registerUser(name, email, pass);
    if (!res.ok) {
      setError(res.error ?? "Something went wrong.");
      return;
    }
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <span className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </span>
          <span className="text-2xl font-bold text-white">
            Market<span className="text-blue-400">AI</span>
          </span>
        </div>

        <div className="rounded-2xl border border-white/10 bg-slate-900/70 backdrop-blur p-6 shadow-2xl shadow-black/40">
          {/* Tabs */}
          <div className="flex gap-1 bg-slate-800/80 rounded-lg p-1 mb-6">
            <button
              onClick={() => { setMode("signin"); setError(""); }}
              className={`flex-1 py-2 rounded-md text-sm font-semibold transition-colors ${
                mode === "signin" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => { setMode("register"); setError(""); }}
              className={`flex-1 py-2 rounded-md text-sm font-semibold transition-colors ${
                mode === "register" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              Create Account
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <label className="block">
                <span className="text-xs text-slate-400">Full name</span>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Priyanshu Kumar"
                  className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
                />
              </label>
            )}
            <label className="block">
              <span className="text-xs text-slate-400">Email</span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
              />
            </label>
            <label className="block">
              <span className="text-xs text-slate-400">Password</span>
              <input
                type="password"
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                placeholder="••••••••"
                className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
              />
            </label>
            {mode === "register" && (
              <label className="block">
                <span className="text-xs text-slate-400">Confirm password</span>
                <input
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
                />
              </label>
            )}

            {error && (
              <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/25 transition-colors"
            >
              {mode === "signin" ? "Sign In →" : "Create Account →"}
            </button>
          </form>

          <p className="text-[10px] text-slate-600 text-center mt-4 leading-relaxed">
            Local demo authentication — your account is stored only in this browser.
            <br />
            <Link href="/" className="text-indigo-400 hover:text-indigo-300">
              ← Back to dashboard (no login required)
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
