"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  Tooltip,
} from "recharts";
import { ProShell, PageTitle } from "@/components/ProShell";
import {
  loadLS,
  saveLS,
  LS,
  DEFAULT_PORTFOLIO,
  riskScore,
  sensitivity,
  shockLevel,
  stdevReturns,
  type Position,
} from "@/lib/pro";

const COLORS = ["#f59e0b", "#38bdf8", "#a78bfa", "#34d399", "#f472b6", "#fb7185"];

interface MarketAsset {
  symbol: string;
  currentPrice: number;
  sparkline: number[];
  priceChange24h: number | null;
}

export default function PortfolioPage() {
  const [positions, setPositions] = useState<Position[]>(() =>
    loadLS<Position[]>(LS.portfolio, DEFAULT_PORTFOLIO)
  );
  const [market, setMarket] = useState<Record<string, MarketAsset>>({});
  const [loaded, setLoaded] = useState(false);

  // What-If Scenario Simulator state
  const [scMode, setScMode] = useState<"invest" | "shock">("shock");
  const [scSym, setScSym] = useState("BTC");
  const [scAmount, setScAmount] = useState(20000);
  const [scMove, setScMove] = useState(10);
  const [scShock, setScShock] = useState(-10);

  useEffect(() => {
    (async () => {
      try {
        const [c, s] = await Promise.all([
          fetch("/api/market/crypto").then((r) => r.json()),
          fetch("/api/market/stocks").then((r) => r.json()),
        ]);
        const map: Record<string, MarketAsset> = {};
        [...c, ...s].forEach((a: MarketAsset) => (map[a.symbol] = a));
        setMarket(map);
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const rows = useMemo(
    () =>
      positions.map((p) => {
        const m = market[p.symbol];
        const price = m?.currentPrice ?? p.avgBuy;
        const value = price * p.qty;
        const cost = p.avgBuy * p.qty;
        const pnl = value - cost;
        const pnlPct = cost ? (pnl / cost) * 100 : 0;
        const risk = m ? riskScore(m.sparkline ?? [], m.priceChange24h ?? 0) : null;
        return { ...p, price, value, cost, pnl, pnlPct, risk };
      }),
    [positions, market]
  );

  const totalValue = rows.reduce((s, r) => s + r.value, 0);
  const totalCost = rows.reduce((s, r) => s + r.cost, 0);
  const totalPnl = totalValue - totalCost;
  const totalPnlPct = totalCost ? (totalPnl / totalCost) * 100 : 0;
  const winRate = rows.length
    ? (rows.filter((r) => r.pnl > 0).length / rows.length) * 100
    : 0;
  const avgRisk = rows.length
    ? Math.round(rows.reduce((s, r) => s + (r.risk?.score ?? 0), 0) / rows.length)
    : 0;

  // Equity curve (approx from weighted sparklines)
  const equity = useMemo(() => {
    const series = rows
      .map((r) => {
        const sp = market[r.symbol]?.sparkline ?? [];
        if (sp.length < 10) return null;
        const base = sp[0] || 1;
        return sp.map((v) => (v / base) * r.value);
      })
      .filter(Boolean) as number[][];
    if (series.length === 0) return [];
    const minLen = Math.min(...series.map((s) => s.length));
    const out: { i: number; v: number }[] = [];
    for (let i = 0; i < minLen; i += Math.max(1, Math.floor(minLen / 60))) {
      out.push({ i, v: Math.round(series.reduce((s, arr) => s + arr[i], 0)) });
    }
    return out;
  }, [rows, market]);

  // AI Coach feedback
  const coach = useMemo(() => {
    const tips: string[] = [];
    const maxPos = rows.reduce((a, b) => (b.value > a.value ? b : a), rows[0]);
    if (maxPos && totalValue > 0 && maxPos.value / totalValue > 0.35)
      tips.push(
        `⚠️ Concentration risk: ${maxPos.symbol} is ${((maxPos.value / totalValue) * 100).toFixed(0)}% of your portfolio. Consider trimming below 30%.`
      );
    if (avgRisk > 60)
      tips.push("⚠️ Portfolio risk score is High. Hedge with lower-volatility assets or reduce size.");
    else if (avgRisk < 35)
      tips.push("✅ Portfolio risk is Low — you have room for a small higher-conviction position.");
    if (totalPnl > 0)
      tips.push(`✅ Overall P&L is positive (+$${totalPnl.toFixed(0)}). Let winners run but trail stops.`);
    else tips.push("📉 Portfolio is underwater. Review losers against their theses — cut or average with a plan.");
    if (winRate >= 60) tips.push(`🏆 Win rate ${winRate.toFixed(0)}% — your entries are working.`);
    tips.push("📘 Rule reminder: never risk more than 2% of this portfolio on a single new trade.");
    return tips;
  }, [rows, totalValue, totalPnl, avgRisk, winRate]);

  const remove = (symbol: string) => {
    const next = positions.filter((p) => p.symbol !== symbol);
    setPositions(next);
    saveLS(LS.portfolio, next);
  };

  return (
    <ProShell active="portfolio">
      <PageTitle
        icon="📊"
        title="Portfolio Analytics"
        subtitle="Live value, P&L, allocation, risk and your AI Trading Coach"
      />

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card label="Total value" value={`$${totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} />
        <Card
          label="Unrealized P&L"
          value={`${totalPnl >= 0 ? "+" : ""}$${totalPnl.toFixed(0)} (${totalPnlPct >= 0 ? "+" : ""}${totalPnlPct.toFixed(2)}%)`}
          tone={totalPnl >= 0 ? "text-emerald-400" : "text-red-400"}
        />
        <Card label="Win rate" value={`${winRate.toFixed(0)}%`} tone={winRate >= 50 ? "text-emerald-400" : "text-amber-400"} />
        <Card
          label="Portfolio risk"
          value={`${avgRisk}/100 · ${avgRisk < 35 ? "Low" : avgRisk < 65 ? "Medium" : "High"}`}
          tone={avgRisk < 35 ? "text-emerald-400" : avgRisk < 65 ? "text-amber-400" : "text-red-400"}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-6">
        {/* Equity curve */}
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <p className="text-sm font-semibold text-white mb-3">Equity curve (30d, approx)</p>
          <div className="h-[220px]">
            {equity.length > 1 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equity}>
                  <defs>
                    <linearGradient id="eq" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#818cf8" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#818cf8" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1e293b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, fontSize: 12 }}
                    formatter={(v) => [`$${Number(v).toLocaleString()}`, "Value"]}
                  />
                  <Area type="monotone" dataKey="v" stroke="#818cf8" strokeWidth={2} fill="url(#eq)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-600">
                {loaded ? "No data" : "Loading..."}
              </div>
            )}
          </div>
        </div>

        {/* Allocation */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <p className="text-sm font-semibold text-white mb-3">Asset allocation</p>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={rows} dataKey="value" nameKey="symbol" innerRadius={45} outerRadius={70} paddingAngle={3}>
                  {rows.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e293b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, fontSize: 12 }}
                  formatter={(v) => `$${Number(v).toLocaleString()}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {rows.map((r, i) => (
              <span key={r.symbol} className="text-[10px] text-slate-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                {r.symbol} {totalValue ? ((r.value / totalValue) * 100).toFixed(0) : 0}%
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Positions table */}
        <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-slate-900/60 p-5 overflow-x-auto">
          <p className="text-sm font-semibold text-white mb-3">Positions</p>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-slate-500">
                <th className="pb-2">Asset</th>
                <th className="pb-2">Qty</th>
                <th className="pb-2">Avg buy</th>
                <th className="pb-2">Price</th>
                <th className="pb-2">Value</th>
                <th className="pb-2">P&L</th>
                <th className="pb-2">Risk</th>
                <th className="pb-2"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.symbol} className="border-t border-white/5">
                  <td className="py-2.5">
                    <Link href={`/trade/${r.symbol}`} className="font-semibold text-white hover:text-indigo-300">
                      {r.symbol}
                    </Link>
                    <span className="block text-[10px] text-slate-500">{r.name}</span>
                  </td>
                  <td className="py-2.5 tabular-nums">{r.qty}</td>
                  <td className="py-2.5 tabular-nums">${r.avgBuy.toLocaleString()}</td>
                  <td className="py-2.5 tabular-nums">${r.price.toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
                  <td className="py-2.5 tabular-nums">${r.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className={`py-2.5 tabular-nums ${r.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {r.pnl >= 0 ? "+" : ""}${r.pnl.toFixed(0)} ({r.pnlPct.toFixed(1)}%)
                  </td>
                  <td className="py-2.5">
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        (r.risk?.score ?? 0) < 35
                          ? "bg-emerald-500/10 text-emerald-400"
                          : (r.risk?.score ?? 0) < 65
                          ? "bg-amber-500/10 text-amber-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                    >
                      {r.risk?.score ?? "—"}
                    </span>
                  </td>
                  <td className="py-2.5 text-right">
                    <button onClick={() => remove(r.symbol)} className="text-slate-600 hover:text-red-400 text-xs">
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* AI Coach */}
        <div className="rounded-2xl border border-purple-500/20 bg-purple-500/5 p-5">
          <p className="text-sm font-semibold text-white mb-3">🧠 AI Trading Coach</p>
          <ul className="space-y-2.5">
            {coach.map((t, i) => (
              <li key={i} className="text-xs text-slate-300 leading-relaxed bg-slate-900/40 rounded-lg p-2.5 border border-white/5">
                {t}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* ── What-If Scenario Simulator ── */}
      <ScenarioSimulator
        rows={rows}
        market={market}
        totalValue={totalValue}
        mode={scMode}
        setMode={setScMode}
        scSym={scSym}
        setScSym={setScSym}
        scAmount={scAmount}
        setScAmount={setScAmount}
        scMove={scMove}
        setScMove={setScMove}
        scShock={scShock}
        setScShock={setScShock}
      />
    </ProShell>
  );
}

/* ═══════════════════════════════════════════════════════════════
   What-If Scenario Simulator
   ═══════════════════════════════════════════════════════════════ */
function ScenarioSimulator(props: {
  rows: { symbol: string; value: number }[];
  market: Record<string, { currentPrice: number; sparkline: number[] }>;
  totalValue: number;
  mode: "invest" | "shock";
  setMode: (m: "invest" | "shock") => void;
  scSym: string;
  setScSym: (s: string) => void;
  scAmount: number;
  setScAmount: (n: number) => void;
  scMove: number;
  setScMove: (n: number) => void;
  scShock: number;
  setScShock: (n: number) => void;
}) {
  const {
    rows, market, totalValue, mode, setMode,
    scSym, setScSym, scAmount, setScAmount, scMove, setScMove, scShock, setScShock,
  } = props;

  // Single investment scenario
  const scPrice = market[scSym]?.currentPrice ?? 0;
  const investProfit = (scAmount * scMove) / 100;
  const investNew = scAmount + investProfit;
  const investLevel = shockLevel(scMove);

  // Portfolio shock scenario (beta-weighted per position)
  let impact = 0;
  rows.forEach((r) => {
    const sp = market[r.symbol]?.sparkline ?? [];
    const sens = sensitivity(stdevReturns(sp));
    impact += r.value * (scShock / 100) * sens;
  });
  const newTotal = totalValue + impact;
  const impactPct = totalValue ? (impact / totalValue) * 100 : 0;
  const level = shockLevel(impactPct);

  const levelTone = (l: string) =>
    l === "LOW" ? "text-emerald-400 bg-emerald-500/10" : l === "MEDIUM" ? "text-amber-400 bg-amber-500/10" : "text-red-400 bg-red-500/10";

  return (
    <div className="mt-6 rounded-2xl border border-indigo-500/20 bg-indigo-500/5 p-5">
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
        <div>
          <p className="text-sm font-semibold text-white">🔮 What-If Scenario Simulator</p>
          <p className="text-xs text-slate-400 mt-0.5">
            Explore "what happens if..." — estimates, not guarantees.
          </p>
        </div>
        <div className="flex gap-1 bg-slate-900/60 rounded-lg p-1">
          <button
            onClick={() => setMode("shock")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md ${mode === "shock" ? "bg-indigo-600 text-white" : "text-slate-400"}`}
          >
            Market shock
          </button>
          <button
            onClick={() => setMode("invest")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md ${mode === "invest" ? "bg-indigo-600 text-white" : "text-slate-400"}`}
          >
            Single investment
          </button>
        </div>
      </div>

      {mode === "shock" ? (
        <>
          <label className="block mb-4">
            <span className="text-xs text-slate-400">
              Market moves by{" "}
              <span className={`font-bold ${scShock >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                {scShock > 0 ? "+" : ""}{scShock}%
              </span>
            </span>
            <input
              type="range"
              min={-30}
              max={30}
              step={1}
              value={scShock}
              onChange={(e) => setScShock(Number(e.target.value))}
              className="w-full mt-2 accent-indigo-500"
            />
            <div className="flex justify-between text-[10px] text-slate-600">
              <span>-30% crash</span><span>0</span><span>+30% rally</span>
            </div>
          </label>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <ScOut label="Current portfolio" value={`$${totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} tone="text-white" />
            <ScOut
              label="Estimated impact"
              value={`${impact >= 0 ? "+" : "-"}$${Math.abs(impact).toLocaleString(undefined, { maximumFractionDigits: 0 })} (${impactPct >= 0 ? "+" : ""}${impactPct.toFixed(1)}%)`}
              tone={impact >= 0 ? "text-emerald-400" : "text-red-400"}
            />
            <ScOut label="New estimated value" value={`$${newTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} tone="text-white" />
            <div className="bg-slate-950/50 border border-white/5 rounded-xl p-3">
              <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Risk level</p>
              <p className={`mt-1 text-lg font-extrabold px-2 py-0.5 rounded inline-block ${levelTone(level)}`}>{level}</p>
            </div>
          </div>
          <p className="text-[11px] text-slate-500 mt-3">
            Impact is beta-weighted: high-volatility positions (crypto) move more than stable ones.
          </p>
        </>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            <label className="block">
              <span className="text-xs text-slate-400">Asset</span>
              <select
                value={scSym}
                onChange={(e) => setScSym(e.target.value)}
                className="mt-1 w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
              >
                {Object.keys(market).map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-xs text-slate-400">Invest amount ($)</span>
              <input
                type="number"
                value={scAmount}
                onChange={(e) => setScAmount(Number(e.target.value))}
                className="mt-1 w-full bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
              />
            </label>
            <label className="block">
              <span className="text-xs text-slate-400">
                Price change:{" "}
                <span className={`font-bold ${scMove >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {scMove > 0 ? "+" : ""}{scMove}%
                </span>
              </span>
              <input
                type="range"
                min={-50}
                max={50}
                step={1}
                value={scMove}
                onChange={(e) => setScMove(Number(e.target.value))}
                className="w-full mt-3 accent-indigo-500"
              />
            </label>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <ScOut label="You invest" value={`$${scAmount.toLocaleString()}`} tone="text-white" />
            <ScOut
              label={investProfit >= 0 ? "Estimated profit" : "Estimated loss"}
              value={`${investProfit >= 0 ? "+" : "-"}$${Math.abs(investProfit).toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
              tone={investProfit >= 0 ? "text-emerald-400" : "text-red-400"}
            />
            <ScOut label="New position value" value={`$${investNew.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} tone="text-white" />
            <div className="bg-slate-950/50 border border-white/5 rounded-xl p-3">
              <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Risk level</p>
              <p className={`mt-1 text-lg font-extrabold px-2 py-0.5 rounded inline-block ${levelTone(investLevel)}`}>{investLevel}</p>
            </div>
          </div>
          {scPrice > 0 && (
            <p className="text-[11px] text-slate-500 mt-3">
              At ${scPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })} you'd get ≈{" "}
              {(scAmount / scPrice).toFixed(scPrice > 100 ? 2 : 4)} units of {scSym}.
            </p>
          )}
        </>
      )}
    </div>
  );
}

function ScOut({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="bg-slate-950/50 border border-white/5 rounded-xl p-3">
      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">{label}</p>
      <p className={`mt-1 text-lg font-extrabold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}

function Card({ label, value, tone = "text-white" }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
      <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold">{label}</p>
      <p className={`mt-1.5 text-xl font-extrabold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}
