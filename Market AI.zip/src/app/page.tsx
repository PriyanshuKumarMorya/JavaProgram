import type { ComponentType } from "react";
import Link from "next/link";
import { MarketDashboard } from "@/components/MarketDashboard";

export const dynamic = "force-dynamic";

export default function HomePage() {
  // Self-heal: if the local MarketDashboard export is missing (out-of-sync
  // or truncated file), show recovery steps instead of a raw crash.
  const MD = MarketDashboard as unknown as ComponentType | null | undefined;
  if (!MD) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-200 flex items-center justify-center p-6">
        <div className="max-w-lg w-full rounded-2xl border border-amber-500/30 bg-slate-900 p-6">
          <p className="text-2xl">🔄</p>
          <h1 className="mt-2 text-xl font-bold text-white">Files out of sync</h1>
          <p className="mt-2 text-sm text-slate-400 leading-relaxed">
            Your local <code className="bg-slate-800 px-1 rounded">MarketDashboard.tsx</code> is
            missing its component export — it was likely truncated while copying.
          </p>
          <ol className="mt-4 list-decimal ml-5 text-sm text-slate-300 space-y-2">
            <li>
              Open the{" "}
              <Link href="/sync" className="text-indigo-400 underline font-semibold">
                🔄 Sync Center
              </Link>
              .
            </li>
            <li>
              Click <b>📦 Download ZIP</b>, extract over your project folder, and choose{" "}
              <b>Replace files</b>.
            </li>
            <li>Restart `npm run dev`.</li>
          </ol>
          <p className="mt-4 text-xs text-slate-500">
            Expected: MarketDashboard.tsx = 992 lines · ProShell.tsx = 364 lines · pro.ts = 658
            lines.
          </p>
        </div>
      </div>
    );
  }
  return <MD />;
}
