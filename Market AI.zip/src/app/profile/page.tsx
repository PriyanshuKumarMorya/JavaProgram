"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ProShell, PageTitle } from "@/components/ProShell";
import type { FormEvent } from "react";
import {
  loadLS,
  saveLS,
  LS,
  DEFAULT_PORTFOLIO,
  currentUser,
  logoutUser,
  updateUserAccount,
  changePassword,
  loginUser,
  registerUser,
  type Position,
  type AlertItem,
  type NotificationItem,
} from "@/lib/pro";

interface Profile {
  name: string;
  email: string;
  age?: string;
  phone?: string;
  personality: "Conservative" | "Balanced" | "Aggressive";
  voiceReplies: boolean;
  autoRefresh: boolean;
  joinedAt: string;
}

const LS_PROFILE = "mai_profile";

const DEFAULT_PROFILE: Profile = {
  name: "Trader",
  email: "",
  personality: "Balanced",
  voiceReplies: true,
  autoRefresh: true,
  joinedAt: new Date().toISOString(),
};

const PERSONALITY = {
  Conservative: { risk: 1, color: "text-emerald-400", desc: "Capital preservation first. Small positions, wide margins." },
  Balanced: { risk: 2, color: "text-amber-400", desc: "Growth with controlled risk. Standard 2% rule." },
  Aggressive: { risk: 3, color: "text-red-400", desc: "High conviction, higher risk. Larger positions, tighter management." },
} as const;

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState(currentUser());
  const [profile, setProfile] = useState<Profile>(() => {
    const u = currentUser();
    const p = loadLS<Profile>(LS_PROFILE, DEFAULT_PROFILE);
    return u
      ? { ...p, name: u.name, email: u.email, age: u.age ?? "", phone: u.phone ?? "", joinedAt: u.joinedAt }
      : p;
  });
  const [saved, setSaved] = useState(false);

  // password change
  const [oldPass, setOldPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [passMsg, setPassMsg] = useState<{ ok: boolean; text: string } | null>(null);

  // inline login / register (shown when not signed in)
  const [authMode, setAuthMode] = useState<"signin" | "register">("signin");
  const [aName, setAName] = useState("");
  const [aEmail, setAEmail] = useState("");
  const [aPass, setAPass] = useState("");
  const [aConfirm, setAConfirm] = useState("");
  const [aError, setAError] = useState("");

  const [positions] = useState<Position[]>(() => loadLS<Position[]>(LS.portfolio, DEFAULT_PORTFOLIO));
  const [alerts] = useState<AlertItem[]>(() => loadLS<AlertItem[]>(LS.alerts, []));
  const [notifs] = useState<NotificationItem[]>(() => loadLS<NotificationItem[]>(LS.notifications, []));

  const [market, setMarket] = useState<Record<string, { currentPrice: number }>>({});
  useEffect(() => {
    (async () => {
      try {
        const [c, s] = await Promise.all([
          fetch("/api/market/crypto").then((r) => r.json()),
          fetch("/api/market/stocks").then((r) => r.json()),
        ]);
        const map: Record<string, { currentPrice: number }> = {};
        [...c, ...s].forEach((a: any) => (map[a.symbol] = { currentPrice: a.currentPrice }));
        setMarket(map);
      } catch { /* ignore */ }
    })();
  }, []);

  const portfolioValue = useMemo(
    () => positions.reduce((s, p) => s + (market[p.symbol]?.currentPrice ?? p.avgBuy) * p.qty, 0),
    [positions, market]
  );
  const portfolioCost = useMemo(() => positions.reduce((s, p) => s + p.avgBuy * p.qty, 0), [positions]);
  const pnl = portfolioValue - portfolioCost;
  const pnlPct = portfolioCost ? (pnl / portfolioCost) * 100 : 0;
  const signals = notifs.filter((n) => n.kind === "signal").length;

  const badges = [
    { icon: "🎯", label: "Getting Started", earned: true },
    { icon: "🏦", label: "Portfolio Builder", earned: positions.length > 0 },
    { icon: "💼", label: "Whale", earned: portfolioValue > 50000 },
    { icon: "📈", label: "In Profit", earned: pnl > 0 },
    { icon: "⏰", label: "Alert Master", earned: alerts.length > 0 },
    { icon: "🤖", label: "AI Explorer", earned: signals > 0 },
  ];
  const earnedCount = badges.filter((b) => b.earned).length;

  const save = () => {
    saveLS(LS_PROFILE, profile);
    if (user)
      updateUserAccount(user.id, {
        name: profile.name,
        email: profile.email,
        age: profile.age ?? "",
        phone: profile.phone ?? "",
      });
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const doChangePassword = () => {
    if (!user) return;
    if (newPass !== confirmPass) {
      setPassMsg({ ok: false, text: "New passwords do not match." });
      return;
    }
    const res = changePassword(user.id, oldPass, newPass);
    setPassMsg(res.ok ? { ok: true, text: "Password updated ✅" } : { ok: false, text: res.error ?? "Failed." });
    if (res.ok) { setOldPass(""); setNewPass(""); setConfirmPass(""); }
  };

  const doLogout = () => {
    logoutUser();
    setUser(null);
    router.push("/");
  };

  const doAuth = (e: FormEvent) => {
    e.preventDefault();
    setAError("");
    if (authMode === "register" && aPass !== aConfirm) {
      setAError("Passwords do not match.");
      return;
    }
    const res =
      authMode === "signin" ? loginUser(aEmail, aPass) : registerUser(aName, aEmail, aPass);
    if (!res.ok) {
      setAError(res.error ?? "Something went wrong.");
      return;
    }
    const u = res.user!;
    setUser(u);
    setProfile((p) => ({ ...p, name: u.name, email: u.email, joinedAt: u.joinedAt }));
  };

  const exportData = () => {
    const data = { profile, user: user ? { id: user.id, name: user.name, email: user.email, joinedAt: user.joinedAt } : null, portfolio: positions, alerts, notifications: notifs, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "marketai-data.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const resetAll = () => {
    if (!confirm("Delete ALL local MarketAI data (account, profile, portfolio, alerts, notifications)?")) return;
    Object.keys(localStorage).filter((k) => k.startsWith("mai_")).forEach((k) => localStorage.removeItem(k));
    location.href = "/";
  };

  /* ── Not logged in → inline login / register ── */
  if (!user) {
    return (
      <ProShell active="profile">
        <div className="max-w-md mx-auto mt-8 rounded-2xl border border-white/10 bg-slate-900/70 p-6">
          <div className="text-center mb-5">
            <span className="text-4xl">🔐</span>
            <h2 className="mt-2 text-xl font-bold text-white">Sign in to your Profile</h2>
            <p className="mt-1 text-xs text-slate-400">
              Local account — stored only in this browser.
            </p>
          </div>

          {/* tabs */}
          <div className="flex gap-1 bg-slate-800/80 rounded-lg p-1 mb-4">
            <button
              onClick={() => { setAuthMode("signin"); setAError(""); }}
              className={`flex-1 py-2 rounded-md text-sm font-semibold ${authMode === "signin" ? "bg-indigo-600 text-white" : "text-slate-400"}`}
            >
              Sign In
            </button>
            <button
              onClick={() => { setAuthMode("register"); setAError(""); }}
              className={`flex-1 py-2 rounded-md text-sm font-semibold ${authMode === "register" ? "bg-indigo-600 text-white" : "text-slate-400"}`}
            >
              Create Account
            </button>
          </div>

          <form onSubmit={doAuth} className="space-y-3">
            {authMode === "register" && (
              <input
                value={aName}
                onChange={(e) => setAName(e.target.value)}
                placeholder="Full name"
                className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
              />
            )}
            <input
              type="email"
              value={aEmail}
              onChange={(e) => setAEmail(e.target.value)}
              placeholder="Email"
              className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
            />
            <input
              type="password"
              value={aPass}
              onChange={(e) => setAPass(e.target.value)}
              placeholder="Password (≥ 6 chars)"
              className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
            />
            {authMode === "register" && (
              <input
                type="password"
                value={aConfirm}
                onChange={(e) => setAConfirm(e.target.value)}
                placeholder="Confirm password"
                className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500/60"
              />
            )}
            {aError && (
              <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{aError}</p>
            )}
            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
            >
              {authMode === "signin" ? "Sign In →" : "Create Account →"}
            </button>
          </form>

          <p className="mt-3 text-[10px] text-slate-600 text-center">
            The dashboard works without login too — auth is optional.
          </p>
        </div>
      </ProShell>
    );
  }

  const initials = user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase() || "U";
  const days = Math.max(1, Math.floor((Date.now() - new Date(user.joinedAt).getTime()) / 86400000));

  return (
    <ProShell active="profile">
      <PageTitle icon="👤" title="My Profile" subtitle="Account, identity, achievements, security and data controls" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* ── Account + identity ── */}
        <div className="space-y-5">
          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-2xl font-extrabold text-white shadow-lg shadow-purple-500/25">
                {initials}
              </div>
              <div className="min-w-0">
                <p className="text-lg font-bold text-white truncate">{user.name}</p>
                <p className="text-xs text-slate-400 truncate">{user.email}</p>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Member for {days} day{days > 1 ? "s" : ""} · ID {user.id.slice(0, 6)}
                </p>
              </div>
            </div>

            <div className="mt-5 space-y-3">
              <label className="block">
                <span className="text-xs text-slate-400">Full name</span>
                <input value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </label>
              <label className="block">
                <span className="text-xs text-slate-400">Email</span>
                <input value={profile.email} onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-xs text-slate-400">Age</span>
                  <input type="number" value={profile.age ?? ""} onChange={(e) => setProfile({ ...profile, age: e.target.value })}
                    className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-400">Phone</span>
                  <input value={profile.phone ?? ""} onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                </label>
              </div>
              <label className="block">
                <span className="text-xs text-slate-400">Trading personality</span>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {(Object.keys(PERSONALITY) as (keyof typeof PERSONALITY)[]).map((p) => (
                    <button key={p} onClick={() => setProfile({ ...profile, personality: p })}
                      className={`px-2 py-2 rounded-lg text-xs font-semibold ${profile.personality === p ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"}`}>
                      {p}
                    </button>
                  ))}
                </div>
              </label>
              <p className={`text-[11px] ${PERSONALITY[profile.personality].color}`}>
                {PERSONALITY[profile.personality].desc} Suggested risk: {PERSONALITY[profile.personality].risk}% per trade.
              </p>
              <button onClick={save} className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold">
                {saved ? "✅ Saved" : "Save profile"}
              </button>
            </div>
          </div>

          {/* Session / logout */}
          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">🔑 Session</p>
            <p className="text-xs text-slate-400 mb-3">
              Signed in as <span className="text-white font-semibold">{user.email}</span>
            </p>
            <button onClick={doLogout} className="w-full py-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 text-sm font-semibold">
              ⎋ Log out
            </button>
          </div>
        </div>

        {/* ── Stats + badges ── */}
        <div className="space-y-5">
          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">📊 Trading stats</p>
            <div className="grid grid-cols-2 gap-3">
              <Stat label="Portfolio value" value={`$${portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} />
              <Stat label="Unrealized P&L" value={`${pnl >= 0 ? "+" : ""}${pnlPct.toFixed(2)}%`} tone={pnl >= 0 ? "text-emerald-400" : "text-red-400"} />
              <Stat label="Positions" value={String(positions.length)} />
              <Stat label="Active alerts" value={String(alerts.length)} />
              <Stat label="AI signals saved" value={String(signals)} />
              <Stat label="Notifications" value={String(notifs.length)} />
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold text-white">🏆 Achievements</p>
              <span className="text-xs text-slate-500">{earnedCount}/{badges.length}</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {badges.map((b) => (
                <div key={b.label} className={`rounded-xl border p-2.5 text-center ${b.earned ? "border-amber-500/30 bg-amber-500/5" : "border-white/5 bg-slate-950/40 opacity-40 grayscale"}`}>
                  <span className="text-xl">{b.icon}</span>
                  <p className="text-[10px] font-semibold text-white mt-1 leading-tight">{b.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Security */}
          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">🛡️ Change password</p>
            <div className="space-y-2">
              <input type="password" placeholder="Current password" value={oldPass} onChange={(e) => setOldPass(e.target.value)}
                className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600" />
              <input type="password" placeholder="New password (≥ 6 chars)" value={newPass} onChange={(e) => setNewPass(e.target.value)}
                className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600" />
              <input type="password" placeholder="Confirm new password" value={confirmPass} onChange={(e) => setConfirmPass(e.target.value)}
                className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600" />
              {passMsg && (
                <p className={`text-xs ${passMsg.ok ? "text-emerald-400" : "text-red-400"}`}>{passMsg.text}</p>
              )}
              <button onClick={doChangePassword} className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold">
                Update password
              </button>
            </div>
          </div>
        </div>

        {/* ── Preferences + data ── */}
        <div className="space-y-5">
          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">⚙️ Preferences</p>
            <Toggle label="🔊 Voice replies from AI assistant" on={profile.voiceReplies} onChange={(v) => setProfile({ ...profile, voiceReplies: v })} />
            <Toggle label="🔄 Auto-refresh market data (60s)" on={profile.autoRefresh} onChange={(v) => setProfile({ ...profile, autoRefresh: v })} />
            <button onClick={save} className="mt-3 w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold">
              Save preferences
            </button>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">🕘 Recent activity</p>
            {notifs.length === 0 ? (
              <p className="text-xs text-slate-600">No activity yet.</p>
            ) : (
              <ul className="space-y-2">
                {notifs.slice(0, 5).map((n) => (
                  <li key={n.id} className="flex items-start gap-2">
                    <span className="text-sm leading-none mt-0.5">
                      {n.kind === "signal" ? "🤖" : n.kind === "alert" ? "⏰" : n.kind === "news" ? "📰" : "📊"}
                    </span>
                    <div className="min-w-0">
                      <p className="text-[11px] text-slate-300 truncate">{n.title}</p>
                      <p className="text-[10px] text-slate-600">{new Date(n.time).toLocaleString()}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">💾 Your data</p>
            <button onClick={exportData} className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold mb-2">
              ⬇️ Export all data (JSON)
            </button>
            <button onClick={resetAll} className="w-full py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 text-xs font-semibold">
              ⚠️ Reset all local data
            </button>
          </div>
        </div>
      </div>
    </ProShell>
  );
}

function Stat({ label, value, tone = "text-white" }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-xl border border-white/5 bg-slate-950/50 p-3">
      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">{label}</p>
      <p className={`mt-1 text-lg font-extrabold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}

function Toggle({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} className="w-full flex items-center justify-between py-2.5 border-b border-white/5 last:border-0">
      <span className="text-xs text-slate-300 text-left">{label}</span>
      <span className={`relative w-10 h-5 rounded-full transition-colors flex-shrink-0 ml-3 ${on ? "bg-indigo-600" : "bg-slate-700"}`}>
        <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${on ? "left-5" : "left-0.5"}`} />
      </span>
    </button>
  );
}
