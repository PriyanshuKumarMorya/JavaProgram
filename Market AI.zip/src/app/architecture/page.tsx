export default function ArchitecturePage() {
  const images = [
    {
      src: "/images/project-structure.png",
      alt: "Project Structure Overview",
      caption: "Fullstack Architecture: Next.js → Spring Boot → PostgreSQL",
    },
    {
      src: "/images/intellij-filetree.png",
      alt: "IntelliJ File Tree",
      caption: "IDE File Tree: Frontend (src/) + Backend (backend/)",
    },
    {
      src: "/images/step1-open-project.png",
      alt: "Step 1 — Open Project",
      caption: "Step 1: File → Open → Select marketai folder",
    },
    {
      src: "/images/step2-maven-import.png",
      alt: "Step 2 — Maven Import",
      caption: "Step 2: Right-click pom.xml → Add as Maven Project",
    },
    {
      src: "/images/step3-npm-install.png",
      alt: "Step 3 — npm install",
      caption: "Step 3: Terminal → npm install",
    },
    {
      src: "/images/step4-postgresql-setup.png",
      alt: "Step 4 — PostgreSQL",
      caption: "Step 4: Configure PostgreSQL database connection",
    },
    {
      src: "/images/step5-springboot-run.png",
      alt: "Step 5 — Run Spring Boot",
      caption: "Step 5: Click ▶ to start Spring Boot on port 8080",
    },
    {
      src: "/images/step6-nextjs-dev.png",
      alt: "Step 6 — Next.js Dev",
      caption: "Step 6: npm run dev → Frontend on port 3000",
    },
    {
      src: "/images/step7-proxy-config.png",
      alt: "Step 7 — Proxy Config",
      caption: "Step 7: next.config.ts proxies /api/* to Spring Boot",
    },
    {
      src: "/images/step8-explore-controllers.png",
      alt: "Step 8 — REST Controllers",
      caption: "Step 8: Explore all @RestController endpoints",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-3">
            🏗️ Project Architecture &amp; Setup
          </h1>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Visual walkthrough of the MarketAI fullstack project — from opening
            in IntelliJ IDEA to running both the Spring Boot backend and Next.js
            frontend.
          </p>
          <div className="flex items-center justify-center gap-3 mt-4">
            <a
              href="/setup-guide"
              className="px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg text-sm font-medium hover:bg-blue-500/30 transition-colors"
            >
              📘 Text Guide →
            </a>
            <a
              href="/"
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg text-sm font-medium hover:bg-slate-700 transition-colors"
            >
              📊 Dashboard →
            </a>
          </div>
        </div>

        {/* Image Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {images.map((img, i) => (
            <div
              key={i}
              className="bg-slate-900/60 border border-white/10 rounded-2xl overflow-hidden hover:border-white/20 transition-colors group"
            >
              <div className="aspect-video bg-slate-800 relative overflow-hidden">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-6 h-6 rounded-md bg-blue-500/20 text-blue-400 flex items-center justify-center text-xs font-bold">
                    {i + 1}
                  </span>
                  <h3 className="text-sm font-semibold text-white">{img.alt}</h3>
                </div>
                <p className="text-xs text-slate-500">{img.caption}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Architecture Diagram (CSS/SVG) */}
        <div className="mt-12 bg-slate-900/60 border border-white/10 rounded-2xl p-8">
          <h2 className="text-xl font-bold text-white mb-6 text-center">
            🔗 Request Flow
          </h2>
          <div className="flex flex-col items-center gap-0">
            {/* Browser */}
            <div className="bg-slate-800 border border-blue-500/30 rounded-xl px-6 py-3 text-center">
              <p className="text-sm font-semibold text-white">🌐 Browser (localhost:3000)</p>
              <p className="text-xs text-slate-500">React + Recharts + Tailwind</p>
            </div>
            <Arrow />
            {/* Next.js */}
            <div className="bg-slate-800 border border-purple-500/30 rounded-xl px-6 py-3 text-center">
              <p className="text-sm font-semibold text-white">⚡ Next.js Frontend</p>
              <p className="text-xs text-slate-500">fetch(&quot;/api/...&quot;) → rewrites proxy</p>
            </div>
            <Arrow />
            {/* Spring Boot */}
            <div className="bg-slate-800 border border-emerald-500/30 rounded-xl px-6 py-3 text-center">
              <p className="text-sm font-semibold text-white">☕ Spring Boot (localhost:8080)</p>
              <p className="text-xs text-slate-500">
                Controllers → Services → Repositories → JPA
              </p>
            </div>
            <Arrow />
            {/* PostgreSQL */}
            <div className="bg-slate-800 border border-orange-500/30 rounded-xl px-6 py-3 text-center">
              <p className="text-sm font-semibold text-white">🐘 PostgreSQL (localhost:5432)</p>
              <p className="text-xs text-slate-500">predictions + watchlist tables</p>
            </div>

            {/* Side APIs */}
            <div className="flex gap-6 mt-6">
              <div className="bg-slate-800 border border-yellow-500/20 rounded-xl px-4 py-2 text-center">
                <p className="text-xs font-semibold text-yellow-400">🪙 CoinGecko API</p>
                <p className="text-[10px] text-slate-500">Crypto market data</p>
              </div>
              <div className="bg-slate-800 border border-yellow-500/20 rounded-xl px-4 py-2 text-center">
                <p className="text-xs font-semibold text-yellow-400">📈 Finnhub API</p>
                <p className="text-[10px] text-slate-500">Stock market data</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Arrow() {
  return (
    <div className="flex flex-col items-center py-1">
      <div className="w-0.5 h-6 bg-gradient-to-b from-blue-500/50 to-purple-500/50" />
      <div className="w-2 h-2 border-r-2 border-b-2 border-purple-500/50 rotate-45 -mt-1" />
    </div>
  );
}
