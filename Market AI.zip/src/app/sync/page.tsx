"use client";

import { useMemo, useState } from "react";
import { ProShell, PageTitle } from "@/components/ProShell";
import { SYNC_FILES } from "@/lib/syncFiles";

/** Expected line counts — if a local file has fewer lines, it's truncated. */
const EXPECTED_LINES: [string, number][] = [
  ["src/components/MarketDashboard.tsx", 992],
  ["src/components/ProShell.tsx", 364],
  ["src/components/AIPrediction.tsx", 663],
  ["src/components/ProPanel.tsx", 419],
  ["src/components/CandleChart.tsx", 422],
  ["src/components/ChartModal.tsx", 206],
  ["src/components/PriceChart.tsx", 185],
  ["src/components/PriceCard.tsx", 111],
  ["src/components/WatchlistPanel.tsx", 143],
  ["src/components/TradingViewChart.tsx", 104],
  ["src/lib/pro.ts", 658],
  ["src/app/page.tsx", 7],
  ["src/app/portfolio/page.tsx", 499],
  ["src/app/trade/[symbol]/page.tsx", 418],
  ["src/app/markets/page.tsx", 246],
  ["src/app/strategy/page.tsx", 187],
  ["src/app/assistant/page.tsx", 242],
  ["src/app/alerts/page.tsx", 264],
  ["src/app/profile/page.tsx", 356],
  ["src/app/login/page.tsx", 155],
  ["src/app/watchlist/page.tsx", 180],
  ["src/app/coach/page.tsx", 208],
  ["src/app/learn/page.tsx", 140],
  ["src/app/sync/page.tsx", 232],
];

/* ── Minimal ZIP builder (store method, no deps) ── */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(data: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function buildZip(entries: { path: string; data: Uint8Array }[]): Blob {
  const enc = new TextEncoder();
  const chunks: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;

  for (const e of entries) {
    const nameB = enc.encode(e.path);
    const crc = crc32(e.data);

    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true);
    lh.setUint16(4, 20, true);
    lh.setUint16(8, 0, true); // method: store
    lh.setUint32(14, crc, true);
    lh.setUint32(18, e.data.length, true);
    lh.setUint32(22, e.data.length, true);
    lh.setUint16(26, nameB.length, true);
    chunks.push(new Uint8Array(lh.buffer), nameB, e.data);

    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true);
    ch.setUint16(4, 20, true);
    ch.setUint16(6, 20, true);
    ch.setUint16(10, 0, true);
    ch.setUint32(16, crc, true);
    ch.setUint32(20, e.data.length, true);
    ch.setUint32(24, e.data.length, true);
    ch.setUint16(28, nameB.length, true);
    ch.setUint32(42, offset, true);
    central.push(new Uint8Array(ch.buffer), nameB);

    offset += 30 + nameB.length + e.data.length;
  }

  const cdSize = central.reduce((s, c) => s + c.length, 0);
  const eocd = new DataView(new ArrayBuffer(22));
  eocd.setUint32(0, 0x06054b50, true);
  eocd.setUint16(8, entries.length, true);
  eocd.setUint16(10, entries.length, true);
  eocd.setUint32(12, cdSize, true);
  eocd.setUint32(16, offset, true);

  return new Blob(
    [...chunks, ...central, new Uint8Array(eocd.buffer)] as unknown as BlobPart[],
    { type: "application/zip" }
  );
}

export default function SyncPage() {
  const [copied, setCopied] = useState<string | null>(null);
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [zipping, setZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState(0);
  const [scriptCopied, setScriptCopied] = useState(false);

  // Auto-fix PowerShell script — embeds THIS page's origin so it always
  // pulls the correct files from wherever you're viewing /sync.
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const psScript = `$base = "${origin}"
$files = @(
${SYNC_FILES.map((f) => `  "${f}"`).join(",\n")}
)
foreach ($f in $files) {
  $dir = Split-Path $f -Parent
  if ($dir) { [void][System.IO.Directory]::CreateDirectory($dir) }
  try {
    $r = Invoke-WebRequest -Uri ($base + "/api/source?file=" + [uri]::EscapeDataString($f)) -UseBasicParsing
    [System.IO.File]::WriteAllText((Join-Path (Get-Location).Path $f), $r.Content)
    Write-Host "OK   $f"
  } catch { Write-Host "FAIL $f" }
}
Write-Host ""
Write-Host "All files synced. Now run:  npm run dev" -ForegroundColor Green
`;

  const groups = useMemo(() => {
    const g: Record<string, string[]> = {};
    SYNC_FILES.forEach((f) => {
      const dir = f.includes("/") ? f.slice(0, f.lastIndexOf("/")) : "(root)";
      (g[dir] ??= []).push(f);
    });
    return Object.entries(g).sort((a, b) => a[0].localeCompare(b[0]));
  }, []);

  const copy = async (file: string) => {
    try {
      const res = await fetch(`/api/source?file=${encodeURIComponent(file)}`);
      const text = await res.text();
      await navigator.clipboard.writeText(text);
      setCopied(file);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      alert("Copy failed — use Download instead.");
    }
  };

  const downloadAll = async () => {
    setDownloadingAll(true);
    for (const f of SYNC_FILES) {
      const a = document.createElement("a");
      a.href = `/api/source?file=${encodeURIComponent(f)}`;
      a.download = f.split("/").pop() ?? "file";
      document.body.appendChild(a);
      a.click();
      a.remove();
      await new Promise((r) => setTimeout(r, 350));
    }
    setDownloadingAll(false);
  };

  // Download the whole project as ONE zip file (most reliable)
  const downloadZip = async () => {
    setZipping(true);
    setZipProgress(0);
    try {
      const enc = new TextEncoder();
      const entries: { path: string; data: Uint8Array }[] = [];
      for (let i = 0; i < SYNC_FILES.length; i++) {
        const f = SYNC_FILES[i];
        const res = await fetch(`/api/source?file=${encodeURIComponent(f)}`);
        if (res.ok) entries.push({ path: f, data: enc.encode(await res.text()) });
        setZipProgress(Math.round(((i + 1) / SYNC_FILES.length) * 100));
      }
      const blob = buildZip(entries);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "marketai-source.zip";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch {
      alert("ZIP failed — use individual downloads instead.");
    } finally {
      setZipping(false);
    }
  };

  return (
    <ProShell active="dashboard">
      <PageTitle
        icon="🔄"
        title="Project Sync Center"
        subtitle="Download or copy the exact latest project files — no more broken copy-paste"
      />

      <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 mb-6 text-sm text-amber-200 leading-relaxed">
        ⚠️ <b>Important:</b> open this page on the <b>live preview URL</b> (not localhost) to
        fetch the latest sandbox files. Each Download saves the exact file — place it in your
        project at the shown path. Or click <b>Download all</b> and sort them into folders.
      </div>

      <div className="flex items-center gap-3 mb-5 flex-wrap">
        <button
          onClick={downloadZip}
          disabled={zipping}
          className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-semibold shadow-lg shadow-emerald-600/25"
        >
          {zipping ? `Packing ${zipProgress}%...` : "📦 Download ZIP (all files, 1 click)"}
        </button>
        <button
          onClick={downloadAll}
          disabled={downloadingAll}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-sm font-semibold shadow-lg shadow-indigo-600/25"
        >
          {downloadingAll ? "Downloading..." : "⬇️ Download files one-by-one"}
        </button>
        <span className="text-xs text-slate-500">{SYNC_FILES.length} files</span>
      </div>

      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 mb-5 text-xs text-emerald-200">
        ✅ <b>Recommended:</b> click <b>📦 Download ZIP</b> → one file contains the whole project.
        Then right-click → <b>Extract All...</b> over your project folder
        (<code className="bg-slate-900/60 px-1 rounded">C:\Users\Priyanshu Kumar\OneDrive\Desktop\New folder</code>),
        choose <b>Replace the files in the destination</b>. Done — no copy-paste, nothing truncated.
      </div>

      {/* Truncation detector */}
      <details className="rounded-xl border border-white/10 bg-slate-900/60 p-4 mb-5 text-xs">
        <summary className="cursor-pointer font-semibold text-white">
          🔍 Verify your local files are NOT truncated (click to open)
        </summary>
        <p className="text-slate-400 mt-2 mb-3 leading-relaxed">
          Open each file in VS Code / Notepad and check the <b>line count</b> (VS Code shows it
          bottom-right). If your number is <b>smaller</b> than expected, that file got cut off
          during copy — re-download it from the list below.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 font-mono text-[11px]">
          {EXPECTED_LINES.map(([f, n]) => (
            <div key={f} className="flex justify-between border-b border-white/5 py-1">
              <span className="text-slate-300 truncate pr-2">{f}</span>
              <span className="text-indigo-300 flex-shrink-0">{n} lines</span>
            </div>
          ))}
        </div>
      </details>

      {/* ⚡ One-command auto-fix */}
      <div className="rounded-2xl border border-indigo-500/30 bg-indigo-500/5 p-5 mb-6">
        <p className="text-sm font-bold text-white">⚡ One-command auto-fix (no ZIP, no copy-paste)</p>
        <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
          This script downloads every correct file and overwrites your local ones automatically.
          <br />
          <span className="text-amber-300 font-semibold">
            ⚠️ Important: open THIS Sync page on the LIVE PREVIEW link (…e2b.app/sync) — not
            localhost — before copying, so the script points at the good files.
          </span>
        </p>
        <ol className="text-xs text-slate-300 mt-2 list-decimal ml-5 space-y-1">
          <li>Copy the script below.</li>
          <li>
            In your project folder, open PowerShell and paste + Enter (if blocked, run:{" "}
            <code className="bg-slate-900 px-1 rounded">Set-ExecutionPolicy -Scope Process Bypass</code>).
          </li>
          <li>Wait for “All files synced”, then run <code className="bg-slate-900 px-1 rounded">npm run dev</code>.</li>
        </ol>
        <div className="relative mt-3">
          <button
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(psScript);
                setScriptCopied(true);
                setTimeout(() => setScriptCopied(false), 1500);
              } catch {
                alert("Copy failed — select the text manually.");
              }
            }}
            className="absolute top-2 right-2 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold z-10"
          >
            {scriptCopied ? "✅ Copied" : "📋 Copy script"}
          </button>
          <pre className="max-h-64 overflow-auto rounded-xl bg-slate-950 border border-white/10 p-3 text-[10px] leading-relaxed text-emerald-300/90">
            {psScript}
          </pre>
        </div>
      </div>

      <div className="space-y-5">
        {groups.map(([dir, files]) => (
          <div key={dir} className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
            <p className="text-xs font-mono text-indigo-300 mb-3">📁 {dir}/</p>
            <div className="space-y-1.5">
              {files.map((f) => {
                const name = f.split("/").pop();
                return (
                  <div
                    key={f}
                    className="flex items-center justify-between gap-3 bg-slate-950/50 border border-white/5 rounded-lg px-3 py-2"
                  >
                    <div className="min-w-0">
                      <p className="text-sm text-white font-medium truncate">{name}</p>
                      <p className="text-[10px] text-slate-600 font-mono truncate">{f}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button
                        onClick={() => copy(f)}
                        className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs hover:text-white"
                      >
                        {copied === f ? "✅ Copied" : "📋 Copy"}
                      </button>
                      <a
                        href={`/api/source?file=${encodeURIComponent(f)}`}
                        download={name}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600/20 text-indigo-300 text-xs hover:bg-indigo-600/40"
                      >
                        ⬇️ Download
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-2xl border border-white/10 bg-slate-900/60 p-4 text-xs text-slate-400 leading-relaxed">
        <p className="font-semibold text-white mb-1">After downloading:</p>
        <ol className="list-decimal ml-5 space-y-1">
          <li>Place each file at its shown path inside your project folder.</li>
          <li>Run <code className="bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">npm install</code> once (installs recharts, lightweight-charts not needed).</li>
          <li>Run <code className="bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">npm run dev</code> and open http://localhost:3000.</li>
          <li>No database or API keys required — everything works out of the box.</li>
        </ol>
      </div>
    </ProShell>
  );
}
