"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { ProShell } from "@/components/ProShell";
import {
  recommend,
  riskScore,
  generateNews,
  stdevReturns,
  rsi14,
  pushNotification,
  type AssetType,
} from "@/lib/pro";

interface MarketAsset {
  id: string;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number;
  priceChange24h: number | null;
  sparkline: number[];
}

export default function TradePage() {
  const params = useParams();
  const router = useRouter();
  const paramSym = String(
    (params as { symbol?: string } | null)?.symbol ?? ""
  ).toUpperCase();

  // Always fall back to BTC so the page never shows an empty error
  const [chosen, setChosen] = useState(paramSym || "BTC");
  const [lists, setLists] = useState<{ c: MarketAsset[]; s: MarketAsset[] }>({
    c: [],
    s: [],
  });
  const [asset, setAsset] = useState<(MarketAsset & { type: AssetType }) | null>(null);
  const [prices, setPrices] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  // Risk calculator state
  const [account, setAccount] = useState(10000);
  const [riskPct, setRiskPct] = useState(2);
  const [stop, setStop] = useState(0);
  const [target, setTarget] = useState(0);

  // Follow URL changes
  useEffect(() => {
    if (paramSym) setChosen(paramSym);
  }, [paramSym]);

  const go = (s: string) => {
    setChosen(s);
    router.replace(`/trade/${s}`);
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setAsset(null);
      setPrices([]);
      try {
        const [c, s] = await Promise.all([
          fetch("/api/market/crypto").then((r) => r.json()),
          fetch("/api/market/stocks").then((r) => r.json()),
        ]);
        if (cancelled) return;
        setLists({ c, s });
        const found =
          c.find((a: MarketAsset) => a.symbol === chosen) ??
          s.find((a: MarketAsset) => a.symbol === chosen);
        if (!found) return;
        const type: AssetType = c.some((a: MarketAsset) => a.symbol === chosen)
          ? "crypto"
          : "stock";
        setAsset({ ...found, type });
        const hRes = await fetch(
          `/api/market/${type === "crypto" ? "crypto" : "stocks"}/${found.id}/history`
        );
        const h = await hRes.json();
        if (!cancelled)
          setPrices((h.prices ?? []).map((p: { price: number }) => p.price));
      } catch {
        /* ignore */
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [chosen]);

  const rec = useMemo(
    () => (prices.length > 30 ? recommend(prices, asset?.priceChange24h ?? 0) : null),
    [prices, asset]
  );
  const risk = useMemo(
    () => (prices.length > 10 ? riskScore(prices, asset?.priceChange24h ?? 0) : null),
    [prices, asset]
  );
  const news = useMemo(() => (asset ? generateNews(asset.symbol, asset.name) : []), [asset]);

  // Prefill SL/TP from recommendation once
  useEffect(() => {
    if (rec && stop === 0 && target === 0) {
      setStop(Math.round(rec.stopLoss * 100) / 100);
      setTarget(Math.round(rec.target * 100) / 100);
    }
  }, [rec, stop, target]);

  const entry = asset?.currentPrice ?? 0;
  const riskAmt = (account * riskPct) / 100;
  const perUnit = Math.abs(entry - stop);
  const qty = perUnit > 0 ? riskAmt / perUnit : 0;
  const posValue = qty * entry;
  const rr = perUnit > 0 ? Math.abs(target - entry) / perUnit : 0;

  const sigColor =
    rec?.signal === "BUY"
      ? "text-emerald-400 border-emerald-500/40 bg-emerald-500/5"
      : rec?.signal === "SELL"
      ? "text-red-400 border-red-500/40 bg-red-500/5"
      : "text-amber-400 border-amber-500/40 bg-amber-500/5";

  const notifySignal = () => {
    if (!rec || !asset) return;
    pushNotification({
      kind: "signal",
      title: `AI Signal: ${rec.signal} ${asset.symbol}`,
      body: `Confidence ${rec.confidence}% · Entry $${entry.toFixed(2)} · SL $${stop.toFixed(2)} · TP $${target.toFixed(2)}`,
    });
    alert("Signal saved to notifications 🔔");
  };

  return (
    <ProShell active="dashboard">
      {loading ? (
        <div className="flex items-center justify-center py-24 gap-3">
          <div className="w-8 h-8 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400">Loading {chosen}...</p>
        </div>
      ) : !asset ? (
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-8 text-center">
          <p className="text-slate-300 text-sm mb-4">
            Select an asset to open its Trade & Risk Management page:
          </p>
          <div className="flex flex-wrap gap-2 justify-center">
            {[...lists.c, ...lists.s].map((a) => (
              <button
                key={a.symbol}
                onClick={() => go(a.symbol)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-indigo-600 hover:text-white transition-colors"
              >
                {a.symbol}
              </button>
            ))}
          </div>
          <Link href="/" className="inline-block mt-5 text-indigo-400 text-sm underline">
            Back to dashboard
          </Link>
        </div>
      ) : (
        <>
          {/* Header */}
          <div className="flex items-center gap-4 mb-6 flex-wrap">
            <img src={asset.image} alt="" className="w-12 h-12 rounded-full bg-slate-700" />
            <div>
              <h1 className="text-2xl font-bold text-white">
                {asset.name}{" "}
                <span className="text-slate-500 text-lg font-normal">{asset.symbol}</span>
              </h1>
              <p className="text-sm text-slate-400">
                ${entry.toLocaleString()} ·{" "}
                <span className={(asset.priceChange24h ?? 0) >= 0 ? "text-emerald-400" : "text-red-400"}>
                  {(asset.priceChange24h ?? 0) >= 0 ? "▲" : "▼"}{" "}
                  {Math.abs(asset.priceChange24h ?? 0).toFixed(2)}%
                </span>
              </p>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {/* Asset switcher */}
              <select
                value={chosen}
                onChange={(e) => go(e.target.value)}
                title="Switch asset"
                className="bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500/50 cursor-pointer"
              >
                <optgroup label="🪙 Crypto">
                  {lists.c.map((a) => (
                    <option key={a.symbol} value={a.symbol}>
                      {a.symbol} — {a.name}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="📈 Stocks">
                  {lists.s.map((a) => (
                    <option key={a.symbol} value={a.symbol}>
                      {a.symbol} — {a.name}
                    </option>
                  ))}
                </optgroup>
              </select>
              <Link
                href="/"
                className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-sm hover:bg-slate-700"
              >
                ← Dashboard
              </Link>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* ── AI Recommendation ── */}
            <div className={`rounded-2xl border p-5 ${sigColor}`}>
              <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                🤖 AI Recommendation
              </p>
              <p className="mt-2 text-4xl font-extrabold">{rec?.signal ?? "—"}</p>
              <p className="mt-1 text-sm text-slate-300">Confidence {rec?.confidence ?? 0}%</p>
              <div className="mt-3 h-1.5 bg-slate-700/60 rounded-full overflow-hidden">
                <div
                  className="h-full bg-current rounded-full"
                  style={{ width: `${rec?.confidence ?? 0}%` }}
                />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="bg-slate-900/50 rounded-lg p-2">
                  <p className="text-[10px] text-slate-500">ENTRY</p>
                  <p className="text-xs font-bold text-white">${entry.toFixed(2)}</p>
                </div>
                <div className="bg-slate-900/50 rounded-lg p-2">
                  <p className="text-[10px] text-slate-500">STOP</p>
                  <p className="text-xs font-bold text-red-400">${(rec?.stopLoss ?? 0).toFixed(2)}</p>
                </div>
                <div className="bg-slate-900/50 rounded-lg p-2">
                  <p className="text-[10px] text-slate-500">TARGET</p>
                  <p className="text-xs font-bold text-emerald-400">${(rec?.target ?? 0).toFixed(2)}</p>
                </div>
              </div>
              <ul className="mt-4 space-y-1.5">
                {rec?.reasons.map((r, i) => (
                  <li key={i} className="text-xs text-slate-300 flex gap-1.5">
                    <span className="text-slate-500">•</span> {r}
                  </li>
                ))}
              </ul>
              <button
                onClick={notifySignal}
                className="mt-4 w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
              >
                🔔 Save signal to notifications
              </button>
            </div>

            {/* ── Risk Management Calculator ── */}
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
              <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                🛡️ Risk Management
              </p>
              <div className="mt-4 space-y-3">
                <label className="block">
                  <span className="text-xs text-slate-400">Account size ($)</span>
                  <input
                    type="number"
                    value={account}
                    onChange={(e) => setAccount(Number(e.target.value))}
                    className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                  />
                </label>
                <label className="block">
                  <span className="text-xs text-slate-400">Risk per trade (%)</span>
                  <input
                    type="number"
                    step="0.5"
                    value={riskPct}
                    onChange={(e) => setRiskPct(Number(e.target.value))}
                    className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                  />
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-xs text-slate-400">Stop loss ($)</span>
                    <input
                      type="number"
                      value={stop}
                      onChange={(e) => setStop(Number(e.target.value))}
                      className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                    />
                  </label>
                  <label className="block">
                    <span className="text-xs text-slate-400">Take profit ($)</span>
                    <input
                      type="number"
                      value={target}
                      onChange={(e) => setTarget(Number(e.target.value))}
                      className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
                    />
                  </label>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Out label="Risk amount" value={`$${riskAmt.toFixed(2)}`} tone="text-red-400" />
                <Out label="Position size" value={`$${posValue.toFixed(2)}`} tone="text-white" />
                <Out
                  label="Quantity"
                  value={qty >= 1 ? qty.toFixed(2) : qty.toFixed(5)}
                  tone="text-white"
                />
                <Out
                  label="Risk : Reward"
                  value={`1 : ${rr.toFixed(2)}`}
                  tone={rr >= 2 ? "text-emerald-400" : "text-amber-400"}
                />
              </div>
              <p className="mt-3 text-[11px] text-slate-500">
                {rr >= 2
                  ? "✅ Healthy R:R (≥ 2:1). Trade meets risk criteria."
                  : "⚠️ R:R below 2:1 — consider moving target or tightening stop."}
              </p>
            </div>

            {/* ── Risk Score + indicators ── */}
            <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
              <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                ⚠️ Risk Score
              </p>
              <div className="mt-4 flex items-center gap-4">
                <div className="relative w-24 h-24">
                  <svg viewBox="0 0 100 100" className="w-24 h-24 -rotate-90">
                    <circle cx="50" cy="50" r="42" fill="none" stroke="#1e293b" strokeWidth="10" />
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      stroke={
                        (risk?.score ?? 0) < 35
                          ? "#10b981"
                          : (risk?.score ?? 0) < 65
                          ? "#f59e0b"
                          : "#ef4444"
                      }
                      strokeWidth="10"
                      strokeDasharray={`${((risk?.score ?? 0) / 100) * 264} 264`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center text-2xl font-extrabold text-white">
                    {risk?.score ?? 0}
                  </span>
                </div>
                <div>
                  <p
                    className={`text-lg font-bold ${
                      risk?.label === "Low"
                        ? "text-emerald-400"
                        : risk?.label === "Medium"
                        ? "text-amber-400"
                        : "text-red-400"
                    }`}
                  >
                    {risk?.label ?? "—"} risk
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Volatility {(stdevReturns(prices) * 100).toFixed(2)}% · RSI{" "}
                    {rsi14(prices).toFixed(0)}
                  </p>
                </div>
              </div>

              {/* News sentiment */}
              <p className="mt-5 text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                📰 Latest news
              </p>
              <div className="mt-2 space-y-2 max-h-52 overflow-y-auto pr-1">
                {news.slice(0, 4).map((nItem, i) => (
                  <div key={i} className="bg-slate-950/50 rounded-lg p-2.5 border border-white/5">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-xs text-slate-200 leading-snug">{nItem.title}</p>
                      <span
                        className={`text-[10px] font-semibold px-1.5 py-0.5 rounded flex-shrink-0 ${
                          nItem.sentiment === "Positive"
                            ? "bg-emerald-500/10 text-emerald-400"
                            : nItem.sentiment === "Negative"
                            ? "bg-red-500/10 text-red-400"
                            : "bg-slate-700/40 text-slate-400"
                        }`}
                      >
                        {nItem.sentiment}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-600 mt-1">
                      {nItem.source} · {nItem.time}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </ProShell>
  );
}

function Out({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="bg-slate-950/50 border border-white/5 rounded-lg p-2.5">
      <p className="text-[10px] text-slate-500">{label}</p>
      <p className={`text-sm font-bold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}
