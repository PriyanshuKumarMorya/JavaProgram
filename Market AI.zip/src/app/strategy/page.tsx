"use client";

import { useEffect, useMemo, useState } from "react";
import { ResponsiveContainer, AreaChart, Area, Tooltip } from "recharts";
import { ProShell, PageTitle } from "@/components/ProShell";
import { backtest, type BacktestResult } from "@/lib/pro";

interface MarketAsset {
  id: string;
  symbol: string;
  name: string;
}

type StratKey = "sma" | "rsi" | "momentum";
const STRATS: { key: StratKey; label: string; desc: string }[] = [
  { key: "sma", label: "SMA Crossover", desc: "Buy when SMA10 crosses above SMA30; exit on cross below." },
  { key: "rsi", label: "RSI Reversal", desc: "Buy when RSI14 < 30 (oversold); exit when RSI14 > 70." },
  { key: "momentum", label: "Momentum", desc: "Buy when 24-bar rate-of-change turns positive; exit when negative." },
];

export default function StrategyPage() {
  const [assets, setAssets] = useState<(MarketAsset & { type: "crypto" | "stock" })[]>([]);
  const [symbol, setSymbol] = useState("BTC");
  const [strat, setStrat] = useState<StratKey>("sma");
  const [prices, setPrices] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([
        fetch("/api/market/crypto").then((r) => r.json()),
        fetch("/api/market/stocks").then((r) => r.json()),
      ]);
      setAssets([
        ...c.map((a: MarketAsset) => ({ ...a, type: "crypto" as const })),
        ...s.map((a: MarketAsset) => ({ ...a, type: "stock" as const })),
      ]);
    })();
  }, []);

  const asset = assets.find((a) => a.symbol === symbol);

  useEffect(() => {
    if (!asset) return;
    let cancelled = false;
    setLoading(true);
    fetch(`/api/market/${asset.type === "crypto" ? "crypto" : "stocks"}/${asset.id}/history`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setPrices((d.prices ?? []).map((p: { price: number }) => p.price));
      })
      .catch(() => !cancelled && setPrices([]))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [asset]);

  const result: BacktestResult | null = useMemo(
    () => (prices.length > 60 ? backtest(prices, strat) : null),
    [prices, strat]
  );

  return (
    <ProShell active="strategy">
      <PageTitle
        icon="🧪"
        title="Strategy Lab"
        subtitle="Backtest trading strategies on 30 days of real price history"
      />

      {/* Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
          <p className="text-xs text-slate-400 mb-2">Asset</p>
          <select
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
          >
            <optgroup label="🪙 Crypto">
              {assets.filter((a) => a.type === "crypto").map((a) => (
                <option key={a.symbol} value={a.symbol}>{a.symbol} — {a.name}</option>
              ))}
            </optgroup>
            <optgroup label="📈 Stocks">
              {assets.filter((a) => a.type === "stock").map((a) => (
                <option key={a.symbol} value={a.symbol}>{a.symbol} — {a.name}</option>
              ))}
            </optgroup>
          </select>
        </div>
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
          <p className="text-xs text-slate-400 mb-2">Strategy</p>
          <div className="flex flex-wrap gap-2">
            {STRATS.map((s) => (
              <button
                key={s.key}
                onClick={() => setStrat(s.key)}
                className={`px-3 py-2 rounded-lg text-xs font-semibold ${
                  strat === s.key ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <p className="text-xs text-slate-500 mb-4">
        {STRATS.find((s) => s.key === strat)?.desc}
      </p>

      {loading ? (
        <div className="flex items-center justify-center py-20 gap-3">
          <div className="w-8 h-8 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm">Running backtest on {symbol}...</p>
        </div>
      ) : result ? (
        <>
          {/* Results */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <Stat
              label="Strategy return"
              value={`${result.totalReturn >= 0 ? "+" : ""}${result.totalReturn.toFixed(2)}%`}
              tone={result.totalReturn >= 0 ? "text-emerald-400" : "text-red-400"}
            />
            <Stat
              label="Buy & hold"
              value={`${result.buyHold >= 0 ? "+" : ""}${result.buyHold.toFixed(2)}%`}
              tone="text-slate-300"
            />
            <Stat label="Win rate" value={`${result.winRate.toFixed(0)}%`} tone={result.winRate >= 50 ? "text-emerald-400" : "text-amber-400"} />
            <Stat label="Trades" value={String(result.trades)} tone="text-slate-300" />
            <Stat label="Max drawdown" value={`-${result.maxDrawdown.toFixed(2)}%`} tone="text-red-400" />
          </div>

          <div
            className={`rounded-2xl border p-4 mb-6 text-sm ${
              result.totalReturn > result.buyHold
                ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-300"
                : "border-amber-500/30 bg-amber-500/5 text-amber-300"
            }`}
          >
            {result.totalReturn > result.buyHold
              ? `✅ ${STRATS.find((s) => s.key === strat)?.label} beat buy & hold by ${(result.totalReturn - result.buyHold).toFixed(2)}% on ${symbol} over 30 days.`
              : `📊 Buy & hold outperformed this strategy by ${(result.buyHold - result.totalReturn).toFixed(2)}% on ${symbol}. Strong trends often beat signal-based entries.`}
          </div>

          {/* Equity curve */}
          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">Equity curve ($10,000 start)</p>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={result.equity}>
                  <defs>
                    <linearGradient id="bt" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#34d399" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#34d399" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Tooltip
                    contentStyle={{ backgroundColor: "#1e293b", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, fontSize: 12 }}
                    formatter={(v) => [`$${Number(v).toLocaleString()}`, "Equity"]}
                  />
                  <Area type="monotone" dataKey="v" stroke="#34d399" strokeWidth={2} fill="url(#bt)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      ) : (
        <p className="text-center text-slate-500 py-20 text-sm">Not enough data to backtest.</p>
      )}
    </ProShell>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
      <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold">{label}</p>
      <p className={`mt-1 text-lg font-extrabold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}
