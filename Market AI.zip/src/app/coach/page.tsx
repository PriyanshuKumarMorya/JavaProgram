"use client";

import { useEffect, useMemo, useState } from "react";
import { ProShell, PageTitle } from "@/components/ProShell";
import {
  loadLS,
  LS,
  DEFAULT_PORTFOLIO,
  riskScore,
  rsi14,
  stdevReturns,
  chatAnswer,
  type Position,
} from "@/lib/pro";

export default function CoachPage() {
  const [positions] = useState<Position[]>(() =>
    loadLS<Position[]>(LS.portfolio, DEFAULT_PORTFOLIO)
  );
  const [market, setMarket] = useState<Record<string, { currentPrice: number; sparkline: number[]; priceChange24h: number | null }>>({});
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([
        fetch("/api/market/crypto").then((r) => r.json()),
        fetch("/api/market/stocks").then((r) => r.json()),
      ]);
      const map: any = {};
      [...c, ...s].forEach((a: any) => (map[a.symbol] = a));
      setMarket(map);
    })();
  }, []);

  const review = useMemo(() => {
    const rows = positions.map((p) => {
      const m = market[p.symbol];
      const price = m?.currentPrice ?? p.avgBuy;
      const value = price * p.qty;
      const cost = p.avgBuy * p.qty;
      const pnlPct = cost ? ((value - cost) / cost) * 100 : 0;
      const sp = m?.sparkline ?? [];
      const risk = riskScore(sp, m?.priceChange24h ?? 0);
      const rsi = rsi14(sp);
      const vol = stdevReturns(sp);

      // Coach feedback per position
      const tips: string[] = [];
      if (pnlPct > 15) tips.push(`Big winner (+${pnlPct.toFixed(0)}%) — protect gains with a trailing stop.`);
      else if (pnlPct > 0) tips.push(`In profit (+${pnlPct.toFixed(1)}%) — let it run, stop at breakeven.`);
      else if (pnlPct > -10) tips.push(`Small loss (${pnlPct.toFixed(1)}%) — still within normal noise; thesis intact?`);
      else tips.push(`Deep loss (${pnlPct.toFixed(1)}%) — cut or re-validate the thesis; don't average down blindly.`);
      if (risk.label === "High") tips.push("High risk asset — keep size small (≤10% of portfolio).");
      if (rsi > 72) tips.push("RSI overbought — a pullback would be healthy; avoid adding here.");
      if (rsi < 30) tips.push("RSI oversold — potential bounce zone for patient buyers.");
      if (vol > 0.02) tips.push("Very volatile — expect large swings; widen stops or reduce size.");

      return { ...p, price, value, cost, pnlPct, risk, rsi, tips };
    });

    const totalValue = rows.reduce((s, r) => s + r.value, 0);
    const totalCost = rows.reduce((s, r) => s + r.cost, 0);
    const totalPnlPct = totalCost ? ((totalValue - totalCost) / totalCost) * 100 : 0;
    const winRate = rows.length ? (rows.filter((r) => r.pnlPct > 0).length / rows.length) * 100 : 0;
    const maxWeight = rows.length ? Math.max(...rows.map((r) => (totalValue ? r.value / totalValue : 0))) : 0;
    const avgRisk = rows.length ? rows.reduce((s, r) => s + r.risk.score, 0) / rows.length : 0;

    // Overall grade
    let score = 50;
    score += Math.max(-20, Math.min(20, totalPnlPct));
    score += (winRate - 50) / 2;
    score -= maxWeight > 0.35 ? 15 : 0;
    score -= avgRisk > 60 ? 10 : 0;
    const grade = score >= 80 ? "A" : score >= 65 ? "B" : score >= 50 ? "C" : score >= 35 ? "D" : "E";

    const mistakes: string[] = [];
    if (maxWeight > 0.35) {
      const w = rows.reduce((a, b) => (b.value > a.value ? b : a));
      mistakes.push(`⚠️ Concentration: ${w.symbol} is ${(maxWeight * 100).toFixed(0)}% of your portfolio — diversify.`);
    }
    if (avgRisk > 60) mistakes.push("⚠️ Overall risk score is HIGH — the portfolio can swing violently.");
    rows.filter((r) => r.pnlPct < -10).forEach((r) =>
      mistakes.push(`⚠️ ${r.symbol} is down ${Math.abs(r.pnlPct).toFixed(0)}% — review or exit, don't hope.`)
    );
    if (winRate < 40 && rows.length > 2) mistakes.push("⚠️ Win rate below 40% — tighten entry criteria and use the AI signal page.");
    if (mistakes.length === 0) mistakes.push("✅ No major mistakes detected. Discipline is paying off.");

    const plan: string[] = [
      totalPnlPct >= 0
        ? "📈 Trend is your friend — add only on pullbacks with defined stops."
        : "🛡️ Focus on capital preservation — raise cash and wait for A-grade setups.",
      "🎯 Risk ≤ 2% per new trade; R:R ≥ 2:1 always.",
      "🔔 Set price alerts on key levels instead of watching charts all day.",
      "🧪 Validate any new idea in the Strategy Lab before using real money.",
    ];

    return { rows, totalValue, totalPnlPct, winRate, maxWeight, avgRisk, grade, mistakes, plan };
  }, [positions, market]);

  return (
    <ProShell active="coach">
      <PageTitle
        icon="🧠"
        title="AI Trading Coach"
        subtitle="Honest feedback on your positions, mistakes and an action plan"
      />

      {/* Grade + headline stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <div className="rounded-2xl border border-indigo-500/30 bg-indigo-500/10 p-4 flex items-center gap-4">
          <span className="text-4xl font-black text-indigo-300">{review.grade}</span>
          <div>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Coach grade</p>
            <p className="text-xs text-slate-400">of your portfolio</p>
          </div>
        </div>
        <Stat label="Portfolio" value={`$${review.totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} />
        <Stat label="Total P&L" value={`${review.totalPnlPct >= 0 ? "+" : ""}${review.totalPnlPct.toFixed(2)}%`} tone={review.totalPnlPct >= 0 ? "text-emerald-400" : "text-red-400"} />
        <Stat label="Win rate" value={`${review.winRate.toFixed(0)}%`} tone={review.winRate >= 50 ? "text-emerald-400" : "text-amber-400"} />
        <Stat label="Avg risk" value={`${review.avgRisk.toFixed(0)}/100`} tone={review.avgRisk < 35 ? "text-emerald-400" : review.avgRisk < 65 ? "text-amber-400" : "text-red-400"} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Per-position review */}
        <div className="lg:col-span-2 space-y-3">
          {review.rows.map((r) => (
            <div key={r.symbol} className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <p className="text-sm font-bold text-white">
                  {r.symbol} <span className="text-slate-500 font-normal text-xs">{r.name}</span>
                </p>
                <div className="flex items-center gap-2 text-xs tabular-nums">
                  <span className={r.pnlPct >= 0 ? "text-emerald-400" : "text-red-400"}>
                    {r.pnlPct >= 0 ? "+" : ""}{r.pnlPct.toFixed(1)}%
                  </span>
                  <span className={`px-1.5 py-0.5 rounded font-semibold ${r.risk.label === "Low" ? "bg-emerald-500/10 text-emerald-400" : r.risk.label === "Medium" ? "bg-amber-500/10 text-amber-400" : "bg-red-500/10 text-red-400"}`}>
                    Risk {r.risk.score}
                  </span>
                  <span className="text-slate-500">RSI {r.rsi.toFixed(0)}</span>
                </div>
              </div>
              <ul className="mt-2 space-y-1">
                {r.tips.map((t, i) => (
                  <li key={i} className="text-xs text-slate-300 leading-relaxed">💬 {t}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Mistakes + plan + ask */}
        <div className="space-y-5">
          <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-5">
            <p className="text-sm font-semibold text-white mb-3">🚩 Mistakes & warnings</p>
            <ul className="space-y-2">
              {review.mistakes.map((m, i) => (
                <li key={i} className="text-xs text-slate-300 leading-relaxed">{m}</li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-5">
            <p className="text-sm font-semibold text-white mb-3">🎯 Action plan</p>
            <ul className="space-y-2">
              {review.plan.map((p, i) => (
                <li key={i} className="text-xs text-slate-300 leading-relaxed">{p}</li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-semibold text-white mb-3">💬 Ask your coach</p>
            <div className="flex gap-2">
              <input
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { setAnswer(chatAnswer(question)); } }}
                placeholder="e.g. should I sell my ETH?"
                className="flex-1 bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600"
              />
              <button
                onClick={() => setAnswer(chatAnswer(question))}
                className="px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
              >
                Ask
              </button>
            </div>
            {answer && (
              <p className="mt-3 text-xs text-slate-300 leading-relaxed bg-slate-950/50 border border-white/5 rounded-lg p-3">
                🧠 {answer}
              </p>
            )}
          </div>
        </div>
      </div>
    </ProShell>
  );
}

function Stat({ label, value, tone = "text-white" }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">{label}</p>
      <p className={`mt-1 text-lg font-extrabold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}
