"use client";

import { useEffect, useState } from "react";
import { ProShell, PageTitle } from "@/components/ProShell";
import {
  loadLS,
  saveLS,
  LS,
  pushNotification,
  type AlertItem,
  type NotificationItem,
  type AssetType,
} from "@/lib/pro";

interface MarketAsset {
  symbol: string;
  name: string;
  currentPrice: number;
  priceChange24h: number | null;
}

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<AlertItem[]>(() => loadLS<AlertItem[]>(LS.alerts, []));
  const [notifs, setNotifs] = useState<NotificationItem[]>(() =>
    loadLS<NotificationItem[]>(LS.notifications, [])
  );
  const [assets, setAssets] = useState<(MarketAsset & { type: AssetType })[]>([]);
  const [symbol, setSymbol] = useState("BTC");
  const [dir, setDir] = useState<"above" | "below" | "change">("above");
  const [price, setPrice] = useState("");

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([
        fetch("/api/market/crypto").then((r) => r.json()),
        fetch("/api/market/stocks").then((r) => r.json()),
      ]);
      const all = [
        ...c.map((a: MarketAsset) => ({ ...a, type: "crypto" as AssetType })),
        ...s.map((a: MarketAsset) => ({ ...a, type: "stock" as AssetType })),
      ];
      setAssets(all);

      // Evaluate alerts against live prices → generate notifications
      const current = loadLS<AlertItem[]>(LS.alerts, []);
      const triggered: AlertItem[] = [];
      current.forEach((al) => {
        const m = all.find((a) => a.symbol === al.symbol);
        if (!m) return;
        const hit =
          (al.dir === "above" && m.currentPrice >= al.price) ||
          (al.dir === "below" && m.currentPrice <= al.price) ||
          (al.dir === "change" && Math.abs(m.priceChange24h ?? 0) >= al.price);
        if (hit) {
          pushNotification({
            kind: "alert",
            title: `⏰ Price alert: ${al.symbol} ${al.dir} $${al.price}`,
            body: `Now trading at $${m.currentPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}`,
          });
          triggered.push(al);
        }
      });
      if (triggered.length) {
        const next = current.filter((a) => !triggered.includes(a));
        saveLS(LS.alerts, next);
        setAlerts(next);
      }
      setNotifs(loadLS<NotificationItem[]>(LS.notifications, []));
    })();
  }, []);

  const addAlert = () => {
    const p = Number(price);
    if (!symbol || !p || p <= 0) return;
    const a = assets.find((x) => x.symbol === symbol);
    const item: AlertItem = {
      id: Math.random().toString(36).slice(2),
      symbol,
      type: a?.type ?? "crypto",
      dir,
      price: p,
      createdAt: Date.now(),
    };
    const next = [...alerts, item];
    setAlerts(next);
    saveLS(LS.alerts, next);
    setPrice("");
    pushNotification({
      kind: "alert",
      title: `Alert created: ${symbol} ${dir} $${p}`,
      body: "We'll notify you when the condition triggers.",
    });
    setNotifs(loadLS<NotificationItem[]>(LS.notifications, []));
  };

  const removeAlert = (id: string) => {
    const next = alerts.filter((a) => a.id !== id);
    setAlerts(next);
    saveLS(LS.alerts, next);
  };

  const markAllRead = () => {
    const next = notifs.map((n) => ({ ...n, read: true }));
    setNotifs(next);
    saveLS(LS.notifications, next);
  };

  const clearNotifs = () => {
    setNotifs([]);
    saveLS(LS.notifications, []);
  };

  const kindIcon: Record<NotificationItem["kind"], string> = {
    signal: "🤖",
    news: "📰",
    portfolio: "📊",
    trade: "💹",
    alert: "⏰",
  };

  return (
    <ProShell active="alerts">
      <PageTitle
        icon="🔔"
        title="Alerts & Notifications"
        subtitle="Price alerts, AI signals, news and portfolio updates — all in one inbox"
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* ── Create alert ── */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <p className="text-sm font-semibold text-white mb-4">⏰ Create price alert</p>
          <div className="grid grid-cols-2 gap-3">
            <label className="block col-span-2 sm:col-span-1">
              <span className="text-xs text-slate-400">Asset</span>
              <select
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
              >
                {assets.map((a) => (
                  <option key={a.symbol} value={a.symbol}>
                    {a.symbol} — {a.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block col-span-2 sm:col-span-1">
              <span className="text-xs text-slate-400">Condition</span>
              <select
                value={dir}
                onChange={(e) => setDir(e.target.value as "above" | "below" | "change")}
                className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white"
              >
                <option value="above">Price goes ABOVE</option>
                <option value="below">Price goes BELOW</option>
                <option value="change">24h move ≥ % (up or down)</option>
              </select>
            </label>
            <label className="block col-span-2 sm:col-span-1">
              <span className="text-xs text-slate-400">Target price ($)</span>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="e.g. 70000"
                className="mt-1 w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600"
              />
            </label>
            <div className="flex items-end">
              <button
                onClick={addAlert}
                className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
              >
                + Add alert
              </button>
            </div>
          </div>

          {/* Active alerts */}
          <p className="text-xs uppercase tracking-wider text-slate-500 font-semibold mt-6 mb-2">
            Active alerts ({alerts.length})
          </p>
          {alerts.length === 0 ? (
            <p className="text-xs text-slate-600">No active alerts.</p>
          ) : (
            <div className="space-y-2">
              {alerts.map((a) => {
                const live = assets.find((x) => x.symbol === a.symbol);
                return (
                  <div key={a.id} className="flex items-center justify-between bg-slate-950/50 border border-white/5 rounded-lg px-3 py-2">
                    <div>
                      <p className="text-sm text-white font-semibold">
                        {a.symbol}{" "}
                        <span className={a.dir === "change" ? "text-amber-400" : a.dir === "above" ? "text-emerald-400" : "text-red-400"}>
                          {a.dir === "above" ? "≥" : a.dir === "below" ? "≤" : "±"}
                          {a.dir === "change" ? `${a.price}%` : ` $${a.price.toLocaleString()}`}
                        </span>
                      </p>
                      <p className="text-[10px] text-slate-500">
                        {live ? `Now $${live.currentPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}` : ""} · created{" "}
                        {new Date(a.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                    <button onClick={() => removeAlert(a.id)} className="text-slate-600 hover:text-red-400 text-xs">
                      ✕
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Notifications inbox ── */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-semibold text-white">
              🔔 Notifications{" "}
              <span className="text-xs text-slate-500 font-normal">
                ({notifs.filter((n) => !n.read).length} unread)
              </span>
            </p>
            <div className="flex gap-2">
              <button onClick={markAllRead} className="text-xs text-indigo-400 hover:text-indigo-300">
                Mark all read
              </button>
              <button onClick={clearNotifs} className="text-xs text-slate-500 hover:text-red-400">
                Clear
              </button>
            </div>
          </div>
          {notifs.length === 0 ? (
            <p className="text-xs text-slate-600 py-8 text-center">
              Inbox empty. Create alerts, run AI signals or trade to see updates here.
            </p>
          ) : (
            <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
              {notifs.map((n) => (
                <div
                  key={n.id}
                  className={`rounded-lg border px-3 py-2.5 ${
                    n.read ? "border-white/5 bg-slate-950/40" : "border-indigo-500/30 bg-indigo-500/5"
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <span className="text-base leading-none mt-0.5">{kindIcon[n.kind]}</span>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white">{n.title}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{n.body}</p>
                      <p className="text-[10px] text-slate-600 mt-1">
                        {new Date(n.time).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </ProShell>
  );
}
