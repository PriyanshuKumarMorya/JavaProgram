"use client";

import { useState } from "react";
import Link from "next/link";
import { ProShell, PageTitle } from "@/components/ProShell";
import { LESSONS, QUIZ } from "@/lib/pro";

const GLOSSARY = [
  { term: "Candlestick", def: "A price bar showing open, high, low, close for a period. Green = close above open; red = below." },
  { term: "Support / Resistance", def: "Price zones where buying (support) or selling (resistance) historically steps in." },
  { term: "RSI", def: "Relative Strength Index (0–100). <30 oversold, >70 overbought." },
  { term: "MACD", def: "Momentum indicator from the gap between 12 & 26 EMAs; crossovers signal shifts." },
  { term: "Stop Loss", def: "Pre-set exit that caps loss. Risk ≤1–2% of capital per trade." },
  { term: "Take Profit", def: "Pre-set exit that locks gains at your target." },
  { term: "Risk : Reward", def: "Ratio of potential loss to potential gain. Aim ≥ 1:2." },
  { term: "Position Size", def: "How much to buy: risk$ ÷ (entry − stop). Controls survival." },
  { term: "Diversification", def: "Spreading capital across uncorrelated assets to reduce single-asset risk." },
  { term: "Drawdown", def: "Peak-to-trough decline of equity. Measures worst pain of a strategy." },
  { term: "Bull / Bear", def: "Rising market (bull) vs falling market (bear)." },
  { term: "Volatility", def: "How wildly price swings. High vol = bigger risk & bigger opportunity." },
];

export default function LearnPage() {
  const [openLesson, setOpenLesson] = useState(0);
  const [qIdx, setQIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [picked, setPicked] = useState<number | null>(null);

  const answer = (i: number) => {
    setPicked(i);
    const correct = i === QUIZ[qIdx].answer;
    setTimeout(() => {
      const ns = score + (correct ? 1 : 0);
      setScore(ns);
      setPicked(null);
      if (qIdx + 1 >= QUIZ.length) setDone(true);
      else setQIdx(qIdx + 1);
    }, 1200);
  };

  return (
    <ProShell active="learn">
      <PageTitle
        icon="📚"
        title="AI Learning Mode"
        subtitle="Trading basics, indicators, risk — lessons, quiz and glossary"
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Lessons */}
        <div className="space-y-3">
          {LESSONS.map((l, i) => (
            <div key={i} className="rounded-2xl border border-white/10 bg-slate-900/60 overflow-hidden">
              <button
                onClick={() => setOpenLesson(openLesson === i ? -1 : i)}
                className="w-full flex items-center justify-between px-5 py-4 text-left"
              >
                <span className="text-sm font-bold text-white">{l.title}</span>
                <span className="text-slate-500">{openLesson === i ? "−" : "+"}</span>
              </button>
              {openLesson === i && (
                <p className="px-5 pb-5 text-sm text-slate-400 leading-relaxed">{l.body}</p>
              )}
            </div>
          ))}
          <div className="rounded-2xl border border-indigo-500/20 bg-indigo-500/5 p-4 text-xs text-slate-300">
            💡 Want a live explanation? Ask the{" "}
            <Link href="/assistant" className="text-indigo-300 underline">AI Assistant</Link>{" "}
            anything — e.g. “explain RSI with an example”.
          </div>
        </div>

        {/* Quiz + glossary */}
        <div className="space-y-5">
          <div className="rounded-2xl border border-purple-500/20 bg-purple-500/5 p-5">
            <p className="text-sm font-bold text-white mb-3">🧠 Knowledge quiz</p>
            {!done ? (
              <>
                <p className="text-sm text-slate-200 mb-3">
                  Q{qIdx + 1}/{QUIZ.length}: {QUIZ[qIdx].q}
                </p>
                <div className="space-y-2">
                  {QUIZ[qIdx].options.map((o, i) => {
                    const showCorrect = picked !== null && i === QUIZ[qIdx].answer;
                    const showWrong = picked === i && i !== QUIZ[qIdx].answer;
                    return (
                      <button
                        key={i}
                        disabled={picked !== null}
                        onClick={() => answer(i)}
                        className={`w-full text-left px-4 py-2.5 rounded-lg border text-sm transition-colors ${
                          showCorrect
                            ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-300"
                            : showWrong
                            ? "border-red-500/50 bg-red-500/10 text-red-300"
                            : "border-white/10 bg-slate-900/60 text-slate-300 hover:border-indigo-500/50"
                        }`}
                      >
                        {o}
                      </button>
                    );
                  })}
                </div>
                {picked !== null && (
                  <p className="mt-3 text-xs text-slate-400">💡 {QUIZ[qIdx].why}</p>
                )}
              </>
            ) : (
              <div className="text-center py-4">
                <p className="text-3xl font-extrabold text-white">{score}/{QUIZ.length}</p>
                <p className="text-sm text-slate-400 mt-2">
                  {score === QUIZ.length ? "🏆 Perfect score!" : score >= 2 ? "✅ Well done!" : "📚 Re-read the lessons and retry."}
                </p>
                <button
                  onClick={() => { setQIdx(0); setScore(0); setDone(false); }}
                  className="mt-4 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold"
                >
                  Retry quiz
                </button>
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
            <p className="text-sm font-bold text-white mb-3">📖 Glossary</p>
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {GLOSSARY.map((g) => (
                <div key={g.term} className="bg-slate-950/50 border border-white/5 rounded-lg p-3">
                  <p className="text-xs font-bold text-indigo-300">{g.term}</p>
                  <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{g.def}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </ProShell>
  );
}
