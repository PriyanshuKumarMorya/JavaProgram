"use client";

import { useEffect, useMemo, useState } from "react";
import { ProShell, PageTitle } from "@/components/ProShell";
import { generateNews, sentimentScore, riskScore, stdevReturns, type AssetType } from "@/lib/pro";

interface MarketAsset {
  id: string;
  symbol: string;
  name: string;
  currentPrice: number;
  priceChange24h: number | null;
  sparkline: number[];
}

export default function MarketsPage() {
  const [crypto, setCrypto] = useState<MarketAsset[]>([]);
  const [stocks, setStocks] = useState<MarketAsset[]>([]);
  const [picked, setPicked] = useState<string[]>(["BTC", "ETH", "AAPL"]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      const [c, s] = await Promise.all([
        fetch("/api/market/crypto").then((r) => r.json()),
        fetch("/api/market/stocks").then((r) => r.json()),
      ]);
      setCrypto(c);
      setStocks(s);
      setLoaded(true);
    })();
  }, []);

  const all = useMemo(
    () => [
      ...crypto.map((a) => ({ ...a, type: "crypto" as AssetType })),
      ...stocks.map((a) => ({ ...a, type: "stock" as AssetType })),
    ],
    [crypto, stocks]
  );

  const compare = useMemo(
    () =>
      picked
        .map((sym) => all.find((a) => a.symbol === sym))
        .filter(Boolean) as (MarketAsset & { type: AssetType })[],
    [picked, all]
  );

  const toggle = (sym: string) =>
    setPicked((p) => (p.includes(sym) ? p.filter((x) => x !== sym) : p.length < 3 ? [...p, sym] : p));

  const newsAsset = compare[0];
  const news = useMemo(
    () => (newsAsset ? generateNews(newsAsset.symbol, newsAsset.name) : []),
    [newsAsset]
  );
  const sent = sentimentScore(news);

  const metric = (a: MarketAsset & { type: AssetType }) => {
    const sp = a.sparkline ?? [];
    const ret7 = sp.length > 1 ? ((sp[sp.length - 1] - sp[0]) / sp[0]) * 100 : 0;
    const risk = riskScore(sp, a.priceChange24h ?? 0);
    const vol = stdevReturns(sp);
    const trend = ret7 > 1 ? "Uptrend" : ret7 < -1 ? "Downtrend" : "Sideways";
    return { ret7, risk, vol, trend };
  };

  return (
    <ProShell active="markets">
      <PageTitle
        icon="📰"
        title="Markets · Compare · News"
        subtitle="Compare up to 3 assets side-by-side and read AI-summarized news"
      />

      {/* Picker */}
      <div className="mb-5">
        <p className="text-xs text-slate-400 mb-2">Pick up to 3 assets to compare:</p>
        <div className="flex flex-wrap gap-2">
          {all.map((a) => (
            <button
              key={a.symbol}
              onClick={() => toggle(a.symbol)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                picked.includes(a.symbol)
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-800/70 text-slate-400 hover:text-white border border-white/5"
              }`}
            >
              {a.symbol}
            </button>
          ))}
        </div>
      </div>

      {/* Comparison table */}
      <div className="rounded-2xl border border-white/10 bg-slate-900/60 overflow-x-auto mb-6">
        <table className="w-full text-sm min-w-[640px]">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-slate-500 border-b border-white/5">
              <th className="p-4">Metric</th>
              {compare.map((a) => (
                <th key={a.symbol} className="p-4">
                  <span className="text-white font-bold text-sm">{a.symbol}</span>
                  <span className="block text-[10px] text-slate-500 font-normal normal-case">
                    {a.name} · {a.type}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <Row label="Price">
              {compare.map((a) => (
                <td key={a.symbol} className="p-4 tabular-nums font-semibold text-white">
                  ${a.currentPrice.toLocaleString(undefined, { maximumFractionDigits: a.currentPrice < 1 ? 4 : 2 })}
                </td>
              ))}
            </Row>
            <Row label="24h change">
              {compare.map((a) => (
                <td key={a.symbol} className={`p-4 tabular-nums ${(a.priceChange24h ?? 0) >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {(a.priceChange24h ?? 0) >= 0 ? "▲" : "▼"} {Math.abs(a.priceChange24h ?? 0).toFixed(2)}%
                </td>
              ))}
            </Row>
            <Row label="7d return">
              {compare.map((a) => (
                <td key={a.symbol} className={`p-4 tabular-nums ${metric(a).ret7 >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {metric(a).ret7 >= 0 ? "+" : ""}
                  {metric(a).ret7.toFixed(2)}%
                </td>
              ))}
            </Row>
            <Row label="Trend (7d)">
              {compare.map((a) => (
                <td key={a.symbol} className="p-4 text-slate-300">
                  {metric(a).trend}
                </td>
              ))}
            </Row>
            <Row label="Volatility">
              {compare.map((a) => (
                <td key={a.symbol} className="p-4 tabular-nums text-slate-300">
                  {(metric(a).vol * 100).toFixed(2)}%
                </td>
              ))}
            </Row>
            <Row label="Risk score">
              {compare.map((a) => (
                <td key={a.symbol} className="p-4">
                  <span
                    className={`text-xs font-bold px-2 py-1 rounded ${
                      metric(a).risk.score < 35
                        ? "bg-emerald-500/10 text-emerald-400"
                        : metric(a).risk.score < 65
                        ? "bg-amber-500/10 text-amber-400"
                        : "bg-red-500/10 text-red-400"
                    }`}
                  >
                    {metric(a).risk.score}/100 · {metric(a).risk.label}
                  </span>
                </td>
              ))}
            </Row>
            <Row label="Mini chart">
              {compare.map((a) => (
                <td key={a.symbol} className="p-4">
                  <Spark values={a.sparkline} up={(a.sparkline?.[a.sparkline.length - 1] ?? 0) >= (a.sparkline?.[0] ?? 0)} />
                </td>
              ))}
            </Row>
          </tbody>
        </table>
      </div>

      {/* News feed */}
      {newsAsset && (
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
          <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
            <p className="text-sm font-semibold text-white">
              📰 News · {newsAsset.name}{" "}
              <span
                className={`ml-2 text-xs font-bold px-2 py-0.5 rounded ${
                  sent > 10 ? "bg-emerald-500/10 text-emerald-400" : sent < -10 ? "bg-red-500/10 text-red-400" : "bg-slate-700/40 text-slate-400"
                }`}
              >
                Sentiment {sent > 0 ? "+" : ""}
                {sent}
              </span>
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {news.map((n, i) => (
              <div key={i} className="bg-slate-950/50 border border-white/5 rounded-xl p-4">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm text-slate-200 font-medium leading-snug">{n.title}</p>
                  <span
                    className={`text-[10px] font-semibold px-1.5 py-0.5 rounded flex-shrink-0 ${
                      n.sentiment === "Positive"
                        ? "bg-emerald-500/10 text-emerald-400"
                        : n.sentiment === "Negative"
                        ? "bg-red-500/10 text-red-400"
                        : "bg-slate-700/40 text-slate-400"
                    }`}
                  >
                    {n.sentiment}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">{n.summary}</p>
                <p className="text-[10px] text-slate-600 mt-2">
                  {n.source} · {n.time}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
      {!loaded && <p className="text-center text-slate-500 text-sm py-10">Loading markets...</p>}
    </ProShell>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <tr className="border-b border-white/5 last:border-0">
      <td className="p-4 text-slate-400 text-xs font-semibold uppercase tracking-wider">{label}</td>
      {children}
    </tr>
  );
}

function Spark({ values, up }: { values: number[]; up: boolean }) {
  if (!values || values.length < 2) return null;
  const w = 120, h = 36;
  const min = Math.min(...values), max = Math.max(...values), r = max - min || 1;
  const d = values
    .map((v, i) => `${i === 0 ? "M" : "L"} ${((i / (values.length - 1)) * w).toFixed(1)} ${(h - ((v - min) / r) * (h - 4) - 2).toFixed(1)}`)
    .join(" ");
  return (
    <svg width={w} height={h}>
      <path d={d} fill="none" stroke={up ? "#34d399" : "#f87171"} strokeWidth={1.8} />
    </svg>
  );
}
