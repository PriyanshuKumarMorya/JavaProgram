"use client";

import { useEffect, useRef, useState } from "react";
import { ProShell, PageTitle } from "@/components/ProShell";
import { chatAnswer, LESSONS, QUIZ } from "@/lib/pro";

interface Msg {
  role: "user" | "ai";
  text: string;
}

export default function AssistantPage() {
  const [tab, setTab] = useState<"chat" | "learn">("chat");
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "ai",
      text: "Hi! I'm your MarketAI assistant 🤖 Ask me about risk, indicators, signals, your portfolio — or tap the mic and speak. You can also say 'open portfolio' or 'open strategy lab'.",
    },
  ]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);
  const [speakOn, setSpeakOn] = useState(true);
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [quizDone, setQuizDone] = useState(false);
  const recRef = useRef<any>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  const send = (raw?: string) => {
    const text = (raw ?? input).trim();
    if (!text) return;
    setInput("");
    setMsgs((m) => [...m, { role: "user", text }]);

    setTimeout(() => {
      const lower = text.toLowerCase();
      let reply = chatAnswer(text);
      // simple navigation commands
      if (/open portfolio/.test(lower)) window.location.href = "/portfolio";
      else if (/open strategy|open lab/.test(lower)) window.location.href = "/strategy";
      else if (/open market|compare|news/.test(lower)) window.location.href = "/markets";
      else if (/open alert/.test(lower)) window.location.href = "/alerts";

      setMsgs((m) => [...m, { role: "ai", text: reply }]);
      if (speakOn && typeof window !== "undefined" && "speechSynthesis" in window) {
        const u = new SpeechSynthesisUtterance(reply.replace(/[🤖📊📰✅⚠️📘💡]/g, ""));
        u.rate = 1.02;
        window.speechSynthesis.cancel();
        window.speechSynthesis.speak(u);
      }
    }, 400);
  };

  const toggleMic = () => {
    const SR =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      alert("Voice recognition not supported in this browser. Try Chrome.");
      return;
    }
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.onresult = (e: any) => {
      const t = e.results[0][0].transcript;
      setInput(t);
      send(t);
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  };

  const answerQuiz = (i: number) => {
    const correct = i === QUIZ[quizIdx].answer;
    const newScore = quizScore + (correct ? 1 : 0);
    setQuizScore(newScore);
    if (quizIdx + 1 >= QUIZ.length) {
      setQuizDone(true);
    } else {
      setQuizIdx(quizIdx + 1);
    }
  };

  return (
    <ProShell active="assistant">
      <PageTitle
        icon="🤖"
        title="AI Assistant"
        subtitle="Chat, voice commands and interactive learning — your 24/7 trading companion"
      />

      <div className="flex gap-2 mb-5">
        <button
          onClick={() => setTab("chat")}
          className={`px-4 py-2 rounded-lg text-sm font-semibold ${
            tab === "chat" ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400"
          }`}
        >
          💬 Chat & Voice
        </button>
        <button
          onClick={() => setTab("learn")}
          className={`px-4 py-2 rounded-lg text-sm font-semibold ${
            tab === "learn" ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400"
          }`}
        >
          📚 Learn Mode
        </button>
      </div>

      {tab === "chat" ? (
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 flex flex-col h-[65vh]">
          {/* messages */}
          <div className="flex-1 overflow-y-auto p-5 space-y-3">
            {msgs.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    m.role === "user"
                      ? "bg-indigo-600 text-white rounded-br-sm"
                      : "bg-slate-800 text-slate-200 rounded-bl-sm border border-white/5"
                  }`}
                >
                  {m.role === "ai" && <span className="mr-1.5">🤖</span>}
                  {m.text}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>

          {/* input */}
          <div className="border-t border-white/10 p-3 flex items-center gap-2">
            <button
              onClick={toggleMic}
              title="Voice input"
              className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                listening ? "bg-red-500 text-white animate-pulse" : "bg-slate-800 text-slate-300 hover:text-white"
              }`}
            >
              <svg width={18} height={18} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" />
              </svg>
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder={listening ? "Listening..." : "Ask about risk, RSI, position sizing, portfolio..."}
              className="flex-1 bg-slate-800 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500/50"
            />
            <button
              onClick={() => setSpeakOn(!speakOn)}
              title="Toggle voice replies"
              className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                speakOn ? "bg-indigo-600/30 text-indigo-300" : "bg-slate-800 text-slate-500"
              }`}
            >
              🔊
            </button>
            <button
              onClick={() => send()}
              className="px-4 h-10 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold flex-shrink-0"
            >
              Send
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Lessons */}
          <div className="space-y-4">
            {LESSONS.map((l, i) => (
              <div key={i} className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
                <p className="text-sm font-bold text-white mb-2">{l.title}</p>
                <p className="text-sm text-slate-400 leading-relaxed">{l.body}</p>
              </div>
            ))}
          </div>

          {/* Quiz */}
          <div className="rounded-2xl border border-purple-500/20 bg-purple-500/5 p-5 h-fit">
            <p className="text-sm font-bold text-white mb-3">🧠 Quick Quiz</p>
            {!quizDone ? (
              <>
                <p className="text-sm text-slate-200 mb-4">
                  Q{quizIdx + 1}/{QUIZ.length}: {QUIZ[quizIdx].q}
                </p>
                <div className="space-y-2">
                  {QUIZ[quizIdx].options.map((o, i) => (
                    <button
                      key={i}
                      onClick={() => answerQuiz(i)}
                      className="w-full text-left px-4 py-2.5 rounded-lg bg-slate-900/60 border border-white/10 text-sm text-slate-300 hover:border-indigo-500/50 hover:text-white transition-colors"
                    >
                      {o}
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-6">
                <p className="text-3xl font-extrabold text-white">
                  {quizScore}/{QUIZ.length}
                </p>
                <p className="text-sm text-slate-400 mt-2">
                  {quizScore === QUIZ.length
                    ? "🏆 Perfect! You've got the fundamentals."
                    : quizScore >= 2
                    ? "✅ Solid — review the lessons and try again."
                    : "📚 Keep learning — the lessons above cover everything."}
                </p>
                <p className="text-xs text-slate-500 mt-3">{QUIZ[quizIdx].why}</p>
                <button
                  onClick={() => {
                    setQuizIdx(0);
                    setQuizScore(0);
                    setQuizDone(false);
                  }}
                  className="mt-4 px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-semibold"
                >
                  Retry quiz
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </ProShell>
  );
}
