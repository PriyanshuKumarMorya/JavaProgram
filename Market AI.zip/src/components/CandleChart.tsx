"use client";

import { useEffect, useMemo, useRef, useState } from "react";

interface PricePoint {
  timestamp: number;
  price: number;
  date?: string;
}

interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

interface CandleChartProps {
  history: PricePoint[];
  symbol: string;
  loading: boolean;
}

const TIMEFRAMES = [
  { label: "15m", minutes: 15 },
  { label: "1h", minutes: 60 },
  { label: "4h", minutes: 240 },
  { label: "1D", minutes: 1440 },
  { label: "1W", minutes: 10080 },
];

const UP = "#10b981";
const DOWN = "#ef4444";

/** Aggregate raw price points into OHLC candles of the given size */
function toCandles(points: PricePoint[], minutes: number): Candle[] {
  if (points.length === 0) return [];
  const bucketMs = minutes * 60 * 1000;
  const map = new Map<number, Candle>();

  for (const p of points) {
    if (!Number.isFinite(p.price)) continue;
    const t = Math.floor(p.timestamp / bucketMs) * bucketMs;
    const existing = map.get(t);
    if (!existing) {
      map.set(t, {
        time: t,
        open: p.price,
        high: p.price,
        low: p.price,
        close: p.price,
      });
    } else {
      existing.high = Math.max(existing.high, p.price);
      existing.low = Math.min(existing.low, p.price);
      existing.close = p.price;
    }
  }

  return [...map.values()].sort((a, b) => a.time - b.time);
}

const fmt = (v: number) =>
  v.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: Math.abs(v) < 1 ? 5 : 2,
  });

/**
 * Pure-SVG candlestick chart — zero external dependencies.
 * Candles + volume bars + crosshair + OHLC legend + timeframes + line mode.
 */
export function CandleChart({ history, symbol, loading }: CandleChartProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(900);
  const [tf, setTf] = useState(60);
  const [chartType, setChartType] = useState<"candles" | "line">("candles");
  const [hover, setHover] = useState<number | null>(null);

  // Responsive width
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) setWidth(Math.max(320, e.contentRect.width));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const candles = useMemo(() => toCandles(history, tf), [history, tf]);

  // ── Layout constants ──
  const H = 460;
  const padR = 68;
  const padB = 26;
  const padT = 10;
  const plotW = Math.max(50, width - padR);
  const plotH = H - padB - padT;
  const volH = plotH * 0.16;
  const priceH = plotH - volH - 8;

  const n = candles.length;
  const min = n ? Math.min(...candles.map((c) => c.low)) : 0;
  const max = n ? Math.max(...candles.map((c) => c.high)) : 1;
  const range = max - min || 1;
  const maxBody = n
    ? Math.max(...candles.map((c) => Math.abs(c.close - c.open)), range * 0.001)
    : 1;

  const slotW = plotW / Math.max(1, n);
  const candleW = Math.max(1.5, Math.min(14, slotW * 0.62));
  const xFor = (i: number) => (i + 0.5) * slotW;
  const yFor = (p: number) => padT + (1 - (p - min) / range) * priceH;
  const volTop = padT + priceH + 8;

  const active = hover != null ? candles[hover] : candles[n - 1];
  const change = active ? active.close - active.open : 0;
  const changePct = active && active.open !== 0 ? (change / active.open) * 100 : 0;
  const isUp = change >= 0;
  const ohlcColor = isUp ? "text-emerald-400" : "text-red-400";

  // Price grid ticks
  const ticks = Array.from({ length: 5 }, (_, i) => min + (range * i) / 4);

  // Time ticks (~6)
  const timeTicks = useMemo(() => {
    if (n === 0) return [];
    const count = Math.min(6, n);
    const out: { i: number; label: string }[] = [];
    for (let k = 0; k < count; k++) {
      const i = Math.round((k * (n - 1)) / Math.max(1, count - 1));
      const d = new Date(candles[i].time);
      const label =
        tf < 1440
          ? d.toLocaleString(undefined, {
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })
          : d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
      out.push({ i, label });
    }
    return out;
  }, [candles, n, tf]);

  const linePath = useMemo(() => {
    if (n < 2) return "";
    return candles
      .map((c, i) => `${i === 0 ? "M" : "L"} ${xFor(i).toFixed(1)} ${yFor(c.close).toFixed(1)}`)
      .join(" ");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [candles, min, range, slotW, priceH]);

  const onMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const i = Math.min(n - 1, Math.max(0, Math.floor(x / slotW)));
    setHover(i);
  };

  return (
    <div className="bg-slate-900/70 border border-white/5 rounded-2xl overflow-hidden">
      {/* ── Toolbar ── */}
      <div className="flex items-center justify-between flex-wrap gap-2 px-4 py-3 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5">
            <button
              onClick={() => setChartType("candles")}
              title="Candlestick chart"
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                chartType === "candles"
                  ? "bg-slate-700 text-white"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              Price
            </button>
            <button
              onClick={() => setChartType("line")}
              title="Line chart"
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                chartType === "line"
                  ? "bg-slate-700 text-white"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              Line
            </button>
          </div>
          <span className="hidden sm:inline-flex items-center text-xs font-medium text-slate-400 bg-slate-800/60 border border-white/5 px-3 py-1.5 rounded-lg">
            {symbol} · Candles
          </span>
        </div>

        <div className="flex items-center gap-1 bg-slate-800/80 rounded-lg p-0.5">
          {TIMEFRAMES.map((t) => (
            <button
              key={t.minutes}
              onClick={() => {
                setTf(t.minutes);
                setHover(null);
              }}
              className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                tf === t.minutes
                  ? "bg-slate-700 text-white"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── OHLC legend ── */}
      <div className="flex items-center gap-3 px-4 py-2 text-xs font-mono flex-wrap">
        <span className="text-slate-500 font-sans font-semibold">{symbol}</span>
        {active ? (
          <>
            <span className="text-slate-500">
              O <span className={ohlcColor}>{fmt(active.open)}</span>
            </span>
            <span className="text-slate-500">
              H <span className={ohlcColor}>{fmt(active.high)}</span>
            </span>
            <span className="text-slate-500">
              L <span className={ohlcColor}>{fmt(active.low)}</span>
            </span>
            <span className="text-slate-500">
              C <span className={ohlcColor}>{fmt(active.close)}</span>
            </span>
            <span className={ohlcColor}>
              {isUp ? "+" : ""}
              {fmt(change)} ({isUp ? "+" : ""}
              {changePct.toFixed(2)}%)
            </span>
          </>
        ) : (
          <span className="text-slate-600">No data</span>
        )}
      </div>

      {/* ── SVG chart ── */}
      <div className="relative" ref={wrapRef}>
        {loading && (
          <div className="absolute inset-0 z-10 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center">
            <div className="w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
          </div>
        )}
        {n === 0 ? (
          <div className="h-[460px] flex items-center justify-center text-sm text-slate-600">
            Loading candles...
          </div>
        ) : (
          <svg
            width={width}
            height={H}
            onMouseMove={onMove}
            onMouseLeave={() => setHover(null)}
            className="block cursor-crosshair select-none"
          >
            {/* Grid + price labels */}
            {ticks.map((t, i) => (
              <g key={i}>
                <line
                  x1={0}
                  x2={plotW}
                  y1={yFor(t)}
                  y2={yFor(t)}
                  stroke="rgba(148,163,184,0.08)"
                  strokeWidth={1}
                />
                <text
                  x={plotW + 8}
                  y={yFor(t) + 3.5}
                  fill="#64748b"
                  fontSize={10.5}
                  fontFamily="ui-monospace, monospace"
                >
                  {fmt(t)}
                </text>
              </g>
            ))}

            {/* Volume bars */}
            {chartType === "candles" &&
              candles.map((c, i) => {
                const body = Math.abs(c.close - c.open);
                const h = Math.max(1, (body / maxBody) * volH);
                const upC = c.close >= c.open;
                return (
                  <rect
                    key={`v${i}`}
                    x={xFor(i) - candleW / 2}
                    y={volTop + volH - h}
                    width={candleW}
                    height={h}
                    fill={upC ? "rgba(16,185,129,0.35)" : "rgba(239,68,68,0.35)"}
                  />
                );
              })}

            {/* Candles or line */}
            {chartType === "candles" ? (
              candles.map((c, i) => {
                const upC = c.close >= c.open;
                const color = upC ? UP : DOWN;
                const bodyTop = yFor(Math.max(c.open, c.close));
                const bodyH = Math.max(1, Math.abs(yFor(c.open) - yFor(c.close)));
                return (
                  <g key={`c${i}`}>
                    <line
                      x1={xFor(i)}
                      x2={xFor(i)}
                      y1={yFor(c.high)}
                      y2={yFor(c.low)}
                      stroke={color}
                      strokeWidth={1}
                    />
                    <rect
                      x={xFor(i) - candleW / 2}
                      y={bodyTop}
                      width={candleW}
                      height={bodyH}
                      fill={color}
                      rx={0.5}
                    />
                  </g>
                );
              })
            ) : (
              <path
                d={linePath}
                fill="none"
                stroke="#38bdf8"
                strokeWidth={2}
                strokeLinejoin="round"
                strokeLinecap="round"
              />
            )}

            {/* Last price tag */}
            {candles[n - 1] && (
              <g>
                <line
                  x1={0}
                  x2={plotW}
                  y1={yFor(candles[n - 1].close)}
                  y2={yFor(candles[n - 1].close)}
                  stroke={candles[n - 1].close >= candles[n - 1].open ? UP : DOWN}
                  strokeWidth={1}
                  strokeDasharray="3 3"
                  opacity={0.5}
                />
                <rect
                  x={plotW + 2}
                  y={yFor(candles[n - 1].close) - 9}
                  width={padR - 6}
                  height={18}
                  rx={3}
                  fill={candles[n - 1].close >= candles[n - 1].open ? UP : DOWN}
                />
                <text
                  x={plotW + 6}
                  y={yFor(candles[n - 1].close) + 3.5}
                  fill="#0b1220"
                  fontSize={10.5}
                  fontWeight={700}
                  fontFamily="ui-monospace, monospace"
                >
                  {fmt(candles[n - 1].close)}
                </text>
              </g>
            )}

            {/* Crosshair */}
            {hover != null && candles[hover] && (
              <g pointerEvents="none">
                <line
                  x1={xFor(hover)}
                  x2={xFor(hover)}
                  y1={padT}
                  y2={padT + plotH}
                  stroke="rgba(148,163,184,0.35)"
                  strokeWidth={1}
                  strokeDasharray="4 4"
                />
                <line
                  x1={0}
                  x2={plotW}
                  y1={yFor(candles[hover].close)}
                  y2={yFor(candles[hover].close)}
                  stroke="rgba(148,163,184,0.35)"
                  strokeWidth={1}
                  strokeDasharray="4 4"
                />
              </g>
            )}

            {/* Time labels */}
            {timeTicks.map((t, i) => (
              <text
                key={`t${i}`}
                x={Math.min(plotW - 10, Math.max(10, xFor(t.i)))}
                y={H - 8}
                fill="#64748b"
                fontSize={10.5}
                textAnchor="middle"
                fontFamily="ui-monospace, monospace"
              >
                {t.label}
              </text>
            ))}
          </svg>
        )}
      </div>
    </div>
  );
}
