"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import type { ReactNode } from "react";
import Link from "next/link";
import { AreaChart, Area, ResponsiveContainer } from "recharts";
import { PriceCard } from "./PriceCard";
import { PriceChart } from "./PriceChart";
import { ChartModal } from "./ChartModal";
import { AIPrediction } from "./AIPrediction";
import { ProPanel } from "./ProPanel";
import { AuthChip } from "./ProShell";
import { detectRegime, radarScan } from "@/lib/pro";
import { WatchlistPanel } from "./WatchlistPanel";

interface MarketAsset {
  id: string;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number;
  marketCap: number;
  marketCapRank: number;
  totalVolume: number;
  priceChange1h: number | null;
  priceChange24h: number | null;
  priceChange7d: number | null;
  priceChange30d: number | null;
  sparkline: number[];
  high24h: number;
  low24h: number;
}

interface TypedAsset extends MarketAsset {
  type: "crypto" | "stock";
}

interface PricePoint {
  timestamp: number;
  price: number;
  date: string;
}

type FilterType = "all" | "crypto" | "stocks";

function formatPrice(v: number): string {
  return v.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: v < 1 ? 4 : 2,
  });
}

function formatLargeNumber(num: number): string {
  if (num >= 1e12) return `$${(num / 1e12).toFixed(2)}T`;
  if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`;
  if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`;
  return `$${num.toFixed(2)}`;
}

export function MarketDashboard() {
  const [filter, setFilter] = useState<FilterType>("all");
  const [search, setSearch] = useState("");
  const [cryptoAssets, setCryptoAssets] = useState<TypedAsset[]>([]);
  const [stockAssets, setStockAssets] = useState<TypedAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<TypedAsset | null>(null);
  const [history, setHistory] = useState<PricePoint[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [modalAsset, setModalAsset] = useState<TypedAsset | null>(null);
  const detailRef = useRef<HTMLDivElement>(null);

  // Click a top graph → open TradingView-style chart in a full popup
  // (the bottom detail graph stays unchanged)
  const openAssetChart = useCallback((asset: TypedAsset) => {
    setSelectedAsset(asset);
    setModalAsset(asset);
  }, []);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [cRes, sRes] = await Promise.all([
        fetch("/api/market/crypto"),
        fetch("/api/market/stocks"),
      ]);
      if (!cRes.ok || !sRes.ok) throw new Error("Failed to fetch market data");
      const c = (await cRes.json()) as MarketAsset[];
      const s = (await sRes.json()) as MarketAsset[];
      const typedC: TypedAsset[] = c.map((a) => ({ ...a, type: "crypto" }));
      const typedS: TypedAsset[] = s.map((a) => ({ ...a, type: "stock" }));
      setCryptoAssets(typedC);
      setStockAssets(typedS);
      setSelectedAsset((prev) => prev ?? typedC[0] ?? typedS[0] ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchHistory = useCallback(async (asset: TypedAsset) => {
    setHistoryLoading(true);
    try {
      const endpoint =
        asset.type === "crypto"
          ? `/api/market/crypto/${asset.id}/history`
          : `/api/market/stocks/${asset.id}/history`;
      const res = await fetch(endpoint);
      if (!res.ok) throw new Error("Failed to fetch history");
      const data = await res.json();
      setHistory(data.prices || []);
    } catch {
      setHistory([]);
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
    const interval = setInterval(fetchAll, 60000);
    return () => clearInterval(interval);
  }, [fetchAll]);

  useEffect(() => {
    if (selectedAsset) fetchHistory(selectedAsset);
  }, [selectedAsset, fetchHistory]);

  // Stable combined asset list (memoized so child memos don't invalidate)
  const allAssets = useMemo(
    () => [...cryptoAssets, ...stockAssets],
    [cryptoAssets, stockAssets]
  );

  // Market regime from the aggregated crypto index
  const regime = useMemo(() => {
    const idx = buildIndex(cryptoAssets).map((d) => d.v);
    return detectRegime(idx);
  }, [cryptoAssets]);

  // AI opportunity radar across all assets
  const radar = useMemo(() => radarScan(allAssets), [allAssets]);

  // Combined + filtered asset list
  const visibleAssets = useMemo(() => {
    const base: TypedAsset[] =
      filter === "all"
        ? [...cryptoAssets, ...stockAssets]
        : filter === "crypto"
        ? cryptoAssets
        : stockAssets;
    const q = search.trim().toLowerCase();
    if (!q) return base;
    return base.filter(
      (a) =>
        a.symbol.toLowerCase().includes(q) || a.name.toLowerCase().includes(q)
    );
  }, [filter, search, cryptoAssets, stockAssets]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950">
      {/* Header */}
      <header className="border-b border-white/10 bg-slate-900/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/25">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <h1 className="text-xl font-bold text-white tracking-tight">
                Market<span className="text-blue-400">AI</span>
              </h1>
            </div>
            <nav className="hidden lg:flex items-center gap-1">
              {[
                { href: "/markets", label: "📰 Markets" },
                { href: "/portfolio", label: "📊 Portfolio" },
                { href: "/assistant", label: "🤖 Assistant" },
                { href: "/sync", label: "🔄 Sync" },
              ].map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors"
                >
                  {l.label}
                </Link>
              ))}
            </nav>
            <AuthChip />
            <span className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-800 px-3 py-1.5 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              Live
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
        {loading && cryptoAssets.length === 0 && stockAssets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-10 h-10 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
            <p className="text-slate-400 text-sm">Loading market data...</p>
          </div>
        ) : error ? (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-6 text-center">
            <p className="text-red-400">{error}</p>
            <button
              onClick={fetchAll}
              className="mt-3 px-4 py-2 bg-red-500/20 text-red-300 rounded-lg text-sm hover:bg-red-500/30 transition-colors"
            >
              Retry
            </button>
          </div>
        ) : (
          <>
            {/* ── Market Regime Detector + AI Opportunity Radar ── */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Regime */}
              <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5">
                <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                  🧭 Market Regime Detector
                </p>
                <p className="mt-2 text-2xl font-extrabold" style={{ color: regime.color }}>
                  {regime.emoji} {regime.regime.toUpperCase()}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Confidence {regime.confidence}%
                </p>
                <div className="mt-2 h-1.5 bg-slate-700/60 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${regime.confidence}%`, background: regime.color }}
                  />
                </div>
                <ul className="mt-3 space-y-1">
                  {regime.analysis.map((t, i) => (
                    <li key={i} className="text-[11px] text-slate-400 flex gap-1.5">
                      <span style={{ color: regime.color }}>•</span> {t}
                    </li>
                  ))}
                </ul>
                <p className="mt-3 text-[11px] text-slate-300 bg-slate-950/50 border border-white/5 rounded-lg p-2">
                  💡 {regime.approach}
                </p>
              </div>

              {/* Radar */}
              <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-slate-900/60 p-5">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
                    📡 AI Opportunity Radar
                  </p>
                  <span className="text-[10px] text-slate-500">
                    Scanned {radar.length} assets · live
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-3">
                  {radar.slice(0, 6).map((r) => (
                    <button
                      key={r.id}
                      onClick={() => {
                        const a = allAssets.find((x) => x.id === r.id);
                        if (a) setSelectedAsset(a);
                      }}
                      className="text-left rounded-xl border border-white/5 bg-slate-950/50 p-3 hover:border-indigo-500/40 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-bold text-white">{r.symbol}</span>
                        <span className="text-[10px] font-semibold" style={{ color: r.color }}>
                          {r.emoji} {r.setup}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-0.5 tabular-nums">
                        Confidence {r.confidence}% · 7d {r.ret7 >= 0 ? "+" : ""}
                        {r.ret7.toFixed(1)}% · RSI {r.rsi.toFixed(0)}
                      </p>
                      <div className="mt-2 h-1 bg-slate-700/60 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${r.confidence}%`, background: r.color }}
                        />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* ── Market overview charts + 6 selectable asset cards ── */}
            <MarketShowcase
              cryptoAssets={cryptoAssets}
              stockAssets={stockAssets}
              onOpenAsset={openAssetChart}
            />

            {/* ── Filter Pills + Search ── */}
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-1 bg-slate-800/60 border border-white/5 rounded-lg p-1">
                {(
                  [
                    { key: "all", label: "All" },
                    { key: "crypto", label: "Crypto" },
                    { key: "stocks", label: "Stocks" },
                  ] as { key: FilterType; label: string }[]
                ).map((f) => (
                  <button
                    key={f.key}
                    onClick={() => setFilter(f.key)}
                    className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                      filter === f.key
                        ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
              <div className="relative flex-1 min-w-[220px]">
                <svg
                  className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-4.35-4.35M17 10.5a6.5 6.5 0 11-13 0 6.5 6.5 0 0113 0z"
                  />
                </svg>
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search asset..."
                  className="w-full bg-slate-800/60 border border-white/5 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500/50 transition-colors"
                />
              </div>
            </div>

            {/* ── Main Grid ── */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Panel - Asset List */}
              <div className="lg:col-span-1 space-y-4">
                <div className="bg-slate-800/50 border border-white/5 rounded-2xl p-4">
                  <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
                    {filter === "all"
                      ? "All Assets"
                      : filter === "crypto"
                      ? "Top Cryptocurrencies"
                      : "Top Stocks"}
                    <span className="ml-2 text-xs text-slate-500 font-normal normal-case">
                      {visibleAssets.length}
                    </span>
                  </h2>
                  <div className="space-y-1 max-h-[600px] overflow-y-auto pr-1 custom-scrollbar">
                    {visibleAssets.length === 0 ? (
                      <p className="text-xs text-slate-600 py-6 text-center">
                        No assets match your search.
                      </p>
                    ) : (
                      visibleAssets.map((asset) => (
                        <PriceCard
                          key={asset.id}
                          asset={asset}
                          isSelected={selectedAsset?.id === asset.id}
                          onClick={() => setSelectedAsset(asset)}
                        />
                      ))
                    )}
                  </div>
                </div>
                <WatchlistPanel
                  activeTab={filter === "stocks" ? "stocks" : "crypto"}
                  onSelectAsset={(symbol: string) => {
                    const found = [...cryptoAssets, ...stockAssets].find(
                      (a) => a.symbol.toLowerCase() === symbol.toLowerCase()
                    );
                    if (found) setSelectedAsset(found);
                  }}
                />
              </div>

              {/* Right Panel - Chart & Prediction (scroll target) */}
              <div
                ref={detailRef}
                className="lg:col-span-2 space-y-6 scroll-mt-20"
              >
                {selectedAsset ? (
                  <>
                    {/* Asset Header */}
                    <div className="bg-slate-800/50 border border-white/5 rounded-2xl p-6">
                      <div className="flex items-center gap-4">
                        <img
                          src={selectedAsset.image}
                          alt={selectedAsset.name}
                          className="w-14 h-14 rounded-full bg-slate-700"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              "data:image/svg+xml," +
                              encodeURIComponent(
                                `<svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" viewBox="0 0 56 56"><rect width="56" height="56" rx="28" fill="#334155"/><text x="28" y="32" text-anchor="middle" fill="white" font-size="24" font-family="sans-serif">${selectedAsset.symbol[0]}</text></svg>`
                              );
                          }}
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="text-2xl font-bold text-white">
                              {selectedAsset.name}
                            </h3>
                            <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 bg-slate-700/60 px-2 py-0.5 rounded">
                              {selectedAsset.type === "crypto" ? "Crypto" : "Stock"}
                            </span>
                          </div>
                          <p className="text-slate-400 text-sm">{selectedAsset.symbol}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-3xl font-bold text-white tabular-nums">
                            ${formatPrice(selectedAsset.currentPrice)}
                          </p>
                          <PriceChange value={selectedAsset.priceChange24h} />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
                        <StatBox label="Market Cap" value={formatLargeNumber(selectedAsset.marketCap)} />
                        <StatBox label="24h Volume" value={formatLargeNumber(selectedAsset.totalVolume)} />
                        <StatBox label="24h High" value={`$${selectedAsset.high24h.toLocaleString()}`} />
                        <StatBox label="24h Low" value={`$${selectedAsset.low24h.toLocaleString()}`} />
                      </div>

                      <div className="flex gap-3 mt-4 flex-wrap">
                        <ChangeChip label="1h" value={selectedAsset.priceChange1h} />
                        <ChangeChip label="24h" value={selectedAsset.priceChange24h} />
                        <ChangeChip label="7d" value={selectedAsset.priceChange7d} />
                        <ChangeChip label="30d" value={selectedAsset.priceChange30d} />
                      </div>


                    </div>

                    <PriceChart
                      history={history}
                      sparkline={selectedAsset.sparkline}
                      loading={historyLoading}
                      symbol={selectedAsset.symbol}
                    />

                    <AIPrediction
                      symbol={selectedAsset.symbol}
                      assetType={selectedAsset.type === "crypto" ? "crypto" : "stock"}
                      assetId={selectedAsset.id}
                      allAssets={allAssets}
                      history={history}
                      currentPrice={selectedAsset.currentPrice}
                    />

                    {/* Pro tools: recommendation, risk, alerts, news,
                        compare, coach, learn + voice */}
                    <ProPanel asset={selectedAsset} history={history} />
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center py-20 text-slate-500 bg-slate-800/30 border border-white/5 rounded-2xl">
                    <svg className="w-16 h-16 mb-4 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                    </svg>
                    <p className="text-lg font-medium">Select an asset to view details</p>
                    <p className="text-sm mt-1">Click any card or row above</p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </main>

      {/* TradingView-style chart popup (opened from top graphs) */}
      <ChartModal
        asset={modalAsset}
        allAssets={allAssets}
        onClose={() => setModalAsset(null)}
      />
    </div>
  );
}

function buildIndex(
  assets: TypedAsset[],
  points = 80
): { i: number; v: number }[] {
  const series = assets
    .map((a) => a.sparkline)
    .filter((s) => s && s.length > 10);
  if (series.length === 0) return [];

  const minLen = Math.min(...series.map((s) => s.length));
  const step = Math.max(1, Math.floor(minLen / points));
  const normalized = series.map((s) => {
    const base = s[0] || 1;
    return s.map((v) => (v / base) * 100);
  });

  const out: { i: number; v: number }[] = [];
  let idx = 0;
  for (let i = 0; i < minLen; i += step) {
    let sum = 0;
    for (const n of normalized) sum += n[i];
    out.push({ i: idx++, v: Math.round((sum / normalized.length) * 100) / 100 });
  }
  return out;
}

/* ── Market overview (2 index charts) + 6 selectable asset cards ── */
function MarketShowcase({
  cryptoAssets,
  stockAssets,
  onOpenAsset,
}: {
  cryptoAssets: TypedAsset[];
  stockAssets: TypedAsset[];
  onOpenAsset: (asset: TypedAsset) => void;
}) {
  const allAssets = useMemo(
    () => [...cryptoAssets, ...stockAssets],
    [cryptoAssets, stockAssets]
  );
  const cryptoIndex = useMemo(() => buildIndex(cryptoAssets), [cryptoAssets]);
  const stockIndex = useMemo(() => buildIndex(stockAssets), [stockAssets]);

  // 6 slots — user can manually change each via dropdown
  const [slots, setSlots] = useState<string[]>([]);
  useEffect(() => {
    if (slots.length === 0 && cryptoAssets.length >= 3 && stockAssets.length >= 3) {
      setSlots([
        cryptoAssets[0].id,
        cryptoAssets[1].id,
        cryptoAssets[2].id,
        stockAssets[0].id,
        stockAssets[1].id,
        stockAssets[2].id,
      ]);
    }
  }, [cryptoAssets, stockAssets, slots.length]);

  const handleSlotChange = (index: number, id: string) => {
    setSlots((prev) => prev.map((s, i) => (i === index ? id : s)));
  };

  if (allAssets.length === 0) return null;

  return (
    <div className="space-y-4">
      {/* ── Top: Crypto vs Stock market index charts ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <OverviewCard
          title="Crypto Market"
          subtitle="Top 10 coins · 7d index"
          data={cryptoIndex}
          color="#22d3ee"
          titleClass="text-cyan-400"
          icon={
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1.2 14.6c-.5.14-1 .22-1.2.24V18h-1.5v-1.16c-1.7-.12-2.9-1.16-2.9-2.7h1.9c.1.83.65 1.2 1.6 1.2 1 0 1.4-.4 1.4-.9 0-.44-.3-.74-1.4-1-1.6-.4-2.7-1.1-2.7-2.5 0-1.3 1-2.1 2.4-2.34V7.5H12v1.1c1.5.2 2.5 1.1 2.6 2.5h-1.9c-.1-.7-.6-1.1-1.4-1.1-.8 0-1.3.4-1.3.9 0 .5.4.7 1.5 1 1.7.5 2.7 1.2 2.7 2.6 0 1.4-1.1 2.2-2.5 2.4z" />
            </svg>
          }
        />
        <OverviewCard
          title="Stock Market"
          subtitle="Top 10 stocks · 7d index"
          data={stockIndex}
          color="#a78bfa"
          titleClass="text-purple-400"
          icon={
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          }
        />
      </div>

      {/* ── Bottom: 6 selectable asset cards (3 crypto + 3 stocks) ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {slots.map((id, idx) => {
          const asset = allAssets.find((a) => a.id === id) ?? allAssets[idx];
          if (!asset) return null;
          return (
            <AssetMiniCard
              key={idx}
              asset={asset}
              allAssets={allAssets}
              onChange={(newId) => handleSlotChange(idx, newId)}
              onOpen={() => onOpenAsset(asset)}
            />
          );
        })}
      </div>
    </div>
  );
}

/* ── Market index overview card (Crypto = cyan, Stock = purple) ── */
function OverviewCard({
  title,
  subtitle,
  data,
  color,
  titleClass,
  icon,
}: {
  title: string;
  subtitle: string;
  data: { i: number; v: number }[];
  color: string;
  titleClass: string;
  icon: ReactNode;
}) {
  const change =
    data.length > 1 && data[0].v !== 0
      ? ((data[data.length - 1].v - data[0].v) / data[0].v) * 100
      : 0;
  const up = change >= 0;
  const gid = `ov-${title.replace(/\s+/g, "")}`;

  return (
    <div className="bg-slate-900/60 border border-white/5 rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className={titleClass}>{icon}</span>
          <div>
            <h3 className={`text-sm font-bold ${titleClass}`}>{title}</h3>
            <p className="text-xs text-slate-500">{subtitle}</p>
          </div>
        </div>
        <span
          className={`text-sm font-bold tabular-nums ${
            up ? "text-emerald-400" : "text-red-400"
          }`}
        >
          {up ? "▲" : "▼"} {Math.abs(change).toFixed(2)}%
        </span>
      </div>
      {data.length > 1 ? (
        <ResponsiveContainer width="100%" height={120}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.35} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area
              type="monotone"
              dataKey="v"
              stroke={color}
              strokeWidth={2.5}
              fill={`url(#${gid})`}
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      ) : (
        <div className="h-[120px] flex items-center justify-center text-xs text-slate-600">
          Loading market data...
        </div>
      )}
    </div>
  );
}

/* ── Selectable asset card: crypto = gold graph, stock = cyan graph ── */
function AssetMiniCard({
  asset,
  allAssets,
  onChange,
  onOpen,
}: {
  asset: TypedAsset;
  allAssets: TypedAsset[];
  onChange: (id: string) => void;
  onOpen: () => void;
}) {
  const change = asset.priceChange24h ?? 0;
  const up = change >= 0;
  const isCrypto = asset.type === "crypto";
  // Crypto graphs = gold/amber, Stock graphs = cyan
  const color = isCrypto ? "#f59e0b" : "#22d3ee";
  const gid = `mini-${asset.id}`;

  const data = useMemo(
    () => (asset.sparkline || []).map((v, i) => ({ i, v })),
    [asset.sparkline]
  );

  const cryptoOptions = allAssets.filter((a) => a.type === "crypto");
  const stockOptions = allAssets.filter((a) => a.type === "stock");

  return (
    <div
      onClick={onOpen}
      title="Click to open full information"
      className="min-w-0 rounded-2xl bg-slate-900/60 border border-white/5 p-4 hover:border-indigo-500/40 hover:bg-slate-900/80 transition-colors cursor-pointer group"
    >
      {/* Header: icon + selectable name + change */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <span
            className={`w-9 h-9 rounded-full bg-slate-800 ring-1 flex-shrink-0 overflow-hidden ${
              isCrypto ? "ring-amber-400/40" : "ring-cyan-400/40"
            }`}
          >
            <img
              src={asset.image}
              alt={asset.name}
              className="w-9 h-9 rounded-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  "data:image/svg+xml," +
                  encodeURIComponent(
                    `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36"><rect width="36" height="36" rx="18" fill="#475569"/><text x="18" y="23" text-anchor="middle" fill="white" font-size="16" font-family="sans-serif">${asset.symbol[0]}</text></svg>`
                  );
              }}
            />
          </span>
          <div className="min-w-0">
            {/* Manual asset selector (shows asset name) — click doesn't open details */}
            <div
              className="relative inline-block max-w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <select
                value={asset.id}
                onChange={(e) => onChange(e.target.value)}
                title="Change asset"
                className="appearance-none bg-transparent text-sm font-bold text-white focus:outline-none cursor-pointer pr-5 hover:text-blue-400 transition-colors max-w-[150px]"
              >
                <optgroup label="🪙 Crypto">
                  {cryptoOptions.map((a) => (
                    <option key={a.id} value={a.id} className="bg-slate-900 text-white">
                      {a.name}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="📈 Stocks">
                  {stockOptions.map((a) => (
                    <option key={a.id} value={a.id} className="bg-slate-900 text-white">
                      {a.name}
                    </option>
                  ))}
                </optgroup>
              </select>
              <svg
                className="w-3 h-3 text-slate-500 absolute right-0 top-1/2 -translate-y-1/2 pointer-events-none"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2.5}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </div>
            <p
              className={`text-[10px] font-semibold uppercase tracking-wider ${
                isCrypto ? "text-amber-400" : "text-cyan-400"
              }`}
            >
              {isCrypto ? "Crypto" : "Stock"}
            </p>
          </div>
        </div>
        <span
          className={`text-xs font-bold tabular-nums flex-shrink-0 ${
            up ? "text-emerald-400" : "text-red-400"
          }`}
        >
          {up ? "▲" : "▼"} {Math.abs(change).toFixed(2)}%
        </span>
      </div>

      {/* Price */}
      <p className="mt-3 text-2xl font-extrabold text-white tabular-nums">
        ${formatPrice(asset.currentPrice)}
      </p>

      {/* Area graph (gold for crypto, cyan for stocks) */}
      <div className="mt-3 h-[110px] rounded-lg overflow-hidden">
        {data.length > 1 ? (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={color} stopOpacity={0.4} />
                  <stop offset="100%" stopColor={color} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="v"
                stroke={color}
                strokeWidth={2}
                fill={`url(#${gid})`}
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-full flex items-center justify-center text-xs text-slate-600">
            No data
          </div>
        )}
      </div>
    </div>
  );
}

function PriceChange({ value }: { value: number | null }) {
  if (value === null || value === undefined) return null;
  const isPositive = value >= 0;
  return (
    <span
      className={`text-sm font-semibold tabular-nums ${
        isPositive ? "text-emerald-400" : "text-red-400"
      }`}
    >
      {isPositive ? "+" : ""}
      {value.toFixed(2)}%
    </span>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-slate-900/50 border border-white/5 rounded-xl p-3">
      <p className="text-xs text-slate-500 mb-1">{label}</p>
      <p className="text-sm font-semibold text-slate-200">{value}</p>
    </div>
  );
}

function ChangeChip({ label, value }: { label: string; value: number | null }) {
  if (value === null || value === undefined) return null;
  const isPositive = value >= 0;
  return (
    <span
      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold ${
        isPositive
          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
          : "bg-red-500/10 text-red-400 border border-red-500/20"
      }`}
    >
      <span className="text-slate-500">{label}</span>
      {isPositive ? "↑" : "↓"} {Math.abs(value).toFixed(2)}%
    </span>
  );
}
