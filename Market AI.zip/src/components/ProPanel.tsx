"use client";

import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { recommend, riskScore, stdevReturns, rsi14 } from "@/lib/pro";

interface PricePoint {
  timestamp: number;
  price: number;
}

interface ProAsset {
  id: string;
  symbol: string;
  name: string;
  type: "crypto" | "stock";
  currentPrice: number;
  priceChange24h: number | null;
  sparkline: number[];
}

interface ProPanelProps {
  asset: ProAsset;
  history: PricePoint[];
}

/**
 * MarketAI Pro Tools — focused set:
 * 1. AI Buy/Sell/Hold recommendation
 * 2. Risk Score (0–100)
 * 3. Risk Management calculator (SL / TP / size / R:R)
 */
export function ProPanel({ asset, history }: ProPanelProps) {
  const prices = useMemo(
    () => history.map((p) => p.price).filter(Number.isFinite),
    [history]
  );

  const rec = useMemo(
    () => (prices.length > 30 ? recommend(prices, asset.priceChange24h ?? 0) : null),
    [prices, asset]
  );
  const risk = useMemo(
    () => (prices.length > 10 ? riskScore(prices, asset.priceChange24h ?? 0) : null),
    [prices, asset]
  );

  // Risk management calculator
  const [account, setAccount] = useState(10000);
  const [riskPct, setRiskPct] = useState(2);
  const [sl, setSl] = useState(0);
  const [tp, setTp] = useState(0);
  useEffect(() => {
    if (rec) {
      setSl(Math.round(rec.stopLoss * 100) / 100);
      setTp(Math.round(rec.target * 100) / 100);
    }
  }, [rec, asset.id]);

  const entry = asset.currentPrice;
  const riskAmt = (account * riskPct) / 100;
  const perUnit = Math.abs(entry - sl);
  const qty = perUnit > 0 ? riskAmt / perUnit : 0;
  const rr = perUnit > 0 ? Math.abs(tp - entry) / perUnit : 0;

  const sigColor =
    rec?.signal === "BUY"
      ? "text-emerald-400 border-emerald-500/40 bg-emerald-500/5"
      : rec?.signal === "SELL"
      ? "text-red-400 border-red-500/40 bg-red-500/5"
      : "text-amber-400 border-amber-500/40 bg-amber-500/5";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
          ⚡ MarketAI Pro Tools
        </h3>
        <span className="text-[10px] text-slate-500">for {asset.symbol}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1 · AI Buy/Sell/Hold */}
        <div className={`rounded-2xl border p-4 ${sigColor}`}>
          <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
            🤖 AI Recommendation
          </p>
          <p className="mt-1.5 text-3xl font-extrabold">{rec?.signal ?? "—"}</p>
          <p className="text-xs text-slate-300 mt-0.5">Confidence {rec?.confidence ?? 0}%</p>
          <div className="mt-2 h-1.5 bg-slate-700/60 rounded-full overflow-hidden">
            <div
              className="h-full bg-current rounded-full"
              style={{ width: `${rec?.confidence ?? 0}%` }}
            />
          </div>
          <div className="grid grid-cols-3 gap-2 mt-3 text-center">
            <Mini label="ENTRY" value={`$${entry.toFixed(2)}`} tone="text-white" />
            <Mini label="STOP" value={`$${sl.toFixed(2)}`} tone="text-red-400" />
            <Mini label="TARGET" value={`$${tp.toFixed(2)}`} tone="text-emerald-400" />
          </div>
          {rec?.reasons[0] && (
            <p className="text-[11px] text-slate-400 mt-2">• {rec.reasons[0]}</p>
          )}
        </div>

        {/* 2 · Risk Score */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
          <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
            ⚠️ Risk Score
          </p>
          <div className="flex items-center gap-4 mt-2">
            <div className="relative w-20 h-20">
              <svg viewBox="0 0 100 100" className="w-20 h-20 -rotate-90">
                <circle cx="50" cy="50" r="42" fill="none" stroke="#1e293b" strokeWidth="10" />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke={
                    (risk?.score ?? 0) < 35
                      ? "#10b981"
                      : (risk?.score ?? 0) < 65
                      ? "#f59e0b"
                      : "#ef4444"
                  }
                  strokeWidth="10"
                  strokeDasharray={`${((risk?.score ?? 0) / 100) * 264} 264`}
                  strokeLinecap="round"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-xl font-extrabold text-white">
                {risk?.score ?? 0}
              </span>
            </div>
            <div className="text-xs text-slate-400 space-y-1">
              <p
                className={`font-bold ${
                  risk?.label === "Low"
                    ? "text-emerald-400"
                    : risk?.label === "Medium"
                    ? "text-amber-400"
                    : "text-red-400"
                }`}
              >
                {risk?.label ?? "—"} risk
              </p>
              <p>Volatility {(stdevReturns(prices) * 100).toFixed(2)}%</p>
              <p>RSI {rsi14(prices).toFixed(0)}</p>
            </div>
          </div>
        </div>

        {/* 3 · Risk Management calculator (full width) */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-4 md:col-span-2">
          <p className="text-[11px] uppercase tracking-wider font-semibold text-slate-400">
            🛡️ Risk Management
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
            <Field label="Account $">
              <input type="number" value={account} onChange={(e) => setAccount(Number(e.target.value))} className="inp" />
            </Field>
            <Field label="Risk %">
              <input type="number" step="0.5" value={riskPct} onChange={(e) => setRiskPct(Number(e.target.value))} className="inp" />
            </Field>
            <Field label="Stop loss">
              <input type="number" value={sl} onChange={(e) => setSl(Number(e.target.value))} className="inp" />
            </Field>
            <Field label="Take profit">
              <input type="number" value={tp} onChange={(e) => setTp(Number(e.target.value))} className="inp" />
            </Field>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-2">
            <Mini label="RISK $" value={`$${riskAmt.toFixed(0)}`} tone="text-red-400" />
            <Mini label="POSITION SIZE" value={`$${(qty * entry).toFixed(0)}`} tone="text-white" />
            <Mini label="QUANTITY" value={qty >= 1 ? qty.toFixed(2) : qty.toFixed(5)} tone="text-white" />
          </div>
          <p className={`text-[11px] mt-2 ${rr >= 2 ? "text-emerald-400" : "text-amber-400"}`}>
            Risk : Reward = 1:{rr.toFixed(2)} {rr >= 2 ? "✅ healthy" : "⚠️ aim for ≥ 1:2"}
          </p>
        </div>
      </div>
    </div>
  );
}

function Mini({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="bg-slate-950/50 border border-white/5 rounded-lg p-1.5">
      <p className="text-[9px] text-slate-500">{label}</p>
      <p className={`text-xs font-bold tabular-nums ${tone}`}>{value}</p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-[10px] text-slate-500">{label}</span>
      {children}
    </label>
  );
}
