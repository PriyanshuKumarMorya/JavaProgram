"use client";

import { useState, useMemo } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

interface PricePoint {
  timestamp: number;
  price: number;
  date: string;
}

interface PriceChartProps {
  history: PricePoint[];
  sparkline: number[];
  loading: boolean;
  symbol: string;
}

type TimeRange = "1d" | "7d" | "30d";

export function PriceChart({
  history,
  sparkline,
  loading,
  symbol,
}: PriceChartProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>("7d");

  const chartData = useMemo(() => {
    if (history && history.length > 0) {
      const now = Date.now();
      const ranges: Record<TimeRange, number> = {
        "1d": 24 * 60 * 60 * 1000,
        "7d": 7 * 24 * 60 * 60 * 1000,
        "30d": 30 * 24 * 60 * 60 * 1000,
      };
      const cutoff = now - ranges[timeRange];
      const filtered = history.filter((p) => p.timestamp >= cutoff);

      if (filtered.length > 0) {
        return filtered.map((p) => ({
          time: new Date(p.timestamp).toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
            hour: timeRange === "1d" ? "2-digit" : undefined,
          }),
          price: p.price,
          fullDate: new Date(p.timestamp).toLocaleString(),
        }));
      }
    }

    // Fallback: use sparkline data
    if (sparkline && sparkline.length > 0) {
      const pointsToShow =
        timeRange === "1d"
          ? sparkline.slice(-24)
          : timeRange === "7d"
          ? sparkline
          : sparkline;

      return pointsToShow.map((price, i) => ({
        time: String(i),
        price,
        fullDate: `Point ${i + 1}`,
      }));
    }

    return [];
  }, [history, sparkline, timeRange]);

  const isPositive =
    chartData.length > 1 &&
    chartData[chartData.length - 1].price >= chartData[0].price;

  const gradientColor = isPositive ? "#34d399" : "#f87171";

  if (loading) {
    return (
      <div className="bg-slate-800/50 border border-white/5 rounded-2xl p-6 h-[400px] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-slate-800/50 border border-white/5 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
          {symbol} Price Chart
        </h3>
        <div className="flex gap-1 bg-slate-900/50 rounded-lg p-1">
          {(["1d", "7d", "30d"] as TimeRange[]).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${
                timeRange === range
                  ? "bg-blue-500/20 text-blue-400"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {chartData.length === 0 ? (
        <div className="h-[350px] flex items-center justify-center text-slate-500">
          No chart data available
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={350}>
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id={`chartGradient-${symbol}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={gradientColor} stopOpacity={0.25} />
                <stop offset="100%" stopColor={gradientColor} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(255,255,255,0.05)"
              vertical={false}
            />
            <XAxis
              dataKey="time"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#64748b", fontSize: 11 }}
              interval="preserveStartEnd"
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#64748b", fontSize: 11 }}
              domain={["auto", "auto"]}
              tickFormatter={(v: number) =>
                v >= 1000 ? `$${(v / 1000).toFixed(1)}k` : `$${v.toFixed(v < 1 ? 4 : 2)}`
              }
              width={70}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1e293b",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: "12px",
                color: "#f1f5f9",
                boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
              }}
              formatter={(value) => {
                const num = Number(value);
                return [
                  `$${num.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: num < 1 ? 6 : 2,
                  })}`,
                  "Price",
                ];
              }}
              labelFormatter={(label) => label}
            />
            <Area
              type="monotone"
              dataKey="price"
              stroke={gradientColor}
              strokeWidth={2}
              fill={`url(#chartGradient-${symbol})`}
              animationDuration={800}
            />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
