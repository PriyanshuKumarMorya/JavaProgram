"use client";

import { useState, useEffect, useCallback } from "react";

interface WatchlistItem {
  id: number;
  symbol: string;
  assetType: string;
  name: string;
  addedAt: string;
}

interface WatchlistPanelProps {
  activeTab: "crypto" | "stocks";
  onSelectAsset: (symbol: string, name: string) => void;
}

export function WatchlistPanel({ activeTab, onSelectAsset }: WatchlistPanelProps) {
  const [items, setItems] = useState<WatchlistItem[]>([]);
  const [newSymbol, setNewSymbol] = useState("");
  const [newName, setNewName] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const fetchWatchlist = useCallback(async () => {
    try {
      const res = await fetch(`/api/watchlist?assetType=${activeTab}`);
      if (res.ok) {
        const data = await res.json();
        setItems(data);
      }
    } catch {
      // ignore
    }
  }, [activeTab]);

  useEffect(() => {
    fetchWatchlist();
  }, [fetchWatchlist]);

  const addToWatchlist = async () => {
    if (!newSymbol.trim()) return;
    try {
      const res = await fetch("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: newSymbol.trim().toUpperCase(),
          assetType: activeTab,
          name: newName.trim() || newSymbol.trim().toUpperCase(),
        }),
      });
      if (res.ok) {
        setNewSymbol("");
        setNewName("");
        setShowAdd(false);
        fetchWatchlist();
      }
    } catch {
      // ignore
    }
  };

  const removeFromWatchlist = async (id: number) => {
    try {
      await fetch(`/api/watchlist?id=${id}`, { method: "DELETE" });
      fetchWatchlist();
    } catch {
      // ignore
    }
  };

  return (
    <div className="bg-slate-800/50 border border-white/5 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
          ⭐ Watchlist
        </h2>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
        >
          {showAdd ? "Cancel" : "+ Add"}
        </button>
      </div>

      {showAdd && (
        <div className="mb-3 p-3 bg-slate-900/50 border border-white/5 rounded-xl space-y-2">
          <input
            type="text"
            placeholder={activeTab === "crypto" ? "e.g. BTC, ETH" : "e.g. AAPL, TSLA"}
            value={newSymbol}
            onChange={(e) => setNewSymbol(e.target.value)}
            className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500/50"
            onKeyDown={(e) => e.key === "Enter" && addToWatchlist()}
          />
          <input
            type="text"
            placeholder="Name (optional)"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500/50"
            onKeyDown={(e) => e.key === "Enter" && addToWatchlist()}
          />
          <button
            onClick={addToWatchlist}
            className="w-full py-2 bg-blue-500/20 text-blue-400 rounded-lg text-xs font-semibold hover:bg-blue-500/30 transition-colors"
          >
            Add to Watchlist
          </button>
        </div>
      )}

      {items.length === 0 ? (
        <p className="text-xs text-slate-600 py-4 text-center">
          No items in watchlist. Add some to track them here.
        </p>
      ) : (
        <div className="space-y-1 max-h-[200px] overflow-y-auto">
          {items.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-700/30 transition-colors group"
            >
              <button
                onClick={() => onSelectAsset(item.symbol, item.name)}
                className="flex-1 text-left"
              >
                <p className="text-sm font-medium text-white">{item.symbol}</p>
                <p className="text-xs text-slate-500">{item.name}</p>
              </button>
              <button
                onClick={() => removeFromWatchlist(item.id)}
                className="text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all text-xs px-2"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
