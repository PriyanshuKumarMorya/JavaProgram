"use client";

import { useEffect, useState } from "react";
import { CandleChart } from "./CandleChart";
import { TradingViewChart, toTradingViewSymbol } from "./TradingViewChart";
import { AIPrediction, type AssetOption } from "./AIPrediction";

interface PricePoint {
  timestamp: number;
  price: number;
  date?: string;
}

export interface ChartModalAsset {
  id: string;
  symbol: string;
  name: string;
  type: "crypto" | "stock";
  image: string;
  currentPrice: number;
  priceChange24h: number | null;
}

interface ChartModalProps {
  asset: ChartModalAsset | null;
  allAssets: AssetOption[];
  onClose: () => void;
}

export function ChartModal({ asset, allAssets, onClose }: ChartModalProps) {
  const [history, setHistory] = useState<PricePoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<"tv" | "local">("tv");

  // Fetch 30-day history (used by local candles + AI prediction)
  useEffect(() => {
    if (!asset) return;
    let cancelled = false;
    setLoading(true);
    setHistory([]);
    const endpoint =
      asset.type === "crypto"
        ? `/api/market/crypto/${asset.id}/history`
        : `/api/market/stocks/${asset.id}/history`;
    fetch(endpoint)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("fetch"))))
      .then((d) => {
        if (!cancelled) setHistory(d.prices || []);
      })
      .catch(() => {
        if (!cancelled) setHistory([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [asset]);

  // Close on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  // Lock body scroll while open
  useEffect(() => {
    if (asset) {
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = "";
      };
    }
  }, [asset]);

  if (!asset) return null;

  const change = asset.priceChange24h ?? 0;
  const up = change >= 0;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`${asset.name} chart`}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/75 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal panel */}
      <div className="relative w-full max-w-7xl bg-slate-950 border border-white/10 rounded-2xl shadow-2xl shadow-black/60 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10 bg-slate-900/80">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={asset.image}
              alt={asset.name}
              className="w-8 h-8 rounded-full bg-slate-700 flex-shrink-0"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  "data:image/svg+xml," +
                  encodeURIComponent(
                    `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><rect width="32" height="32" rx="16" fill="#475569"/><text x="16" y="21" text-anchor="middle" fill="white" font-size="14" font-family="sans-serif">${asset.symbol[0]}</text></svg>`
                  );
              }}
            />
            <div className="min-w-0">
              <p className="text-sm font-bold text-white truncate">
                {asset.name}{" "}
                <span className="text-slate-500 font-normal">
                  {asset.symbol} · {asset.type === "crypto" ? "Crypto" : "Stock"}
                </span>
              </p>
              <p className="text-xs text-slate-400 tabular-nums">
                $
                {asset.currentPrice.toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: asset.currentPrice < 1 ? 5 : 2,
                })}{" "}
                <span className={up ? "text-emerald-400" : "text-red-400"}>
                  {up ? "▲" : "▼"} {Math.abs(change).toFixed(2)}%
                </span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            title="Close (Esc)"
            className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Chart mode tabs */}
        <div className="flex items-center gap-2 px-5 py-2.5 border-b border-white/10 bg-slate-900/50">
          <button
            onClick={() => setMode("tv")}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              mode === "tv"
                ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                : "text-slate-500 hover:text-slate-300 border border-transparent"
            }`}
          >
            📊 TradingView · Live
          </button>
          <button
            onClick={() => setMode("local")}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              mode === "local"
                ? "bg-purple-500/20 text-purple-400 border border-purple-500/30"
                : "text-slate-500 hover:text-slate-300 border border-transparent"
            }`}
          >
            🕯️ Local Candles
          </button>
          <span className="ml-auto text-[10px] text-slate-600 hidden sm:inline">
            {mode === "tv"
              ? "Live data · Powered by TradingView"
              : "30-day history · In-browser engine"}
          </span>
        </div>

        {/* Scrollable body: chart + AI prediction below it */}
        <div className="max-h-[85vh] overflow-y-auto">
          {mode === "tv" ? (
            <div className="h-[60vh] min-h-[420px]">
              <TradingViewChart
                symbol={toTradingViewSymbol(asset.id, asset.type, asset.symbol)}
                height="100%"
              />
            </div>
          ) : (
            <CandleChart
              history={history}
              symbol={asset.symbol}
              loading={loading}
            />
          )}

          {/* AI prediction for this asset, right below the chart */}
          <div className="p-4 sm:p-6 border-t border-white/10 bg-slate-950">
            <AIPrediction
              symbol={asset.symbol}
              assetType={asset.type}
              assetId={asset.id}
              allAssets={allAssets}
              history={history}
              currentPrice={asset.currentPrice}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
