"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  loadLS,
  saveLS,
  LS,
  currentUser,
  logoutUser,
  updateUserAccount,
  changePassword,
  type NotificationItem,
} from "@/lib/pro";

const NAV = [
  { href: "/", label: "Dashboard", key: "dashboard" },
  { href: "/markets", label: "Markets", key: "markets" },
  { href: "/portfolio", label: "Portfolio", key: "portfolio" },
  { href: "/watchlist", label: "Watchlist", key: "watchlist" },
  { href: "/assistant", label: "Assistant", key: "assistant" },
];

export function ProShell({
  active,
  children,
}: {
  active: string;
  children: React.ReactNode;
}) {
  const [notifs, setNotifs] = useState<NotificationItem[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setNotifs(loadLS<NotificationItem[]>(LS.notifications, []));
    const t = setInterval(
      () => setNotifs(loadLS<NotificationItem[]>(LS.notifications, [])),
      3000
    );
    return () => clearInterval(t);
  }, []);

  const unread = notifs.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-slate-200">
      {/* ── Top Navbar ── */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-900/85 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2.5 flex-shrink-0">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/25">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
            </span>
            <span className="text-lg font-bold text-white">
              Market<span className="text-blue-400">AI</span>
              <span className="ml-1.5 text-[10px] font-semibold text-purple-300 bg-purple-500/20 px-1.5 py-0.5 rounded align-middle">
                PRO
              </span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1 ml-4">
            {NAV.map((n) => (
              <Link
                key={n.key}
                href={n.href}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  active === n.key
                    ? "bg-indigo-600/20 text-indigo-300"
                    : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            {/* Login / Logout control */}
            <AuthChip />

            {/* Notification bell */}
            <div className="relative">
              <button
                onClick={() => setOpen(!open)}
                className="relative w-9 h-9 rounded-lg bg-slate-800/80 border border-white/5 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
                title="Notifications"
              >
                <svg className="w-4.5 h-4.5" width={18} height={18} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.4-1.4A2 2 0 0118 14.2V11a6 6 0 10-12 0v3.2c0 .5-.2 1-.6 1.4L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {unread > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                    {unread}
                  </span>
                )}
              </button>

              {open && (
                <div className="absolute right-0 mt-2 w-80 max-h-96 overflow-y-auto rounded-xl border border-white/10 bg-slate-900 shadow-2xl shadow-black/50">
                  <div className="px-4 py-2.5 border-b border-white/5 flex items-center justify-between">
                    <p className="text-sm font-semibold text-white">Notifications</p>
                    <Link
                      href="/alerts"
                      onClick={() => setOpen(false)}
                      className="text-xs text-indigo-400 hover:text-indigo-300"
                    >
                      View all
                    </Link>
                  </div>
                  {notifs.length === 0 ? (
                    <p className="px-4 py-6 text-xs text-slate-500 text-center">
                      No notifications yet. Create price alerts or run the AI to
                      generate signals.
                    </p>
                  ) : (
                    notifs.slice(0, 8).map((n) => (
                      <div key={n.id} className="px-4 py-2.5 border-b border-white/5 last:border-0">
                        <p className="text-xs font-semibold text-white">{n.title}</p>
                        <p className="text-xs text-slate-400 mt-0.5">{n.body}</p>
                        <p className="text-[10px] text-slate-600 mt-1">
                          {new Date(n.time).toLocaleTimeString()}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile nav */}
        <nav className="md:hidden flex items-center gap-1 px-4 pb-2 overflow-x-auto">
          {NAV.map((n) => (
            <Link
              key={n.key}
              href={n.href}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap ${
                active === n.key
                  ? "bg-indigo-600/20 text-indigo-300"
                  : "text-slate-400"
              }`}
            >
              {n.label}
            </Link>
          ))}
        </nav>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">{children}</main>
    </div>
  );
}

export function PageTitle({ icon, title, subtitle }: { icon: string; title: string; subtitle: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold text-white flex items-center gap-2.5">
        <span>{icon}</span> {title}
      </h1>
      <p className="text-sm text-slate-400 mt-1">{subtitle}</p>
    </div>
  );
}

/**
 * Auth control:
 *  - Signed out  → 🔒 Login button
 *  - Signed in   → click avatar → account panel
 *    (Name, Age, Gmail, Phone, Password, Logout)
 *  - After Logout → back to Login button
 */
export function AuthChip() {
  const [user, setUser] = useState<ReturnType<typeof currentUser>>(null);
  const [open, setOpen] = useState(false);
  const [pName, setPName] = useState("");
  const [pAge, setPAge] = useState("");
  const [pEmail, setPEmail] = useState("");
  const [pPhone, setPPhone] = useState("");
  const [curPass, setCurPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    const u = currentUser();
    setUser(u);
    const t = setInterval(() => setUser(currentUser()), 2000);
    return () => clearInterval(t);
  }, []);

  // Sync form when the signed-in user changes
  useEffect(() => {
    if (user) {
      setPName(user.name);
      setPAge(user.age ?? "");
      setPEmail(user.email);
      setPPhone(user.phone ?? "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // ── Signed out → Login button ──
  if (!user) {
    return (
      <Link
        href="/login"
        className="flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors shadow-lg shadow-indigo-600/25"
      >
        <svg width={13} height={13} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
        </svg>
        Login
      </Link>
    );
  }

  const initials =
    user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase() || "U";

  const saveDetails = () => {
    updateUserAccount(user.id, { name: pName, email: pEmail, age: pAge, phone: pPhone });
    // keep the profile page in sync
    const prof = loadLS<Record<string, unknown>>("mai_profile", {});
    saveLS("mai_profile", { ...prof, name: pName, email: pEmail });
    setUser(currentUser());
    setMsg({ ok: true, text: "Saved ✅" });
  };

  const doChangePass = () => {
    const res = changePassword(user.id, curPass, newPass);
    setMsg(res.ok ? { ok: true, text: "Password updated ✅" } : { ok: false, text: res.error ?? "Failed" });
    if (res.ok) { setCurPass(""); setNewPass(""); }
  };

  const doLogout = () => {
    logoutUser();
    setUser(null);
    setOpen(false);
    window.location.href = "/";
  };

  return (
    <div className="relative">
      {/* Avatar button */}
      <button
        onClick={() => { setOpen(!open); setMsg(null); }}
        title={`${user.name} — my account`}
        className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-extrabold border transition-colors ${
          open
            ? "bg-indigo-600 text-white border-indigo-500"
            : "bg-slate-800/80 border-white/5 text-slate-200 hover:border-indigo-500/50"
        }`}
      >
        {initials}
      </button>

      {/* Account dropdown panel */}
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-2 w-[320px] z-50 rounded-2xl border border-white/10 bg-slate-900 shadow-2xl shadow-black/60 p-4">
            <div className="flex items-center gap-2.5 mb-3">
              <span className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-extrabold text-white">
                {initials}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-bold text-white truncate">{user.name}</p>
                <p className="text-[10px] text-slate-500 truncate">{user.email}</p>
              </div>
            </div>

            <div className="space-y-2">
              <PanelField label="Name" value={pName} onChange={setPName} />
              <div className="grid grid-cols-2 gap-2">
                <PanelField label="Age" value={pAge} onChange={setPAge} type="number" />
                <PanelField label="Phone" value={pPhone} onChange={setPPhone} />
              </div>
              <PanelField label="Gmail / Email" value={pEmail} onChange={setPEmail} type="email" />
              <button
                onClick={saveDetails}
                className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
              >
                💾 Save details
              </button>
            </div>

            <div className="border-t border-white/10 my-3" />

            <div className="space-y-2">
              <PanelField label="Current password" value={curPass} onChange={setCurPass} type="password" />
              <PanelField label="New password (≥ 6)" value={newPass} onChange={setNewPass} type="password" />
              <button
                onClick={doChangePass}
                className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                🔑 Change password
              </button>
            </div>

            {msg && (
              <p className={`mt-2 text-[11px] ${msg.ok ? "text-emerald-400" : "text-red-400"}`}>{msg.text}</p>
            )}

            <div className="border-t border-white/10 my-3" />

            <button
              onClick={doLogout}
              className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 text-xs font-semibold"
            >
              <svg width={13} height={13} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
              </svg>
              Logout
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function PanelField({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="text-[10px] text-slate-500">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-0.5 w-full bg-slate-800 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500/60"
      />
    </label>
  );
}
