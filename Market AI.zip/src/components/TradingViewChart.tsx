"use client";

import { useEffect, useRef } from "react";

/* ── Map our assets to TradingView symbols ── */
const CRYPTO_TV: Record<string, string> = {
  bitcoin: "BINANCE:BTCUSDT",
  ethereum: "BINANCE:ETHUSDT",
  binancecoin: "BINANCE:BNBUSDT",
  solana: "BINANCE:SOLUSDT",
  ripple: "BINANCE:XRPUSDT",
  cardano: "BINANCE:ADAUSDT",
  dogecoin: "BINANCE:DOGEUSDT",
  polkadot: "BINANCE:DOTUSDT",
  "avalanche-2": "BINANCE:AVAXUSDT",
  chainlink: "BINANCE:LINKUSDT",
};

const STOCK_TV: Record<string, string> = {
  AAPL: "NASDAQ:AAPL",
  MSFT: "NASDAQ:MSFT",
  GOOGL: "NASDAQ:GOOGL",
  AMZN: "NASDAQ:AMZN",
  NVDA: "NASDAQ:NVDA",
  META: "NASDAQ:META",
  TSLA: "NASDAQ:TSLA",
  JPM: "NYSE:JPM",
  V: "NYSE:V",
  WMT: "NYSE:WMT",
};

export function toTradingViewSymbol(
  id: string,
  type: "crypto" | "stock",
  symbol: string
): string {
  if (type === "crypto") return CRYPTO_TV[id] ?? `BINANCE:${symbol}USDT`;
  return STOCK_TV[symbol.toUpperCase()] ?? symbol.toUpperCase();
}

interface TradingViewChartProps {
  symbol: string; // TradingView symbol e.g. "BINANCE:BTCUSDT"
  height?: number | string; // px number or CSS value like "100%"
}

/**
 * Official TradingView Advanced Chart widget (live data, indicators,
 * drawing tools, interval buttons — exactly like the TradingView UI).
 */
export function TradingViewChart({ symbol, height = 520 }: TradingViewChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    container.innerHTML = "";

    const h = typeof height === "number" ? `${height}px` : height;
    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    widgetDiv.style.height = h;
    widgetDiv.style.width = "100%";
    container.appendChild(widgetDiv);

    const script = document.createElement("script");
    script.src =
      "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.type = "text/javascript";
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol,
      interval: "60",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1", // candlesticks
      locale: "en",
      withdateranges: true,
      hide_side_toolbar: false,
      allow_symbol_change: true,
      calendar: false,
      support_host: "https://www.tradingview.com",
      backgroundColor: "rgba(2, 6, 23, 1)",
      gridColor: "rgba(148, 163, 184, 0.06)",
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: false,
      studies: ["STD;RSI"],
    });
    container.appendChild(script);

    return () => {
      container.innerHTML = "";
    };
  }, [symbol, height]);

  return (
    <div
      ref={containerRef}
      className="tradingview-widget-container w-full"
      style={{ height: typeof height === "number" ? `${height}px` : height }}
    />
  );
}
