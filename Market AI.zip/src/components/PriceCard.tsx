"use client";

interface MarketAsset {
  id: string;
  symbol: string;
  name: string;
  image: string;
  currentPrice: number;
  marketCap: number;
  priceChange24h: number | null;
  sparkline: number[];
}

interface PriceCardProps {
  asset: MarketAsset;
  isSelected: boolean;
  onClick: () => void;
}

export function PriceCard({ asset, isSelected, onClick }: PriceCardProps) {
  const isPositive = (asset.priceChange24h ?? 0) >= 0;
  const sparklineColor = isPositive ? "#34d399" : "#f87171";

  // Normalize sparkline for mini chart
  const sparklinePoints = asset.sparkline || [];
  const min = Math.min(...sparklinePoints, 0);
  const max = Math.max(...sparklinePoints, 1);
  const range = max - min || 1;

  const normalizedPoints = sparklinePoints.map((p) => ({
    x: 0,
    y: 100 - ((p - min) / range) * 100,
  }));

  // Build SVG path (only if we have points)
  const width = 80;
  const height = 32;
  const stepX = sparklinePoints.length > 1 ? width / (sparklinePoints.length - 1) : 0;

  const pathD =
    sparklinePoints.length > 1
      ? normalizedPoints
          .map(
            (pt, i) =>
              `${i === 0 ? "M" : "L"} ${i * stepX} ${pt.y}`
          )
          .join(" ")
      : "";

  return (
    <button
      onClick={onClick}
      className={`w-full text-left p-3 rounded-xl transition-all duration-200 group ${
        isSelected
          ? "bg-blue-500/10 border border-blue-500/30 shadow-lg shadow-blue-500/5"
          : "hover:bg-slate-700/50 border border-transparent"
      }`}
    >
      <div className="flex items-center gap-3">
        <img
          src={asset.image}
          alt={asset.name}
          className="w-9 h-9 rounded-full bg-slate-700 flex-shrink-0"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "data:image/svg+xml," +
              encodeURIComponent(
                `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36"><rect width="36" height="36" rx="18" fill="#475569"/><text x="18" y="22" text-anchor="middle" fill="white" font-size="16" font-family="sans-serif">${asset.symbol[0]}</text></svg>`
              );
          }}
        />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white truncate">
            {asset.name}
          </p>
          <p className="text-xs text-slate-500">{asset.symbol}</p>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-sm font-semibold text-white tabular-nums">
            $
            {asset.currentPrice.toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: asset.currentPrice < 1 ? 4 : 2,
            })}
          </p>
          <p
            className={`text-xs font-medium tabular-nums ${
              isPositive ? "text-emerald-400" : "text-red-400"
            }`}
          >
            {isPositive ? "+" : ""}
            {(asset.priceChange24h ?? 0).toFixed(2)}%
          </p>
        </div>
        {/* Mini Sparkline */}
        {sparklinePoints.length > 1 && (
          <svg width={width} height={height} className="flex-shrink-0 hidden sm:block">
            <path
              d={pathD}
              fill="none"
              stroke={sparklineColor}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </div>
    </button>
  );
}
