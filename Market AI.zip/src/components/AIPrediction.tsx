"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  YAxis,
  Tooltip,
} from "recharts";

interface PricePoint {
  timestamp: number;
  price: number;
  date?: string;
}

export interface AssetOption {
  id: string;
  symbol: string;
  name: string;
  type: "crypto" | "stock";
}

interface PredictionResult {
  currentPrice: number;
  predictedPrice: number;
  changePercent: number;
  trend: "bullish" | "bearish";
  confidence: number;
  support: number;
  resistance: number;
  indicators: {
    rsi: number;
    volatility: number;
    regressionR2: number;
  };
  timeframe: string;
}

interface AIPredictionProps {
  symbol: string;
  assetType: "crypto" | "stock";
  assetId: string;
  allAssets: AssetOption[];
  history: PricePoint[];
  currentPrice: number;
}

const TIMEFRAMES = [
  { label: "1h", value: 1 },
  { label: "24h", value: 24 },
  { label: "7d", value: 168 },
  { label: "30d", value: 720 },
];

// ════════════════════════════════════════════════════════════════
//  AI PREDICTION ENGINE (runs entirely in the browser)
//  Ensemble: Linear Regression 45% + EMA/MACD 30% + RSI 15% + Noise 10%
// ════════════════════════════════════════════════════════════════

function linearRegression(values: number[]) {
  const n = values.length;
  if (n < 2) return { slope: 0, intercept: values[0] ?? 0, r2: 0 };
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += values[i];
    sumXY += i * values[i];
    sumX2 += i * i;
  }
  const denom = n * sumX2 - sumX * sumX;
  if (denom === 0) return { slope: 0, intercept: sumY / n, r2: 0 };
  const slope = (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  const meanY = sumY / n;
  let ssRes = 0, ssTot = 0;
  for (let i = 0; i < n; i++) {
    const predicted = slope * i + intercept;
    ssRes += (values[i] - predicted) ** 2;
    ssTot += (values[i] - meanY) ** 2;
  }
  const r2 = ssTot === 0 ? 0 : 1 - ssRes / ssTot;
  return { slope, intercept, r2: Math.max(0, Math.min(1, r2)) };
}

function ema(values: number[], period: number): number {
  if (values.length === 0) return 0;
  if (values.length < period) return values[values.length - 1];
  const k = 2 / (period + 1);
  let v = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) v = values[i] * k + v * (1 - k);
  return v;
}

function rsi(values: number[], period = 14): number {
  if (values.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const diff = values[i] - values[i - 1];
    if (diff >= 0) gains += diff;
    else losses -= diff;
  }
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = (gains / period) / avgLoss;
  return 100 - 100 / (1 + rs);
}

function volatility(values: number[]): number {
  if (values.length < 2) return 0;
  const rets: number[] = [];
  for (let i = 1; i < values.length; i++)
    rets.push((values[i] - values[i - 1]) / values[i - 1]);
  const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
  const variance =
    rets.reduce((sum, r) => sum + (r - mean) ** 2, 0) / rets.length;
  return Math.sqrt(variance);
}

const round2 = (v: number) => Math.round(v * 100) / 100;

function predictPriceLocally(
  prices: PricePoint[],
  timeframeHours: number
): PredictionResult {
  const priceValues = prices
    .map((p) => p.price)
    .filter((v) => Number.isFinite(v));
  if (priceValues.length < 5) {
    throw new Error("Not enough price data for prediction");
  }

  const currentPrice = priceValues[priceValues.length - 1];
  const recentCount = Math.max(24, Math.floor(priceValues.length * 0.4));
  const recent = priceValues.slice(-recentCount);

  const reg = linearRegression(recent);
  const futureIdx = recent.length + Math.max(1, Math.round(timeframeHours));
  const regPred = reg.slope * futureIdx + reg.intercept;

  const shortP = Math.max(2, Math.min(12, Math.floor(recent.length / 4)));
  const longP = Math.max(2, Math.min(26, Math.floor(recent.length / 2)));
  const momentum =
    currentPrice !== 0
      ? (ema(recent, shortP) - ema(recent, longP)) / currentPrice
      : 0;

  const rsiValue = rsi(recent, 14);
  const rsiFactor = (rsiValue - 50) / 50;
  const vol = volatility(recent);
  const volTf = timeframeHours * (1 + vol * 2);

  const momentumPred = currentPrice * (1 + momentum * (volTf / 24));
  const rsiPred = currentPrice * (1 + rsiFactor * 0.05 * (timeframeHours / 24));
  const noise = (Math.random() - 0.5) * vol * currentPrice * 0.1;

  let predicted =
    regPred * 0.45 +
    momentumPred * 0.3 +
    rsiPred * 0.15 +
    (currentPrice + noise) * 0.1;

  predicted = Math.max(currentPrice * 0.7, Math.min(currentPrice * 1.3, predicted));

  const regConf = reg.r2;
  const volConf = Math.max(0, 1 - vol * 15);
  const dataConf = Math.min(1, prices.length / 168);
  const confidence = Math.min(
    95,
    Math.max(
      30,
      Math.round((regConf * 0.4 + volConf * 0.35 + dataConf * 0.25) * 100)
    )
  );

  const sorted = [...recent].sort((a, b) => a - b);
  const support = sorted[Math.floor(sorted.length * 0.05)] ?? currentPrice;
  const resistance = sorted[Math.floor(sorted.length * 0.95)] ?? currentPrice;
  const changePercent = ((predicted - currentPrice) / currentPrice) * 100;

  return {
    currentPrice: round2(currentPrice),
    predictedPrice: round2(predicted),
    changePercent: round2(changePercent),
    trend: predicted > currentPrice ? "bullish" : "bearish",
    confidence,
    support: round2(support),
    resistance: round2(resistance),
    indicators: {
      rsi: Math.round(rsiValue * 10) / 10,
      volatility: Math.round(vol * 10000) / 100,
      regressionR2: Math.round(reg.r2 * 1000) / 10,
    },
    timeframe: `${timeframeHours}h`,
  };
}

const fmt = (v: number) =>
  v.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: Math.abs(v) < 1 ? 5 : 2,
  });

type Signal = "BUY" | "SELL" | "HOLD";

const SIGNAL_STYLES: Record<
  Signal,
  { text: string; border: string; bg: string; bar: string }
> = {
  BUY: {
    text: "text-emerald-400",
    border: "border-emerald-500/40",
    bg: "bg-emerald-500/5",
    bar: "bg-emerald-400",
  },
  SELL: {
    text: "text-red-400",
    border: "border-red-500/40",
    bg: "bg-red-500/5",
    bar: "bg-red-400",
  },
  HOLD: {
    text: "text-amber-400",
    border: "border-amber-500/40",
    bg: "bg-amber-500/5",
    bar: "bg-amber-400",
  },
};

// ════════════════════════════════════════════════════════════════
//  Main component
// ════════════════════════════════════════════════════════════════

export function AIPrediction({
  symbol,
  assetType,
  assetId,
  allAssets = [],
  history,
}: AIPredictionProps) {
  const assets = useMemo<AssetOption[]>(() => {
    if (allAssets && allAssets.length > 0) return allAssets;
    return [
      {
        id: assetId || symbol || "current",
        symbol: symbol || "—",
        name: symbol || "Current asset",
        type: assetType,
      },
    ];
  }, [allAssets, assetId, symbol, assetType]);

  const [chosenId, setChosenId] = useState(assetId || assets[0]?.id || "");
  const [chosenHistory, setChosenHistory] = useState<PricePoint[]>(history);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [selectedTf, setSelectedTf] = useState(24);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pastPredictions, setPastPredictions] = useState<
    { predictedPrice: number; currentPrice: number; createdAt: string }[]
  >([]);

  const chosenAsset = useMemo(
    () => assets.find((a) => a.id === chosenId) ?? assets[0],
    [assets, chosenId]
  );

  useEffect(() => {
    setChosenId(assetId || assets[0]?.id || "");
  }, [assetId, assets]);

  useEffect(() => {
    if (allAssets.length === 0 || !assetId || chosenId === assetId) {
      setChosenHistory(history);
      setHistoryLoading(false);
      return;
    }
    const asset = assets.find((a) => a.id === chosenId);
    if (!asset) return;
    let cancelled = false;
    setHistoryLoading(true);
    const endpoint =
      asset.type === "crypto"
        ? `/api/market/crypto/${asset.id}/history`
        : `/api/market/stocks/${asset.id}/history`;
    fetch(endpoint)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("fetch"))))
      .then((data) => {
        if (!cancelled) setChosenHistory(data.prices || []);
      })
      .catch(() => {
        if (!cancelled) setChosenHistory([]);
      })
      .finally(() => {
        if (!cancelled) setHistoryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [chosenId, assetId, history, assets, allAssets.length]);

  const chosenSymbol = chosenAsset?.symbol ?? symbol;
  const chosenType = chosenAsset?.type ?? assetType;

  const runPrediction = useCallback(() => {
    if (chosenHistory.length < 5) return;
    setLoading(true);
    setError(null);
    const timer = setTimeout(() => {
      try {
        const result = predictPriceLocally(chosenHistory, selectedTf);
        setPrediction(result);
        fetch("/api/predict", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            symbol: chosenSymbol,
            assetType: chosenType,
            prices: chosenHistory,
            timeframe: selectedTf,
          }),
        }).catch(() => {});
      } catch (err) {
        setError(err instanceof Error ? err.message : "Not enough data");
      } finally {
        setLoading(false);
      }
    }, 350);
    return () => clearTimeout(timer);
  }, [chosenHistory, selectedTf, chosenSymbol, chosenType]);

  const fetchPastPredictions = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/predict?symbol=${chosenSymbol}&assetType=${chosenType}`
      );
      if (res.ok) setPastPredictions(await res.json());
    } catch {
      /* ignore */
    }
  }, [chosenSymbol, chosenType]);

  useEffect(() => {
    const cleanup = runPrediction();
    fetchPastPredictions();
    return cleanup;
  }, [runPrediction, fetchPastPredictions]);

  // ── Derived display values ──
  const isPositive = (prediction?.changePercent ?? 0) >= 0;
  const signal: Signal = !prediction
    ? "HOLD"
    : prediction.changePercent >= 1
    ? "BUY"
    : prediction.changePercent <= -1
    ? "SELL"
    : "HOLD";
  const sStyle = SIGNAL_STYLES[signal];

  // 90% confidence band: Monte-Carlo style volatility envelope
  const band = useMemo(() => {
    if (!prediction) return { low: 0, high: 0 };
    const volFrac = (prediction.indicators.volatility || 1) / 100;
    const horizon = Math.sqrt(Math.max(1, selectedTf));
    const half = prediction.currentPrice * volFrac * 1.65 * horizon * 0.15;
    return {
      low: prediction.predictedPrice - half,
      high: prediction.predictedPrice + half,
    };
  }, [prediction, selectedTf]);

  return (
    <div className="bg-slate-900/70 border border-white/5 rounded-2xl p-5 sm:p-6">
      {/* ── Header ─ */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-5">
        <div className="flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-lg bg-slate-800 border border-white/10 flex items-center justify-center">
            <svg className="w-5 h-5 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3v1.5M15.75 3v1.5M4.5 7.5h15a1.5 1.5 0 011.5 1.5v8.25a1.5 1.5 0 01-1.5 1.5h-15A1.5 1.5 0 013 17.25V9a1.5 1.5 0 011.5-1.5zM9 12h.008M15 12h.008M9.75 15.75c.75.5 1.5.75 2.25.75s1.5-.25 2.25-.75" />
            </svg>
          </span>
          <h3 className="text-base font-bold text-white">AI price prediction</h3>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Manual asset selector */}
          <div className="relative">
            <select
              value={chosenId}
              onChange={(e) => setChosenId(e.target.value)}
              title="Pick asset to predict"
              className="appearance-none bg-slate-800/80 border border-white/10 rounded-lg pl-3 pr-8 py-2 text-xs font-semibold text-white focus:outline-none focus:border-indigo-500/50 cursor-pointer"
            >
              <optgroup label="🪙 Crypto">
                {assets
                  .filter((a) => a.type === "crypto")
                  .map((a) => (
                    <option key={a.id} value={a.id} className="bg-slate-900">
                      {a.symbol} — {a.name}
                    </option>
                  ))}
              </optgroup>
              <optgroup label="📈 Stocks">
                {assets
                  .filter((a) => a.type === "stock")
                  .map((a) => (
                    <option key={a.id} value={a.id} className="bg-slate-900">
                      {a.symbol} — {a.name}
                    </option>
                  ))}
              </optgroup>
            </select>
            <svg className="w-3 h-3 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </div>

          {/* Timeframe pills */}
          <div className="flex gap-1 bg-slate-800/80 rounded-lg p-1">
            {TIMEFRAMES.map((tf) => (
              <button
                key={tf.value}
                onClick={() => setSelectedTf(tf.value)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
                  selectedTf === tf.value
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {tf.label}
              </button>
            ))}
          </div>

          {/* Re-run model */}
          <button
            onClick={runPrediction}
            className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold shadow-lg shadow-indigo-600/25 transition-colors"
          >
            Re-run model
          </button>
        </div>
      </div>

      {historyLoading ? (
        <div className="flex items-center justify-center py-16 gap-3">
          <div className="w-6 h-6 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm">Loading price data...</p>
        </div>
      ) : loading ? (
        <div className="flex items-center justify-center py-16 gap-3">
          <div className="w-6 h-6 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm">AI analyzing market data...</p>
        </div>
      ) : error ? (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-center">
          <p className="text-red-400 text-sm">{error}</p>
          <button onClick={runPrediction} className="mt-2 text-xs text-red-300 underline">
            Try again
          </button>
        </div>
      ) : prediction ? (
        <div className="space-y-5">
          {/* ── Three result cards ── */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Predicted price */}
            <div className="rounded-xl border border-white/10 bg-slate-950/60 p-5">
              <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold">
                Predicted price ({selectedTf}h)
              </p>
              <p className="mt-2 text-3xl font-extrabold text-white tabular-nums">
                ${fmt(prediction.predictedPrice)}
              </p>
              <p
                className={`mt-2 text-sm font-semibold tabular-nums ${
                  isPositive ? "text-emerald-400" : "text-red-400"
                }`}
              >
                {isPositive ? "+" : ""}
                {prediction.changePercent}% vs now
              </p>
            </div>

            {/* Model signal */}
            <div className={`rounded-xl border p-5 ${sStyle.border} ${sStyle.bg}`}>
              <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                Model signal
              </p>
              <p className={`mt-2 text-3xl font-extrabold ${sStyle.text}`}>
                {signal}
              </p>
              <p className="mt-1 text-sm text-slate-300">
                Confidence {prediction.confidence}%
              </p>
              <div className="mt-3 h-1.5 bg-slate-700/60 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${sStyle.bar}`}
                  style={{ width: `${prediction.confidence}%` }}
                />
              </div>
            </div>

            {/* Confidence band */}
            <div className="rounded-xl border border-white/10 bg-slate-950/60 p-5">
              <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold">
                90% confidence band
              </p>
              <p className="mt-2 text-2xl font-extrabold text-white tabular-nums">
                ${fmt(band.low)} – ${fmt(band.high)}
              </p>
              <p className="mt-2 text-sm text-slate-500">
                Monte-Carlo style volatility envelope
              </p>
            </div>
          </div>

          {/* ── Forecast chart (history + up/down trajectory) ── */}
          <div className="rounded-xl border border-white/5 bg-slate-950/40 p-4">
            <ForecastChart history={chosenHistory} prediction={prediction} />
            <div className="flex items-center justify-center gap-4 mt-2 text-[10px] text-slate-500">
              <span className="flex items-center gap-1.5">
                <span className="w-4 h-0.5 bg-slate-400 inline-block" /> History
              </span>
              <span className="flex items-center gap-1.5">
                <span
                  className={`w-4 h-0.5 inline-block border-t-2 border-dashed ${
                    isPositive ? "border-emerald-400" : "border-red-400"
                  }`}
                />
                AI Forecast ({isPositive ? "UP" : "DOWN"})
              </span>
            </div>
          </div>

          {/* ── Compact indicators ── */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <MiniStat label="RSI (14)" value={prediction.indicators.rsi.toFixed(1)} />
            <MiniStat
              label="Volatility"
              value={`${prediction.indicators.volatility}%`}
            />
            <MiniStat
              label="Model fit R²"
              value={`${prediction.indicators.regressionR2}%`}
            />
            <MiniStat label="Support" value={`$${fmt(prediction.support)}`} />
            <MiniStat label="Resistance" value={`$${fmt(prediction.resistance)}`} />
          </div>

          {/* ── Past predictions ── */}
          {pastPredictions.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                Prediction history
              </h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {pastPredictions.slice(-5).reverse().map((p, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between bg-slate-950/40 border border-white/5 rounded-lg px-4 py-2"
                  >
                    <div className="text-xs text-slate-400">
                      {new Date(p.createdAt).toLocaleDateString()}
                    </div>
                    <div className="text-xs font-mono text-slate-300">
                      ${fmt(p.currentPrice)} → ${fmt(p.predictedPrice)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <p className="text-xs text-slate-600 text-center italic">
            ⚠️ AI predictions are for informational purposes only. Not financial advice.
          </p>
        </div>
      ) : (
        <div className="text-center py-12 text-slate-500 text-sm">
          Select an asset and timeframe to generate AI predictions
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
//  Forecast chart: history line + dashed up/down prediction line
// ════════════════════════════════════════════════════════════════

function ForecastChart({
  history,
  prediction,
}: {
  history: PricePoint[];
  prediction: PredictionResult;
}) {
  const data = useMemo(() => {
    const tail = history.slice(-60);
    if (tail.length < 2) return [];
    const pts: { x: number; hist: number | null; pred: number | null }[] =
      tail.map((p, i) => ({ x: i, hist: p.price, pred: null }));
    pts[pts.length - 1].pred = pts[pts.length - 1].hist;
    pts.push({ x: pts.length, hist: null, pred: prediction.predictedPrice });
    return pts;
  }, [history, prediction]);

  const up = prediction.trend === "bullish";
  const forecastColor = up ? "#34d399" : "#f87171";

  if (data.length === 0) return null;

  return (
    <div className="h-[180px]">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data}>
          <YAxis hide domain={["auto", "auto"]} />
          <Tooltip
            contentStyle={{
              backgroundColor: "#1e293b",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "10px",
              color: "#f1f5f9",
              fontSize: 12,
            }}
            formatter={(value) => [`$${fmt(Number(value))}`, "Price"]}
            labelFormatter={() => ""}
          />
          <Line
            type="monotone"
            dataKey="hist"
            stroke="#94a3b8"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
          <Line
            type="monotone"
            dataKey="pred"
            stroke={forecastColor}
            strokeWidth={2.5}
            strokeDasharray="6 4"
            dot={{ r: 4, fill: forecastColor, strokeWidth: 0 }}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/5 bg-slate-950/40 px-3 py-2">
      <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">
        {label}
      </p>
      <p className="text-sm font-bold text-white tabular-nums mt-0.5">{value}</p>
    </div>
  );
}
