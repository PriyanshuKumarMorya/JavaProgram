/**
 * Whitelist of project files available for download via /api/source.
 * Used by the /sync page so users can pull exact latest files
 * from the live preview to their local machine (no copy-paste truncation).
 */
export const SYNC_FILES: string[] = [
  // components
  "src/components/MarketDashboard.tsx",
  "src/components/AIPrediction.tsx",
  "src/components/CandleChart.tsx",
  "src/components/ChartModal.tsx",
  "src/components/ProPanel.tsx",
  "src/components/ProShell.tsx",
  "src/components/PriceCard.tsx",
  "src/components/PriceChart.tsx",
  "src/components/WatchlistPanel.tsx",
  "src/components/TradingViewChart.tsx",
  // lib
  "src/lib/pro.ts",
  "src/lib/api.ts",
  "src/lib/syncFiles.ts",
  // app pages
  "src/app/layout.tsx",
  "src/app/page.tsx",
  "src/app/error.tsx",
  "src/app/globals.css",
  "src/app/markets/page.tsx",
  "src/app/portfolio/page.tsx",
  "src/app/strategy/page.tsx",
  "src/app/assistant/page.tsx",
  "src/app/alerts/page.tsx",
  "src/app/trade/[symbol]/page.tsx",
  "src/app/architecture/page.tsx",
  "src/app/setup-guide/page.tsx",
  "src/app/sync/page.tsx",
  "src/app/profile/page.tsx",
  "src/app/login/page.tsx",
  "src/app/watchlist/page.tsx",
  "src/app/coach/page.tsx",
  "src/app/learn/page.tsx",
  // api routes
  "src/app/api/source/route.ts",
  "src/app/api/predict/route.ts",
  "src/app/api/watchlist/route.ts",
  "src/app/api/health/route.ts",
  "src/app/api/market/crypto/route.ts",
  "src/app/api/market/crypto/[id]/history/route.ts",
  "src/app/api/market/stocks/route.ts",
  "src/app/api/market/stocks/[symbol]/history/route.ts",
  // db + config
  "src/db/index.ts",
  "src/db/schema.ts",
  "next.config.ts",
  "package.json",
];
