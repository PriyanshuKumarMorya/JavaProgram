/* ═══════════════════════════════════════════════════════════════
   MarketAI Pro — client-side engine:
   portfolio store, risk score, AI recommendations, news sentiment,
   strategy backtester, chatbot brain, learning content.
   ═══════════════════════════════════════════════════════════════ */

/** Bump this whenever files change — the navbar shows it so you can
 *  verify your local copy matches the live preview after syncing. */
export const APP_VERSION = "v26.08.03-r4";

export type AssetType = "crypto" | "stock";

export interface Position {
  symbol: string;
  name: string;
  type: AssetType;
  qty: number;
  avgBuy: number;
}

export interface AlertItem {
  id: string;
  symbol: string;
  type: AssetType;
  dir: "above" | "below" | "change"; // change = 24h move ≥ X%
  price: number;
  createdAt: number;
}

export interface NotificationItem {
  id: string;
  kind: "signal" | "news" | "portfolio" | "trade" | "alert";
  title: string;
  body: string;
  time: number;
  read: boolean;
}

/* ── localStorage helpers ── */
export function loadLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function saveLS<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

export const LS = {
  portfolio: "mai_portfolio",
  alerts: "mai_alerts",
  notifications: "mai_notifications",
  watchlist: "mai_watchlist_pro",
};

export const DEFAULT_PORTFOLIO: Position[] = [
  { symbol: "BTC", name: "Bitcoin", type: "crypto", qty: 0.25, avgBuy: 58200 },
  { symbol: "ETH", name: "Ethereum", type: "crypto", qty: 2.4, avgBuy: 1720 },
  { symbol: "SOL", name: "Solana", type: "crypto", qty: 18, avgBuy: 61 },
  { symbol: "AAPL", name: "Apple Inc.", type: "stock", qty: 12, avgBuy: 214 },
  { symbol: "NVDA", name: "NVIDIA", type: "stock", qty: 9, avgBuy: 108 },
];

export function pushNotification(n: Omit<NotificationItem, "id" | "time" | "read">) {
  const list = loadLS<NotificationItem[]>(LS.notifications, []);
  list.unshift({ ...n, id: Math.random().toString(36).slice(2), time: Date.now(), read: false });
  saveLS(LS.notifications, list.slice(0, 50));
}

/* ── math utils ── */
export function stdevReturns(prices: number[]): number {
  if (prices.length < 2) return 0;
  const rets: number[] = [];
  for (let i = 1; i < prices.length; i++) rets.push((prices[i] - prices[i - 1]) / prices[i - 1]);
  const m = rets.reduce((a, b) => a + b, 0) / rets.length;
  const v = rets.reduce((s, r) => s + (r - m) ** 2, 0) / rets.length;
  return Math.sqrt(v);
}

export function rsi14(prices: number[]): number {
  if (prices.length < 15) return 50;
  let g = 0, l = 0;
  for (let i = prices.length - 14; i < prices.length; i++) {
    const d = prices[i] - prices[i - 1];
    if (d >= 0) g += d;
    else l -= d;
  }
  if (l === 0) return 100;
  const rs = g / 14 / (l / 14);
  return 100 - 100 / (1 + rs);
}

export function sma(values: number[], period: number): number {
  if (values.length === 0) return 0;
  const s = values.slice(-period);
  return s.reduce((a, b) => a + b, 0) / s.length;
}

/* ── Risk Score (0–100) ── */
export function riskScore(prices: number[], change24h: number): {
  score: number;
  label: "Low" | "Medium" | "High";
} {
  const vol = stdevReturns(prices);
  const rsi = rsi14(prices);
  let score = Math.min(60, vol * 100 * 9);
  score += Math.min(25, Math.abs(change24h) * 2.5);
  score += Math.min(15, Math.abs(rsi - 50) / 3);
  score = Math.round(Math.max(0, Math.min(100, score)));
  return { score, label: score < 35 ? "Low" : score < 65 ? "Medium" : "High" };
}

/* ── AI Buy/Sell/Hold recommendation ── */
export interface Recommendation {
  signal: "BUY" | "SELL" | "HOLD";
  confidence: number;
  reasons: string[];
  entry: number;
  stopLoss: number;
  target: number;
}

export function recommend(prices: number[], change24h: number): Recommendation {
  const rsi = rsi14(prices);
  const vol = stdevReturns(prices);
  const short = sma(prices, 12);
  const long = sma(prices, 26);
  const last = prices[prices.length - 1] ?? 0;
  const reasons: string[] = [];
  let score = 0;

  if (short > long) {
    score += 1;
    reasons.push("Short-term trend (SMA12) is above SMA26 — bullish momentum");
  } else {
    score -= 1;
    reasons.push("Short-term trend (SMA12) is below SMA26 — bearish momentum");
  }
  if (rsi < 32) {
    score += 1;
    reasons.push(`RSI ${rsi.toFixed(0)} is oversold — potential rebound zone`);
  } else if (rsi > 68) {
    score -= 1;
    reasons.push(`RSI ${rsi.toFixed(0)} is overbought — pullback risk elevated`);
  } else {
    reasons.push(`RSI ${rsi.toFixed(0)} is neutral`);
  }
  if (change24h > 1) {
    score += 0.5;
    reasons.push(`Positive 24h momentum (+${change24h.toFixed(2)}%)`);
  } else if (change24h < -1) {
    score -= 0.5;
    reasons.push(`Negative 24h momentum (${change24h.toFixed(2)}%)`);
  }
  if (vol < 0.008) reasons.push("Low volatility — cleaner technical signals");
  else if (vol > 0.02) reasons.push("High volatility — use smaller position size");

  const signal: Recommendation["signal"] = score >= 1.5 ? "BUY" : score <= -1.5 ? "SELL" : "HOLD";
  const confidence = Math.round(Math.min(92, 55 + Math.abs(score) * 12 + (vol < 0.01 ? 5 : 0)));
  const atr = last * Math.max(vol * 3, 0.015);
  return {
    signal,
    confidence,
    reasons,
    entry: last,
    stopLoss: signal === "SELL" ? last + atr : last - atr,
    target: signal === "SELL" ? last - atr * 2 : last + atr * 2,
  };
}

/* ── News with sentiment (deterministic mock) ── */
export interface NewsItem {
  title: string;
  source: string;
  time: string;
  sentiment: "Positive" | "Negative" | "Neutral";
  summary: string;
}

export function generateNews(symbol: string, name: string): NewsItem[] {
  const seed = symbol.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const sents: NewsItem["sentiment"][] = ["Positive", "Neutral", "Positive", "Negative", "Neutral"];
  const templates = [
    {
      t: `${name} sees renewed institutional interest as on-chain activity climbs`,
      sum: `AI summary: Accumulation by large holders and rising active addresses suggest growing confidence in ${symbol}. Momentum indicators are turning supportive.`,
    },
    {
      t: `Analysts split on ${name} near-term direction after volatile week`,
      sum: `AI summary: Opinion is divided; resistance overhead remains while support has held twice. A breakout above recent highs would confirm bullish structure.`,
    },
    {
      t: `${name} volatility cools as market digests macro data`,
      sum: `AI summary: Realized volatility is compressing. Historically this precedes an expansion move — direction likely decided by the trend regime.`,
    },
    {
      t: `Regulatory headline weighs on ${name} sentiment`,
      sum: `AI summary: Policy uncertainty triggered profit-taking. Sentiment score dipped, but long-term holders remained net buyers.`,
    },
    {
      t: `${name} technical setup: traders watch key moving-average cluster`,
      sum: `AI summary: Price is testing the 50/100 MA zone. Volume profile shows interest on both sides; risk-reward favours patient entries with defined stops.`,
    },
  ];
  const sources = ["MarketWire", "CoinDesk", "Bloomberg", "Reuters", "The Street"];
  const hours = [1, 3, 6, 12, 24];
  return templates.map((tpl, i) => ({
    title: tpl.t,
    summary: tpl.sum,
    source: sources[(seed + i) % sources.length],
    sentiment: sents[(seed + i) % sents.length],
    time: `${hours[i]}h ago`,
  }));
}

export function sentimentScore(news: NewsItem[]): number {
  if (news.length === 0) return 0;
  const v = news.reduce((s, n) => s + (n.sentiment === "Positive" ? 1 : n.sentiment === "Negative" ? -1 : 0), 0);
  return Math.round((v / news.length) * 100);
}

/* ── Strategy backtester ── */
export interface BacktestResult {
  strategy: string;
  totalReturn: number;
  buyHold: number;
  winRate: number;
  trades: number;
  maxDrawdown: number;
  equity: { i: number; v: number }[];
}

export function backtest(
  prices: number[],
  strategy: "sma" | "rsi" | "momentum"
): BacktestResult {
  const n = prices.length;
  let cash = 10000;
  let units = 0;
  let equity: { i: number; v: number }[] = [];
  let wins = 0, losses = 0, entryPrice = 0;
  let peak = 10000, maxDD = 0;

  const close = (i: number, price: number) => {
    if (units > 0) {
      cash += units * price;
      if (price > entryPrice) wins++;
      else losses++;
      units = 0;
    }
  };
  const open = (i: number, price: number) => {
    if (units === 0 && cash > 0) {
      units = cash / price;
      entryPrice = price;
      cash = 0;
    }
  };

  for (let i = 30; i < n; i++) {
    const p = prices[i];
    const win = prices.slice(0, i + 1);
    let sig = 0;
    if (strategy === "sma") {
      const s = sma(win, 10), l = sma(win, 30);
      const sp = sma(win.slice(0, -1), 10), lp = sma(win.slice(0, -1), 30);
      if (sp <= lp && s > l) sig = 1;
      if (sp >= lp && s < l) sig = -1;
    } else if (strategy === "rsi") {
      const r = rsi14(win);
      if (r < 30) sig = 1;
      if (r > 70) sig = -1;
    } else {
      const roc = (p - prices[i - 24]) / prices[i - 24];
      const rocP = (prices[i - 1] - prices[i - 25]) / prices[i - 25];
      if (rocP <= 0 && roc > 0) sig = 1;
      if (rocP >= 0 && roc < 0) sig = -1;
    }
    if (sig === 1) open(i, p);
    if (sig === -1) close(i, p);
    const val = cash + units * p;
    peak = Math.max(peak, val);
    maxDD = Math.max(maxDD, (peak - val) / peak);
    equity.push({ i, v: Math.round(val * 100) / 100 });
  }
  close(n - 1, prices[n - 1]);
  const finalVal = cash;
  const total = wins + losses;
  const buyHold = ((prices[n - 1] - prices[30]) / prices[30]) * 100;
  return {
    strategy,
    totalReturn: ((finalVal - 10000) / 10000) * 100,
    buyHold,
    winRate: total ? (wins / total) * 100 : 0,
    trades: total,
    maxDrawdown: maxDD * 100,
    equity,
  };
}

/* ── Chatbot brain (rule-based) ── */
export function chatAnswer(q: string, ctx?: { symbol?: string; signal?: string }): string {
  const s = q.toLowerCase();
  if (/stop[\s-]?loss/.test(s))
    return "A stop-loss is a pre-defined exit price that caps your loss on a trade. A common rule: risk 1–2% of your account per trade. Example: with a $10,000 account and a 5% stop distance, position size = $200 risk ÷ 0.05 = $4,000. On the Trade page I compute this for you automatically.";
  if (/rsi/.test(s))
    return "RSI (Relative Strength Index) measures momentum on a 0–100 scale. Below 30 = oversold (possible bounce), above 70 = overbought (possible pullback). I use RSI inside my ensemble prediction model and the RSI strategy in the Strategy Lab.";
  if (/macd/.test(s))
    return "MACD shows the gap between two EMAs (12 & 26). When the MACD line crosses above its signal line it's bullish; below is bearish. My AI model uses EMA momentum as 30% of its prediction weight.";
  if (/candle|doji|hammer/.test(s))
    return "Candlesticks show open/high/low/close for a period. A long lower wick (hammer) after a drop suggests buyers stepping in; a long upper wick suggests rejection. Switch the chart to 'Price' candles in any asset popup to read them.";
  if (/diversif|allocat/.test(s))
    return "Diversification spreads risk across uncorrelated assets. Your Portfolio page shows an allocation pie — aim for no single position above ~20–25% of total value, and mix crypto (high vol) with stocks (lower vol).";
  if (/risk/.test(s))
    return "I score risk 0–100 from volatility, 24h move and RSI extremes. <35 = Low, 35–65 = Medium, >65 = High. Size positions so a stop-out loses ≤2% of the portfolio. See the Risk Score card on any Trade page.";
  if (/portfolio|p&l|pnl/.test(s))
    return "Your Portfolio page tracks live value, unrealized P&L, return %, win rate and allocation. I also act as an AI Trading Coach there — reviewing concentration risk and suggesting rebalancing.";
  if (/buy|sell|hold|signal|recommend/.test(s))
    return `My recommendation engine blends trend (SMA cross), momentum (RSI) and volatility. Currently for ${ctx?.symbol ?? "the selected asset"} the model leans ${ctx?.signal ?? "HOLD"}. Always pair a signal with a stop-loss and target — shown on the Trade page.`;
  if (/strategy|backtest/.test(s))
    return "The Strategy Lab backtests SMA-Cross, RSI-Reversal and Momentum strategies on 30 days of real history. It reports return vs buy-and-hold, win rate, trade count and max drawdown so you can compare before risking capital.";
  if (/learn|beginner|start|basic/.test(s))
    return "Start in Learn mode (Assistant page): 4 short lessons on candles, trend, risk and indicators, plus a quiz. Golden rules: 1) trend is your friend, 2) never risk >2% per trade, 3) always define your exit before entry.";
  if (/news|sentiment/.test(s))
    return "On the Markets page I attach a sentiment tag (Positive/Neutral/Negative) and an AI summary to each headline, plus an overall sentiment score. Use it as context — never as a standalone trigger.";
  if (/voice|speak|mic/.test(s))
    return "Tap the mic button and ask me anything — I listen via your browser's speech recognition and reply out loud. Works best in Chrome. Example: 'What is the risk score of Bitcoin?'";
  if (/hello|hi|hey|namaste/.test(s))
    return "Hello! I'm your MarketAI assistant. Ask me about indicators, risk, your portfolio, strategies — or press the mic and speak. You can also say 'open portfolio' or 'open strategy lab'.";
  if (/open portfolio/.test(s)) return "Opening your Portfolio page now… 📊";
  if (/open strategy|open lab/.test(s)) return "Opening the Strategy Lab… 🧪";
  if (/open market|open news|compare/.test(s)) return "Opening Markets & Compare… 📰";
  return "I can help with: stop-loss & position sizing, RSI/MACD/candlesticks, risk scores, buy-sell signals, your portfolio, backtesting strategies, news sentiment, and learning basics. Try: 'How do I size a position with a stop loss?'";
}

/* ── Learning content ── */
export const LESSONS = [
  {
    title: "1 · Reading Candlesticks",
    body: "Each candle = one time period. Green: close > open. Red: close < open. Wicks show the extremes. Patterns like hammers (long lower wick) hint at reversals; long upper wicks show rejection. Always read candles in context of the trend.",
  },
  {
    title: "2 · Trend & Moving Averages",
    body: "Price above rising 50/200 MA = uptrend; below = downtrend. SMA crossovers (fast over slow = 'golden cross') are classic trend-change signals. Trade with the trend for higher win rates.",
  },
  {
    title: "3 · Risk Management (most important)",
    body: "Risk ≤1–2% of capital per trade. Position size = risk $ ÷ (entry − stop). Reward:Risk ≥ 2:1. A 50% win rate with 2:1 R:R is highly profitable. Survive first, profit second.",
  },
  {
    title: "4 · Indicators: RSI & MACD",
    body: "RSI gauges overbought/oversold (70/30). MACD gauges momentum shifts. Indicators confirm — they don't predict. Combine with trend + price action, and you have my ensemble model's recipe.",
  },
];

export const QUIZ = [
  {
    q: "You have $10,000 and risk 2% per trade. Entry $100, stop $95. Position size?",
    options: ["200 shares", "40 shares", "100 shares", "20 shares"],
    answer: 1,
    why: "Risk $ = 200. Per-share risk = $5. 200 ÷ 5 = 40 shares.",
  },
  {
    q: "RSI at 25 typically means the asset is…",
    options: ["Overbought", "Oversold", "Neutral", "Trending"],
    answer: 1,
    why: "RSI below 30 = oversold; a bounce becomes more likely.",
  },
  {
    q: "A healthy minimum Reward:Risk ratio is…",
    options: ["1:1", "0.5:1", "2:1", "1:3"],
    answer: 2,
    why: "2:1 lets you be wrong half the time and still grow.",
  },
];

/* ═══════════════════════════════════════════════════════════════
   Market Regime Detector — Bull / Bear / Sideways / High Volatility
   ═══════════════════════════════════════════════════════════════ */
export interface Regime {
  regime: "Bull Market" | "Bear Market" | "Sideways" | "High Volatility";
  emoji: string;
  color: string;
  confidence: number;
  analysis: string[];
  approach: string;
}

export function detectRegime(values: number[]): Regime {
  const fallback: Regime = {
    regime: "Sideways",
    emoji: "🟡",
    color: "#facc15",
    confidence: 50,
    analysis: ["Not enough data yet"],
    approach: "Wait for more data.",
  };
  if (values.length < 12) return fallback;

  const win = values.slice(-Math.min(values.length, 96));
  const ret = (win[win.length - 1] - win[0]) / win[0];
  const vol = stdevReturns(win);
  const mn = Math.min(...win);
  const mx = Math.max(...win);
  const rangePct = (mx - mn) / mn;

  let r: Regime;
  if (vol > 0.018 && rangePct > 0.1) {
    r = {
      regime: "High Volatility",
      emoji: "🟠",
      color: "#fb923c",
      analysis: [
        "Elevated bar-to-bar volatility",
        "Wide trading range",
        "Direction uncertain — whipsaw risk",
      ],
      approach: "Reduce position size, tighten stops, consider hedges.",
      confidence: 0,
    };
    r.confidence = Math.round(Math.min(95, 58 + vol * 900));
  } else if (ret > 0.02) {
    r = {
      regime: "Bull Market",
      emoji: "🟢",
      color: "#34d399",
      analysis: [
        "Positive directional momentum",
        "Higher highs / higher lows forming",
        "Trend-following strategies favoured",
      ],
      approach: "Buy pullbacks; trail stops under higher lows.",
      confidence: 0,
    };
    r.confidence = Math.round(Math.min(95, 60 + ret * 450));
  } else if (ret < -0.02) {
    r = {
      regime: "Bear Market",
      emoji: "🔴",
      color: "#f87171",
      analysis: [
        "Negative directional momentum",
        "Lower lows / lower highs forming",
        "Rallies are being sold into",
      ],
      approach: "Defensive: raise cash, hedge, avoid catching falling knives.",
      confidence: 0,
    };
    r.confidence = Math.round(Math.min(95, 60 + Math.abs(ret) * 450));
  } else {
    r = {
      regime: "Sideways",
      emoji: "🟡",
      color: "#facc15",
      analysis: [
        "Low directional momentum",
        "Price moving within a range",
        "Moderate volatility",
      ],
      approach: "Wait for a confirmed breakout; trade range edges only.",
      confidence: 0,
    };
    r.confidence = Math.round(Math.min(95, 62 + (0.08 - Math.min(0.08, rangePct)) * 350));
  }
  return r;
}

/* ═══════════════════════════════════════════════════════════════
   AI Opportunity Radar — scans assets for interesting setups
   ═══════════════════════════════════════════════════════════════ */
export interface RadarItem {
  id: string;
  symbol: string;
  name: string;
  type: AssetType;
  setup: "Bullish Setup" | "Watch" | "Weak Momentum";
  emoji: string;
  color: string;
  confidence: number;
  ret7: number;
  rsi: number;
}

export function radarScan(
  assets: {
    id: string;
    symbol: string;
    name: string;
    type: AssetType;
    sparkline?: number[];
  }[]
): RadarItem[] {
  return assets
    .map((a) => {
      const sp = a.sparkline ?? [];
      const ret7 = sp.length > 1 ? ((sp[sp.length - 1] - sp[0]) / sp[0]) * 100 : 0;
      const rsi = rsi14(sp);
      const vol = stdevReturns(sp);
      let score = 0;
      if (ret7 > 2) score += 2;
      else if (ret7 > 0) score += 1;
      else if (ret7 < -2) score -= 2;
      else score -= 1;
      if (rsi >= 50 && rsi <= 70) score += 1;
      if (rsi < 30) score += 1; // oversold bounce candidate
      if (rsi > 75) score -= 1;
      if (vol < 0.02) score += 0.5;

      const setup: RadarItem["setup"] =
        score >= 2 ? "Bullish Setup" : score <= -1 ? "Weak Momentum" : "Watch";
      const confidence = Math.round(
        Math.min(93, 55 + Math.abs(score) * 9 + Math.min(15, Math.abs(ret7)))
      );
      return {
        id: a.id,
        symbol: a.symbol,
        name: a.name,
        type: a.type,
        setup,
        emoji: setup === "Bullish Setup" ? "🟢" : setup === "Weak Momentum" ? "🔴" : "🟡",
        color:
          setup === "Bullish Setup" ? "#34d399" : setup === "Weak Momentum" ? "#f87171" : "#facc15",
        confidence,
        ret7,
        rsi,
      };
    })
    .sort((a, b) => b.confidence - a.confidence);
}

/* ═══════════════════════════════════════════════════════════════
   What-If Scenario helpers
   ═══════════════════════════════════════════════════════════════ */
/** How strongly an asset moves vs the market (beta-like), from hourly vol */
export function sensitivity(hourlyVol: number): number {
  const daily = hourlyVol * Math.sqrt(24);
  return Math.max(0.4, Math.min(1.8, (daily * 100) / 2.5));
}

export function shockLevel(impactPct: number): "LOW" | "MEDIUM" | "HIGH" {
  const a = Math.abs(impactPct);
  return a < 4 ? "LOW" : a < 9 ? "MEDIUM" : "HIGH";
}

/* ═══════════════════════════════════════════════════════════════
   Local authentication (demo — data stays in the browser)
   ═══════════════════════════════════════════════════════════════ */
export interface UserAccount {
  id: string;
  name: string;
  email: string;
  pass: string; // light hash, demo only
  joinedAt: string;
  age?: string;
  phone?: string;
}

export const LS_USERS = "mai_users";
export const LS_SESSION = "mai_session";

const hash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return "h" + Math.abs(h).toString(36);
};

export function getUsers(): UserAccount[] {
  return loadLS<UserAccount[]>(LS_USERS, []);
}

export function currentUser(): UserAccount | null {
  const id = loadLS<string | null>(LS_SESSION, null);
  if (!id) return null;
  return getUsers().find((u) => u.id === id) ?? null;
}

export function registerUser(
  name: string,
  email: string,
  pass: string
): { ok: boolean; error?: string; user?: UserAccount } {
  if (!name.trim() || !email.trim() || pass.length < 6)
    return { ok: false, error: "Fill all fields (password ≥ 6 characters)." };
  const users = getUsers();
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase()))
    return { ok: false, error: "An account with this email already exists." };
  const user: UserAccount = {
    id: Math.random().toString(36).slice(2),
    name: name.trim(),
    email: email.trim(),
    pass: hash(pass),
    joinedAt: new Date().toISOString(),
  };
  users.push(user);
  saveLS(LS_USERS, users);
  saveLS(LS_SESSION, user.id);
  return { ok: true, user };
}

export function loginUser(
  email: string,
  pass: string
): { ok: boolean; error?: string; user?: UserAccount } {
  const u = getUsers().find((x) => x.email.toLowerCase() === email.toLowerCase());
  if (!u) return { ok: false, error: "No account found with this email." };
  if (u.pass !== hash(pass)) return { ok: false, error: "Incorrect password." };
  saveLS(LS_SESSION, u.id);
  return { ok: true, user: u };
}

export function logoutUser() {
  if (typeof window !== "undefined") window.localStorage.removeItem(LS_SESSION);
}

export function demoLogin(): UserAccount {
  let u = getUsers().find((x) => x.email === "demo@marketai.pro");
  if (!u) {
    const r = registerUser("Demo Trader", "demo@marketai.pro", "demo1234");
    u = r.user!;
  } else {
    saveLS(LS_SESSION, u.id);
  }
  return u;
}

export function updateUserAccount(
  id: string,
  patch: Partial<Pick<UserAccount, "name" | "email" | "age" | "phone">>
) {
  const users = getUsers().map((u) => (u.id === id ? { ...u, ...patch } : u));
  saveLS(LS_USERS, users);
}

export function changePassword(
  id: string,
  oldPass: string,
  newPass: string
): { ok: boolean; error?: string } {
  if (newPass.length < 6) return { ok: false, error: "New password must be ≥ 6 characters." };
  const users = getUsers();
  const u = users.find((x) => x.id === id);
  if (!u) return { ok: false, error: "User not found." };
  if (u.pass !== hash(oldPass)) return { ok: false, error: "Current password is incorrect." };
  u.pass = hash(newPass);
  saveLS(LS_USERS, users);
  return { ok: true };
}
