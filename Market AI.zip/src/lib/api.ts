/**
 * API configuration.
 *
 * In development, the Spring Boot backend runs on http://localhost:8080.
 * The Next.js frontend runs on http://localhost:3000.
 *
 * Set NEXT_PUBLIC_API_BASE_URL to the Spring Boot URL (default: http://localhost:8080).
 */
const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8080";

export async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(`API ${res.status}: ${errorBody || res.statusText}`);
  }

  return res.json() as Promise<T>;
}

export { API_BASE };
